# Count toggles of every net inside the DUT and write them to a TCF file.
# The testbench calls $finish at 350 ns, so stop at 345 ns and close the file first.
dumptcf -scope tb_cnt_updown.dut -output activity/dut.tcf -overwrite
run 345 ns
dumptcf -end
puts "TCF written to activity/dut.tcf"
