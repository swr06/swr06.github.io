`timescale 1ns/1ps
module tb_cnt_updown_scan;
  localparam L = 8;                         // chain length from reports/scan_chains.rpt
  reg clk = 0, reset = 1, enable = 0, up_down = 1, scan_enable = 0, scan_in = 0;
  wire       scan_out;
  wire [7:0] count;
  integer    errors = 0, i;

  cnt_updown dut (.clk(clk), .reset(reset), .enable(enable), .up_down(up_down),
                  .scan_enable(scan_enable), .scan_in(scan_in),
                  .scan_out(scan_out), .count(count));
  always #50 clk = ~clk;                    // 100 ns test clock

  // Reference model of the chain: shifts only when scan_enable = 1
  reg [L-1:0] model;
  always @(posedge clk or posedge reset)
    if (reset)            model <= {L{1'b0}};
    else if (scan_enable) model <= {model[L-2:0], scan_in};

  initial begin
    $dumpfile("./scan_test.dump"); $dumpvars(0, tb_cnt_updown_scan);
    #120 reset = 0;

    // ---- Functional mode: count up 5 times ----
    @(negedge clk); enable = 1; up_down = 1;
    repeat (5) @(negedge clk);
    enable = 0;
    if (count !== 8'd5) begin errors = errors + 1; $display("ERROR functional count=%0d (expected 5)", count); end
    else $display("Functional mode OK: count = %0d", count);

    // ---- Shift mode: reset chain, then shift 2L random bits ----
    reset = 1; #10 reset = 0;
    scan_enable = 1;
    for (i = 0; i < 2*L; i = i + 1) begin
      scan_in = $random;
      @(negedge clk);
      if (scan_out !== model[L-1]) begin
        errors = errors + 1;
        $display("ERROR shift %0d: scan_out=%b expected=%b", i, scan_out, model[L-1]);
      end
    end
    scan_enable = 0;

    if (errors == 0) $display("PASS: functional and %0d-bit shift test", 2*L);
    else             $display("FAIL: %0d errors", errors);
    $finish;
  end
endmodule
