`timescale 1ns/1ps

module tb_cnt_updown;
  reg        clk;
  reg        reset;
  reg        enable;
  reg        up_down;
  wire [7:0] count;

  // ---------------- Device under test ----------------
  cnt_updown dut (
    .clk(clk), .reset(reset), .enable(enable),
    .up_down(up_down), .count(count)
  );

  // ---------------- 100 MHz clock (10 ns period) ----------------
  initial clk = 1'b0;
  always #5 clk = ~clk;          // rising edges at 5, 15, 25 ... ns

  // ---------------- Waveform database for SimVision ----------------
  initial begin
    $dumpfile("./updown_counter.dump");
    $dumpvars(0, tb_cnt_updown);
  end

  // ---------------- Optional SDF back-annotation (Chapter 7) ----------------
`ifdef SDF
  initial $sdf_annotate("results/cnt_updown.sdf", dut, , "logs/sdf_annotate.log", "MAXIMUM");
`endif

  // ---------------- Reference model: what count SHOULD be ----------------
  reg [7:0] expected;
  always @(posedge clk or posedge reset) begin
    if (reset)        expected <= 8'h00;
    else if (enable)  expected <= up_down ? expected + 8'h01 : expected - 8'h01;
  end

  // ---------------- Checker: compare on every falling edge ----------------
  integer errors = 0;
  integer checks = 0;
  always @(negedge clk) begin
    if (!reset) begin
      checks = checks + 1;
      if (count !== expected) begin
        errors = errors + 1;
        $display("ERROR  t=%0t ns  count=%0d  expected=%0d  (enable=%b up_down=%b)",
                 $time, count, expected, enable, up_down);
      end
    end
  end

  // ---------------- Stimulus: inputs change only on falling edges ----------------
  initial begin
    reset = 1'b1; enable = 1'b0; up_down = 1'b1;
    #22 reset = 1'b0;                          // release reset between clock edges

    @(negedge clk); enable = 1'b1; up_down = 1'b1;   // Phase 1: count up 10 times
    repeat (10) @(negedge clk);                       //          0 -> 10

    enable = 1'b0;                                    // Phase 2: hold for 3 cycles
    repeat (3) @(negedge clk);

    enable = 1'b1; up_down = 1'b0;                    // Phase 3: count down 12 times
    repeat (12) @(negedge clk);                       //          10 -> 0 -> 255 -> 254

    enable = 1'b0;                                    // Phase 4: hold
    repeat (2) @(negedge clk);

    #2 reset = 1'b1;                                  // Phase 5: asynchronous reset
    #2 reset = 1'b0;                                  //          in the middle of a cycle

    enable = 1'b1; up_down = 1'b1;                    // Phase 6: count up 3 times
    repeat (3) @(negedge clk);                        //          0 -> 3
    enable = 1'b0;
    repeat (2) @(negedge clk);

    if (errors == 0)
      $display("PASS: %0d cycle checks matched, final count = %0d", checks, count);
    else
      $display("FAIL: %0d of %0d cycle checks mismatched", errors, checks);
    $finish;
  end
endmodule
