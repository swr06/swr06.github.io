`timescale 1ns/1ps

module cnt_updown (
  input  wire       clk,
  input  wire       reset,     // asynchronous, active high
  input  wire       enable,    // 1 = count, 0 = hold
  input  wire       up_down,   // 1 = up,    0 = down
  output reg  [7:0] count
);

  always @(posedge clk or posedge reset) begin
    if (reset)
      count <= 8'h00;
    else if (enable) begin
      if (up_down)
        count <= count + 8'h01;
      else
        count <= count - 8'h01;
    end
  end

endmodule
