`timescale 1ns/1ps

module cnt_updown (
  input  wire       clk,
  input  wire       reset,        // asynchronous, active high (held 0 during test)
  input  wire       enable,
  input  wire       up_down,
  input  wire       scan_enable,  // 1 = shift, 0 = functional/capture
  input  wire       scan_in,      // serial data into the chain
  output wire       scan_out,     // serial data out of the chain (driven by RC)
  output reg  [7:0] count
);
  // Functional logic is unchanged. RC replaces the 8 flops with scan flops
  // and connects scan_in -> flop -> ... -> flop -> scan_out.
  always @(posedge clk or posedge reset) begin
    if (reset)
      count <= 8'h00;
    else if (enable) begin
      if (up_down) count <= count + 8'h01;
      else         count <= count - 8'h01;
    end
  end
endmodule
