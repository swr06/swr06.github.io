#!/bin/bash
# ---- Cadence environment for the ASIC lab (source this file, do not execute it) ----
export CDS_ROOT=/home/buet/cadence/IC615
export CDSHOME=$CDS_ROOT
export CDS_INSTALL_DIR=$CDS_ROOT/tools/dfII
export CDS_LIC_FILE=$CDS_ROOT/ic6151license.dat

export PATH=$CDS_ROOT/tools/dfII/bin:$CDS_ROOT/tools/bin:$PATH
export PATH=/home/buet/cadence/MMSIM121/tools/bin:$PATH
export PATH=/home/buet/cadence/ASSURA41/tools/bin:$PATH
export PATH=/home/buet/cadence/EDI/tools/bin:$PATH
export PATH=/home/buet/cadence/installs/INCISIV102/tools/bin:$PATH

# Example 45 nm library shipped with Encounter (used by every later chapter)
export PDK45=/home/buet/cadence/EDI/share/FoundationFlows/EXAMPLES/EDI/DESIGN/GPDK/LIBS/GPDK045
# Technology data of the same example kit: capTable, qrcTechFile, mapFile, qrc.conf
export PDK45_TECH=/home/buet/cadence/EDI/share/FoundationFlows/EXAMPLES/EDI/DESIGN/GPDK/TECH
# 90 nm transistor-level PDK (no standard cells) - used only to VIEW the final GDS in Virtuoso
export GPDK090=/home/buet/cadence/gpdk090_v4.6
