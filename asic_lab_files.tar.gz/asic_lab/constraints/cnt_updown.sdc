# ---------- Clock: 10 ns period = 100 MHz, on input port clk ----------
create_clock -name core_clk -period 10.000 [get_ports clk]
set_clock_uncertainty 0.20 [get_clocks core_clk]

# ---------- Inputs: arrive 1 ns after the clock edge (outside logic uses it) ----------
set_input_delay  1.00 -clock core_clk [get_ports {enable up_down reset}]

# ---------- Outputs: must be valid 1 ns before the next edge ----------
set_output_delay 1.00 -clock core_clk [all_outputs]

# ---------- Electrical environment of the boundary ----------
set_input_transition 0.10 [get_ports {enable up_down reset}]
set_load 0.05 [all_outputs]

# ---------- Asynchronous reset is not a timed single-cycle path ----------
set_false_path -from [get_ports reset]
