# ================= Encounter 13.10 place-and-route: cnt_updown =================
# VARIANT func (default) implements results/cnt_updown_mapped.v (Chapters 4-5);
# VARIANT scan implements the scan netlist from Chapter 6 (set by encounter_scan.tcl).
if {![info exists VARIANT]} { set VARIANT func }
set TOP cnt_updown
source scripts/lib_paths.tcl
if {$VARIANT eq "scan"} {
  set NETLIST  results/${TOP}_scan.v
  set SDC_FILE results/${TOP}_scan.sdc
  set TAG      ${TOP}_scan
  set R        reports/scan
} else {
  set NETLIST  results/${TOP}_mapped.v
  set SDC_FILE results/${TOP}_mapped.sdc
  set TAG      ${TOP}
  set R        reports
}
file mkdir reports results $R

# ---- 4.2-4.4  Import ----
set init_top_cell  $TOP
set init_verilog   $NETLIST
set init_lef_file  $LEF_FILES
set init_mmmc_file scripts/mmmc.tcl
set init_pwr_net   VDD
set init_gnd_net   VSS
init_design
if {$VARIANT eq "scan"} {
  defIn results/${TOP}_scan.scandef          ;# scan-chain description from RC (Step 6.3)
}

# ---- 4.5  Floorplan: square, 72 % utilisation, 100 um margins, gsclib045 site ----
floorPlan -site CoreSite -r 1.0 0.72 100 100 100 100

# ---- 4.6  Global power connections ----
globalNetConnect VDD -type pgpin -pin VDD -inst * -verbose
globalNetConnect VSS -type pgpin -pin VSS -inst * -verbose
globalNetConnect VDD -type tiehi -inst * -verbose
globalNetConnect VSS -type tielo -inst * -verbose

# ---- 4.7  Core ring: Metal9 (horizontal) top/bottom, Metal8 (vertical) left/right ----
addRing -nets {VDD VSS} -type core_rings -follow core \
  -layer [list top $H_LAYER bottom $H_LAYER left $V_LAYER right $V_LAYER] \
  -width   {top 3 bottom 3 left 3 right 3} \
  -spacing {top 4 bottom 4 left 4 right 4} \
  -offset  {top 3 bottom 3 left 3 right 3}

# ---- 4.8  Stripes sized for this ~15 um core ----
addStripe -nets {VDD VSS} -direction horizontal -layer $H_LAYER \
  -width 1 -spacing 1 -set_to_set_distance 6 \
  -start_from bottom -start_offset 2 -stop_offset 2
addStripe -nets {VDD VSS} -direction vertical -layer $V_LAYER \
  -width 1 -spacing 1 -set_to_set_distance 6 \
  -start_from left -start_offset 2 -stop_offset 2

# ---- 4.9  Special route (cell rails) ----
sroute -connect {blockPin padPin padRing corePin floatingStripe} -nets {VDD VSS}

# ---- 4.10-4.11  Placement ----
setPlaceMode -clkGateAware true
setTieHiLoMode -cell $TIE_CELLS -maxFanout 8
setFillerMode -core $FILLERS -corePrefix FILL
placeDesign
if {$VARIANT eq "scan"} { catch {scanReorder} }
addTieHiLo
checkPlace $R/checkPlace.rpt
optDesign -preCTS -outDir $R/preCTS

# ---- 4.12  Clock tree ----
createClockTreeSpec -bufferList $CTS_BUFS -file constraints/Clock.ctstch
clockDesign -specFile constraints/Clock.ctstch -outDir $R/clock
optDesign -postCTS       -outDir $R/postCTS
optDesign -postCTS -hold -outDir $R/postCTS_hold

# ---- 4.13  Routing and post-route optimisation (cap-table extraction) ----
trialRoute
setNanoRouteMode -routeWithTimingDriven true -routeWithSiDriven true
routeDesign -globalDetail
if {[catch {setExtractRCMode -engine postRoute -effortLevel low}]} {
  setExtractRCMode -engine postRoute
}
setAnalysisMode -analysisType onChipVariation
optDesign -postRoute       -outDir $R/postRoute
optDesign -postRoute -hold -outDir $R/postRoute_hold

# ---- 4.14  Fillers, checks, save ----
addFiller -cell $FILLERS -prefix FILL
globalNetConnect VDD -type pgpin -pin VDD -inst * -verbose
globalNetConnect VSS -type pgpin -pin VSS -inst * -verbose
verifyConnectivity -type all -error 1000 -warning 50 -report $R/connectivity.rpt
verifyGeometry -report $R/geometry.rpt
timeDesign -postRoute       -outDir $R/timing_final
timeDesign -postRoute -hold -outDir $R/timing_final
saveDesign  results/${TAG}_postRoute.enc
saveNetlist results/${TAG}_postRoute.v

# ---- Exports for signoff (Chapter 7) ----
extractRC
rcOut -spef results/${TAG}.spef -rc_corner RC_TYP
write_sdf -view VIEW_SETUP results/${TAG}.sdf
if {[catch {write_sdc -view VIEW_SETUP results/${TAG}_postRoute.sdc}]} {
  catch {writeTimingCon -sdc -view VIEW_SETUP results/${TAG}_postRoute.sdc}
}
defOut -floorplan -netlist -routing results/${TAG}.def
if {[catch {streamOut results/${TAG}.gds -mapFile $STREAM_MAP -libName DesignLib \
              -structureName $TOP -units $DB_UNITS -mode ALL -outputMacros} msg]} {
  puts "**NOTE: streamOut with -outputMacros failed ($msg) - retrying without it"
  streamOut results/${TAG}.gds -mapFile $STREAM_MAP -libName DesignLib \
    -structureName $TOP -units $DB_UNITS -mode ALL
}
puts "==== Encounter flow for $TAG finished ===="
