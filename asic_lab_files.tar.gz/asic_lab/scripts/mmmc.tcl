# ---------- MMMC view definition for Encounter 13.10 ----------
source scripts/lib_paths.tcl

# Which SDC to time with: RC's functional SDC unless a caller (Step 6.5) chose another
if {![info exists SDC_FILE]} { set SDC_FILE results/cnt_updown_mapped.sdc }

# Library sets: one per corner
create_library_set -name LIB_SLOW -timing [list $LIB_SLOW]
create_library_set -name LIB_FAST -timing [list $LIB_FAST]

# Interconnect (RC) corner: the kit's cap table; the QRC tech file only if you enabled it
if {$QRC_TECH ne ""} {
  create_rc_corner -name RC_TYP -cap_table $CAPTBL -qx_tech_file $QRC_TECH
} else {
  create_rc_corner -name RC_TYP -cap_table $CAPTBL
}

# Delay corners = library set + RC corner
create_delay_corner -name DC_SLOW -library_set LIB_SLOW -rc_corner RC_TYP
create_delay_corner -name DC_FAST -library_set LIB_FAST -rc_corner RC_TYP

# Constraint mode = the SDC written by RTL Compiler
create_constraint_mode -name FUNC -sdc_files [list $SDC_FILE]

# Analysis views: slow corner for setup, fast corner for hold
create_analysis_view -name VIEW_SETUP -constraint_mode FUNC -delay_corner DC_SLOW
create_analysis_view -name VIEW_HOLD  -constraint_mode FUNC -delay_corner DC_FAST
set_analysis_view -setup [list VIEW_SETUP] -hold [list VIEW_HOLD]
