# Re-run the full synthesis script, then annotate real activity and report power
source scripts/rtl_rc.tcl

read_tcf -instance tb_cnt_updown.dut activity/dut.tcf
report power         > reports/power_tcf.rpt
report power -verbose > reports/power_tcf_verbose.rpt
puts "==== Power with simulation activity written to reports/power_tcf.rpt ===="
