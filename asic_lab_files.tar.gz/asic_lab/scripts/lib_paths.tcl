# ---------- One source of truth for library data (values verified on this VM) ----------
# Project root = the folder that contains scripts/ (works in RC and in Encounter)
set ROOT       [file normalize [file join [file dirname [info script]] ..]]

set PDK45      /home/buet/cadence/EDI/share/FoundationFlows/EXAMPLES/EDI/DESIGN/GPDK/LIBS/GPDK045
set TECH45     /home/buet/cadence/EDI/share/FoundationFlows/EXAMPLES/EDI/DESIGN/GPDK/TECH
set GPDK090    /home/buet/cadence/gpdk090_v4.6

# Liberty (.lib): cell timing + power. 477 cells each.
set LIB_SLOW   $PDK45/timing/slow.lib      ;# library gpdk045bc : 1.08 V, 125 C  (setup corner)
set LIB_TYP    $PDK45/timing/typical.lib
set LIB_FAST   $PDK45/timing/fast.lib      ;# library gpdk045wc : 1.32 V,   0 C  (hold corner)

# Generated in Step 0.5 by scripts/gpdk045_libtool.py (the kit does not ship these)
set LIB_SLOW_SCAN $ROOT/libs/slow_scan.lib      ;# slow.lib + test_cell groups (for RC DFT)
set CELL_VLOG     $ROOT/libs/gsclib045_cells.v  ;# cell Verilog models (gate-level simulation)

# LEF: ONE file holds the technology section (layers, vias, CoreSite) AND all 487 cell macros
set LEF_FILES  [list $PDK45/gsclib045.lef]

# Parasitic extraction data from the same example kit
set CAPTBL       $TECH45/capTable          ;# used by every Encounter extraction in this lab
set QRC_TECH     ""                        ;# optional: $TECH45/qrcTechFile (see Step 4.3)
set QRC_LAYERMAP $TECH45/mapFile           ;# LEF-layer -> QRC-layer map that goes with it

# GDS: the kit has NO cell GDS and NO 45 nm stream map. Step 7.5 writes the routed
# design with LEF cell abstracts, using our own map file (gpdk090 layer numbers).
set GDS_CELLS  ""
set STREAM_MAP $ROOT/scripts/gds_view.map
set DB_UNITS   2000                        ;# LEF: DATABASE MICRONS 2000

# Power-grid layers: the two TOP routing layers of gsclib045.lef (Metal1..Metal9)
set H_LAYER    Metal9                      ;# HORIZONTAL, pitch 0.33
set V_LAYER    Metal8                      ;# VERTICAL,   pitch 0.20

# Cell names (all checked against gsclib045.lef / slow.lib on this VM)
set TIE_CELLS  {TIEHI TIELO}
set FILLERS    {FILL64 FILL32 FILL16 FILL8 FILL4 FILL2 FILL1}
set CTS_BUFS   {CLKBUFX2 CLKBUFX3 CLKBUFX4 CLKBUFX6 CLKBUFX8 CLKBUFX12 CLKINVX1 CLKINVX2 CLKINVX4 CLKINVX8}

# Supply of the slow (setup) corner, used for power and rail analysis
set VDD_VOLTS  1.08

foreach f [list $LIB_SLOW $LIB_FAST [lindex $LEF_FILES 0] $CAPTBL] {
  if {![file exists $f]} { puts "**ERROR (lib_paths.tcl): file not found: $f" }
}
puts "lib_paths.tcl loaded: ROOT=$ROOT LIB_SLOW=$LIB_SLOW"
