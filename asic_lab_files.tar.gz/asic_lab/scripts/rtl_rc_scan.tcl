# ================= RTL Compiler 12.10 synthesis + muxed scan insertion =================
set TOP  cnt_updown
set ROOT [file normalize .]
source scripts/lib_paths.tcl
file mkdir reports results

# The scan-aware copy of slow.lib (Step 0.5) - same timing, plus test_cell groups
if {![file exists $LIB_SLOW_SCAN]} {
  puts "**ERROR: $LIB_SLOW_SCAN not found - run Step 0.5 (gpdk045_libtool.py scan) first"
  return
}

set_attribute information_level 7 /
set_attribute hdl_search_path [list $ROOT/rtl] /
set_attribute library [list $LIB_SLOW_SCAN] /

read_hdl -v2001 [list rtl/cnt_updown_scan.v]
elaborate $TOP
read_sdc constraints/cnt_updown.sdc

# ---- 1. Declare the scan style and test signals (before mapping) ----
set_attribute dft_scan_style muxed_scan /
define_dft shift_enable -name SE     -active high [find / -port scan_enable]
define_dft test_mode    -name TM_RST -active low  [find / -port reset]
define_dft test_clock   -name scan_clk -period 100000 [find / -port clk]  ;# ps = 100 ns

# ---- 2. Check the DFT rules on the generic design ----
check_dft_rules      > reports/dft_rules_pre_map.rpt
report dft_registers > reports/dft_registers_pre_map.rpt

# ---- 3. Map: flops that passed the rules become scan flops (SDFF... cells) ----
synthesize -to_generic
synthesize -to_mapped

# ---- 4. Build and connect the chain ----
define_dft scan_chain -name chain0 \
  -sdi [find / -port scan_in] -sdo [find / -port scan_out] -shift_enable SE
connect_scan_chains -chains chain0
synthesize -incremental

# ---- 5. Reports and outputs ----
check_dft_rules       > reports/dft_rules_post.rpt
report dft_setup      > reports/dft_setup.rpt
report dft_chains     > reports/scan_chains.rpt
report dft_registers  > reports/dft_registers.rpt
report gates          > reports/gates_scan.rpt
report timing         > reports/timing_scan.rpt
write_hdl     > results/cnt_updown_scan.v
write_sdc     > results/cnt_updown_scan.sdc
write_scandef > results/cnt_updown_scan.scandef
write_do_lec -revised_design results/cnt_updown_scan.v > results/cnt_updown_scan_lec.do
puts "==== Scan insertion finished ===="
