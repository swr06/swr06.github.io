# ================= RTL Compiler 12.10 synthesis: cnt_updown =================
set TOP  cnt_updown
set ROOT [file normalize .]
source scripts/lib_paths.tcl

file mkdir reports
file mkdir results

# ---- 1. Tool verbosity and library (slow corner: gpdk045bc, 1.08 V, 125 C) ----
set_attribute information_level 7 /
set_attribute hdl_search_path [list $ROOT/rtl] /
set_attribute library [list $LIB_SLOW] /

# ---- 2. Read and elaborate the RTL ----
read_hdl -v2001 [list rtl/cnt_updown.v]
elaborate $TOP
check_design -unresolved
check_design -all > reports/check_design.rpt

# ---- 3. Apply constraints and lint them ----
read_sdc constraints/cnt_updown.sdc
report timing -lint -verbose > reports/timing_lint.rpt
report clocks                > reports/clocks.rpt

# ---- 4. Synthesize in three passes ----
synthesize -to_generic -effort medium
synthesize -to_mapped  -effort medium
synthesize -incremental

# ---- 5. Reports ----
report gates  > reports/gates.rpt
report area   > reports/area.rpt
report timing > reports/timing.rpt
report power  > reports/power_vectorless.rpt
report qor    > reports/qor.rpt

# ---- 6. Outputs for the next tools ----
write_hdl  > results/cnt_updown_mapped.v
write_sdc  > results/cnt_updown_mapped.sdc
puts "==== RC synthesis of $TOP finished. Type 'exit' to quit. ===="
