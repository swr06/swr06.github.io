# Place and route the SCAN netlist from Chapter 6 with the same flow as Chapter 5
set VARIANT scan
source scripts/encounter.tcl
