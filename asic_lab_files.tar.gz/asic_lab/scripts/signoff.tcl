# ================= Chapter 7 signoff checks and exports (Encounter 13.10) =================
restoreDesign results/cnt_updown_postRoute.enc.dat cnt_updown
source scripts/lib_paths.tcl
file mkdir reports

# ---- Extraction with the GPDK045 cap table, then hand-off files ----
if {[catch {setExtractRCMode -engine postRoute -effortLevel low}]} {
  setExtractRCMode -engine postRoute
}
extractRC
rcOut -spef results/cnt_updown.spef -rc_corner RC_TYP
write_sdf -view VIEW_SETUP results/cnt_updown.sdf
if {[catch {write_sdc -view VIEW_SETUP results/cnt_updown_syn_final.sdc}]} {
  catch {writeTimingCon -sdc -view VIEW_SETUP results/cnt_updown_syn_final.sdc}
}

# ---- Implementation checks (Verify menu) ----
verifyConnectivity -type all  -report reports/signoff_connectivity.rpt
verifyGeometry                -report reports/signoff_geometry.rpt
verifyProcessAntenna          -reportfile reports/signoff_antenna.rpt
verifyMetalDensity            -report reports/signoff_metal_density.rpt
verifyCutDensity              -report reports/signoff_cut_density.rpt

# ---- Post-route timing with extracted parasitics ----
timeDesign -postRoute       -outDir reports/signoff_timing
timeDesign -postRoute -hold -outDir reports/signoff_timing
report_timing -max_paths 5 > reports/signoff_setup_paths.rpt
puts "==== signoff.tcl finished - read reports/signoff_* ===="
