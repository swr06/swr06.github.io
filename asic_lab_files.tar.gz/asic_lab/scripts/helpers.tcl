# Print the worst setup and hold slack of the current design state
proc slack_summary {tag} {
  set s [report_timing -late  -max_paths 1 -collection]
  set h [report_timing -early -max_paths 1 -collection]
  set ws [get_property $s slack]
  set wh [get_property $h slack]
  puts [format "%-12s  setup WNS = %8.3f ns   hold WNS = %8.3f ns" $tag $ws $wh]
}

# Count lines that contain a pattern in a report file
proc count_in_file {file pattern} {
  set fh [open $file r]; set n 0
  while {[gets $fh line] >= 0} { if {[regexp -- $pattern $line]} { incr n } }
  close $fh
  return $n
}
