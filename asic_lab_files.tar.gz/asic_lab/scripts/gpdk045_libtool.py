#!/usr/bin/env python
# -*- coding: ascii -*-
# =====================================================================
#  gpdk045_libtool.py  -  builds the two library views that the GPDK045
#  example kit on this VM does not ship:
#
#    verilog : Liberty (.lib)  ->  behavioural Verilog cell models
#              (functions, flip-flops, latches, tri-states, plus
#               specify paths so an SDF file can annotate delays)
#    scan    : Liberty (.lib)  ->  copy of the .lib with a test_cell
#              group added to every muxed-scan flop (SDFF...), so
#              RTL Compiler can map flops to scan flops.
#
#  Usage (from the project root):
#    python scripts/gpdk045_libtool.py verilog <in.lib> <out.v> [cells.lef]
#    python scripts/gpdk045_libtool.py scan    <in.lib> <out.lib>
#
#  Works with Python 2.6 (CentOS 6 system python) and Python 3.
# =====================================================================
import sys
import re

# ---------------------------------------------------------------------
#  Small file helpers (latin-1 so any byte in the .lib survives)
# ---------------------------------------------------------------------
def read_text(path):
    data = open(path, 'rb').read()
    if sys.version_info[0] >= 3:
        data = data.decode('latin-1')
    return data


def write_text(path, text):
    if sys.version_info[0] >= 3:
        text = text.encode('latin-1')
    f = open(path, 'wb')
    f.write(text)
    f.close()


# ---------------------------------------------------------------------
#  Liberty scanner
#    parse_block() returns the statements found at depth 0 of a block:
#      ('attr',  name, value)
#      ('group', name, args, body_start, body_end, header_start)
# ---------------------------------------------------------------------
TOK = re.compile(r'/\*|"|\{|\}|;|\n')
BRACE = re.compile(r'/\*|"|\{|\}')
COMMENT = re.compile(r'/\*.*?\*/', re.S)
HEADER = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*$', re.S)


def skip_comment(text, p):
    q = text.find('*/', p + 2)
    if q < 0:
        return len(text)
    return q + 2


def skip_string(text, p):
    q = text.find('"', p + 1)
    if q < 0:
        return len(text)
    return q + 1


def match_brace(text, p):
    """text[p] == '{'  ->  index of the matching '}'."""
    depth = 0
    pos = p
    n = len(text)
    while pos < n:
        m = BRACE.search(text, pos)
        if m is None:
            break
        tok = m.group()
        q = m.start()
        if tok == '/*':
            pos = skip_comment(text, q)
        elif tok == '"':
            pos = skip_string(text, q)
        elif tok == '{':
            depth += 1
            pos = q + 1
        else:
            depth -= 1
            pos = q + 1
            if depth == 0:
                return q
    raise ValueError('unbalanced braces starting at offset %d' % p)


def top_level_colon(s):
    """Index of the first ':' that is outside quotes and parentheses."""
    depth = 0
    inq = False
    i = 0
    for ch in s:
        if ch == '"':
            inq = not inq
        elif not inq:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ':' and depth == 0:
                return i
        i += 1
    return -1


def clean_value(v):
    v = v.strip()
    if v.endswith(';'):
        v = v[:-1].strip()
    if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
        v = v[1:-1]
    return v.strip()


def simple_attr_complete(s):
    """True when a line holds a whole 'name : value' with no ';' (sloppy libs)."""
    s = COMMENT.sub(' ', s).strip()
    if not s or s.endswith('\\'):
        return False
    if s.count('(') != s.count(')') or s.count('"') % 2:
        return False
    c = top_level_colon(s)
    return c > 0 and s[c + 1:].strip() != ''


def parse_block(text, start, end):
    items = []
    pos = start
    stmt = start
    while pos < end:
        m = TOK.search(text, pos, end)
        if m is None:
            break
        tok = m.group()
        p = m.start()
        if tok == '/*':
            pos = skip_comment(text, p)
            continue
        if tok == '"':
            pos = skip_string(text, p)
            continue
        if tok == '{':
            header = COMMENT.sub(' ', text[stmt:p])
            close = match_brace(text, p)
            hm = HEADER.match(header)
            if hm:
                args = hm.group(2).replace('"', '').strip()
                items.append(('group', hm.group(1), args, p + 1, close, stmt))
            pos = close + 1
            stmt = pos
            continue
        if tok == '}':
            pos = p + 1
            stmt = pos
            continue
        if tok == ';':
            add_statement(items, text[stmt:p])
            pos = p + 1
            stmt = pos
            continue
        # newline
        if simple_attr_complete(text[stmt:p]):
            add_statement(items, text[stmt:p])
            stmt = p + 1
        pos = p + 1
    return items


def add_statement(items, s):
    s = COMMENT.sub(' ', s).strip()
    if not s:
        return
    c = top_level_colon(s)
    if c > 0:
        items.append(('attr', s[:c].strip(), clean_value(s[c + 1:])))
    else:
        hm = HEADER.match(s)
        if hm:
            items.append(('cattr', hm.group(1), hm.group(2).strip()))


def attrs_of(items):
    d = {}
    for it in items:
        if it[0] == 'attr' and it[1] not in d:
            d[it[1]] = it[2]
    return d


def groups_of(items, name):
    return [it for it in items if it[0] == 'group' and it[1] == name]


# ---------------------------------------------------------------------
#  Liberty boolean expression  ->  Verilog expression
#    precedence: ! and ' (highest), ^, & * space, + | (lowest)
# ---------------------------------------------------------------------
EXPR_TOK = re.compile(r"\s*([A-Za-z_][A-Za-z0-9_\[\]\.]*|[01]|[!'\^\*&\+\|\(\)])")


class ExprError(Exception):
    pass


def tokenize_expr(s):
    toks = []
    pos = 0
    s = s.strip()
    while pos < len(s):
        m = EXPR_TOK.match(s, pos)
        if m is None:
            if s[pos:].strip() == '':
                break
            raise ExprError('cannot parse "%s" near "%s"' % (s, s[pos:]))
        toks.append(m.group(1))
        pos = m.end()
    return toks


class ExprParser(object):
    def __init__(self, s, rename):
        self.toks = tokenize_expr(s)
        self.i = 0
        self.rename = rename
        self.names = []

    def peek(self):
        if self.i < len(self.toks):
            return self.toks[self.i]
        return None

    def take(self):
        t = self.peek()
        self.i += 1
        return t

    def parse(self):
        if not self.toks:
            raise ExprError('empty expression')
        e = self.or_expr()
        if self.peek() is not None:
            raise ExprError('unexpected "%s"' % self.peek())
        return e

    def or_expr(self):
        e = self.and_expr()
        while self.peek() in ('+', '|'):
            self.take()
            e = '(%s | %s)' % (e, self.and_expr())
        return e

    def starts_operand(self, t):
        return t is not None and (t == '(' or t == '!' or re.match(r'[A-Za-z_01]', t) is not None)

    def and_expr(self):
        e = self.xor_expr()
        while True:
            t = self.peek()
            if t in ('*', '&'):
                self.take()
                e = '(%s & %s)' % (e, self.xor_expr())
            elif self.starts_operand(t):          # implicit AND (space)
                e = '(%s & %s)' % (e, self.xor_expr())
            else:
                return e

    def xor_expr(self):
        e = self.unary()
        while self.peek() == '^':
            self.take()
            e = '(%s ^ %s)' % (e, self.unary())
        return e

    def unary(self):
        if self.peek() == '!':
            self.take()
            return '(~%s)' % self.unary()
        e = self.primary()
        while self.peek() == "'":
            self.take()
            e = '(~%s)' % e
        return e

    def primary(self):
        t = self.take()
        if t is None:
            raise ExprError('expression ends too early')
        if t == '(':
            e = self.or_expr()
            if self.take() != ')':
                raise ExprError('missing )')
            return e
        if t == '0':
            return "1'b0"
        if t == '1':
            return "1'b1"
        if re.match(r'[A-Za-z_]', t):
            name = self.rename.get(t, t)
            if name not in self.names:
                self.names.append(name)
            return vname(name)
        raise ExprError('unexpected "%s"' % t)


def lib2v(expr, rename=None):
    return ExprParser(expr, rename or {}).parse()


VERILOG_KEYWORDS = set(('always and assign begin buf bufif0 bufif1 case casex casez cmos deassign '
                        'default defparam disable edge else end endcase endfunction endmodule '
                        'endprimitive endspecify endtable endtask event for force forever fork '
                        'function highz0 highz1 if ifnone initial inout input integer join large '
                        'macromodule medium module nand negedge nmos nor not notif0 notif1 or '
                        'output parameter pmos posedge primitive pull0 pull1 pulldown pullup '
                        'rcmos real realtime reg release repeat rnmos rpmos rtran rtranif0 '
                        'rtranif1 scalared small specify specparam strong0 strong1 supply0 '
                        'supply1 table task time tran tranif0 tranif1 tri tri0 tri1 triand '
                        'trior trireg vectored wait wand weak0 weak1 while wire wor xnor xor').split())


def vname(n):
    if n in VERILOG_KEYWORDS or not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', n):
        return '\\' + n + ' '
    return n


def edge_of(expr):
    """'CK' -> ('posedge','CK');  '!CKN' / "CKN'" -> ('negedge','CKN'); else None."""
    s = expr.replace(' ', '')
    while s.startswith('(') and s.endswith(')'):
        s = s[1:-1]
    m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)$', s)
    if m:
        return ('posedge', m.group(1))
    m = re.match(r"^!\(?([A-Za-z_][A-Za-z0-9_]*)\)?$", s) or re.match(r"^\(?([A-Za-z_][A-Za-z0-9_]*)\)?'$", s)
    if m:
        return ('negedge', m.group(1))
    return None


# ---------------------------------------------------------------------
#  Library model
# ---------------------------------------------------------------------
class Pin(object):
    def __init__(self, name, attrs, timings):
        self.name = name
        self.attrs = attrs
        self.direction = attrs.get('direction', 'input')
        self.function = attrs.get('function')
        self.three_state = attrs.get('three_state')
        self.timings = timings                   # list of attr dicts


class Cell(object):
    def __init__(self, name, start, end):
        self.name = name
        self.start = start                       # body start
        self.end = end                           # index of closing brace
        self.pins = []
        self.ff = None                           # (vars, attrs)
        self.latch = None
        self.statetable = False
        self.has_test_cell = False

    def pin(self, name):
        for p in self.pins:
            if p.name == name:
                return p
        return None


def load_library(path):
    text = read_text(path)
    top = parse_block(text, 0, len(text))
    libs = groups_of(top, 'library')
    if not libs:
        raise SystemExit('ERROR: no library() group found in %s' % path)
    lib = libs[0]
    libname = lib[2]
    lib_items = parse_block(text, lib[3], lib[4])
    cells = []
    for g in groups_of(lib_items, 'cell'):
        cell = Cell(g[2], g[3], g[4])
        citems = parse_block(text, g[3], g[4])
        for it in citems:
            if it[0] != 'group':
                continue
            gname = it[1]
            if gname == 'pin':
                pitems = parse_block(text, it[3], it[4])
                timings = []
                for t in groups_of(pitems, 'timing'):
                    timings.append(attrs_of(parse_block(text, t[3], t[4])))
                for pname in [x.strip() for x in it[2].split(',') if x.strip()]:
                    cell.pins.append(Pin(pname, attrs_of(pitems), timings))
            elif gname in ('ff', 'latch'):
                vars_ = [x.strip() for x in it[2].split(',') if x.strip()]
                gattrs = attrs_of(parse_block(text, it[3], it[4]))
                if gname == 'ff':
                    cell.ff = (vars_, gattrs)
                else:
                    cell.latch = (vars_, gattrs)
            elif gname == 'statetable':
                cell.statetable = True
            elif gname == 'test_cell':
                cell.has_test_cell = True
        cells.append(cell)
    return text, libname, cells


# ---------------------------------------------------------------------
#  verilog mode
# ---------------------------------------------------------------------
CPV = {'L': "1'b0", 'H': "1'b1", 'X': "1'bx"}


def cpv_value(v, var):
    v = (v or 'X').strip().upper()
    if v == 'N':
        return vname(var)
    if v == 'T':
        return '~' + vname(var)
    return CPV.get(v, "1'bx")


def seq_assign(vars_, value_q, value_qn, blocking):
    op = '=' if blocking else '<='
    parts = ['%s %s %s;' % (vname(vars_[0]), op, value_q)]
    if len(vars_) > 1:
        parts.append('%s %s %s;' % (vname(vars_[1]), op, value_qn))
    return 'begin ' + ' '.join(parts) + ' end'


def event_for(expr, label, lines, active_high_edge):
    """Return a sensitivity item for a clock/clear/preset expression."""
    e = edge_of(expr)
    if e is not None:
        if not active_high_edge:
            # for clear/preset the edge that ASSERTS the signal
            return '%s %s' % (e[0], vname(e[1]))
        return '%s %s' % (e[0], vname(e[1]))
    wname = 'cdn_' + label
    lines.append('  wire %s = %s;' % (wname, lib2v(expr)))
    return 'posedge ' + wname


def ff_block(cell, lines, warns):
    vars_, a = cell.ff
    ns = a.get('next_state')
    clk = a.get('clocked_on')
    if ns is None or clk is None:
        warns.append('%s: ff without next_state/clocked_on - modelled as X' % cell.name)
        return False
    lines.append('  reg %s;' % ', '.join([vname(v) for v in vars_]))
    sens = [event_for(clk, 'clk', lines, True)]
    clr = a.get('clear')
    pre = a.get('preset')
    if clr:
        sens.append(event_for(clr, 'clr', lines, False))
    if pre:
        sens.append(event_for(pre, 'pre', lines, False))
    nsv = lib2v(ns)
    lines.append('  always @(%s) begin' % ' or '.join(sens))
    first = True
    if clr and pre:
        lines.append('    if (%s && %s) %s' % (lib2v(clr), lib2v(pre), seq_assign(
            vars_, cpv_value(a.get('clear_preset_var1'), vars_[0]),
            cpv_value(a.get('clear_preset_var2'), vars_[-1]), False)))
        first = False
    if clr:
        lines.append('    %sif (%s) %s' % ('' if first else 'else ', lib2v(clr),
                                          seq_assign(vars_, "1'b0", "1'b1", False)))
        first = False
    if pre:
        lines.append('    %sif (%s) %s' % ('' if first else 'else ', lib2v(pre),
                                          seq_assign(vars_, "1'b1", "1'b0", False)))
        first = False
    body = seq_assign(vars_, nsv, '~' + nsv, False)
    if first:
        lines.append('    ' + body)
    else:
        lines.append('    else ' + body)
    lines.append('  end')
    return True


def latch_block(cell, lines, warns):
    vars_, a = cell.latch
    en = a.get('enable')
    d = a.get('data_in')
    if en is None or d is None:
        warns.append('%s: latch without enable/data_in - modelled as X' % cell.name)
        return False
    lines.append('  reg %s;' % ', '.join([vname(v) for v in vars_]))
    clr = a.get('clear')
    pre = a.get('preset')
    dv = lib2v(d)
    lines.append('  always @(*) begin')
    first = True
    if clr and pre:
        lines.append('    if (%s && %s) %s' % (lib2v(clr), lib2v(pre), seq_assign(
            vars_, cpv_value(a.get('clear_preset_var1'), vars_[0]),
            cpv_value(a.get('clear_preset_var2'), vars_[-1]), True)))
        first = False
    if clr:
        lines.append('    %sif (%s) %s' % ('' if first else 'else ', lib2v(clr),
                                          seq_assign(vars_, "1'b0", "1'b1", True)))
        first = False
    if pre:
        lines.append('    %sif (%s) %s' % ('' if first else 'else ', lib2v(pre),
                                          seq_assign(vars_, "1'b1", "1'b0", True)))
        first = False
    lines.append('    %sif (%s) %s' % ('' if first else 'else ', lib2v(en),
                                      seq_assign(vars_, dv, '~' + dv, True)))
    lines.append('  end')
    return True


SKIP_TIMING = re.compile(r'^(setup|hold|recovery|removal|skew|non_seq|nochange|min_pulse|minimum_period|max_clock)')


def specify_lines(cell, inputs, outputs):
    paths = []
    seen = set()

    def add(line):
        if line not in seen:
            seen.add(line)
            paths.append(line)

    for p in cell.pins:
        if p.name not in outputs:
            continue
        uncond = set()
        conds = {}
        for t in p.timings:
            ttype = t.get('timing_type', 'combinational')
            if SKIP_TIMING.match(ttype):
                continue
            sense = t.get('timing_sense', '')
            cond = t.get('sdf_cond')
            if not cond and t.get('when'):
                try:
                    cond = lib2v(t.get('when'))
                except ExprError:
                    cond = None
            for src in t.get('related_pin', '').replace('"', '').split():
                if src not in inputs:
                    continue
                edge = None
                if ttype == 'rising_edge':
                    edge = 'posedge'
                elif ttype == 'falling_edge':
                    edge = 'negedge'
                elif ttype == 'clear':
                    edge = {'positive_unate': 'negedge', 'negative_unate': 'posedge'}.get(sense)
                elif ttype == 'preset':
                    edge = {'positive_unate': 'posedge', 'negative_unate': 'negedge'}.get(sense)
                key = (edge, src)
                if edge:
                    core = '(%s %s => (%s : %s))' % (edge, vname(src), vname(p.name), vname(src))
                    add('    %s = (0, 0);' % core)          # always keep an unconditional edge path
                    if cond:
                        add('    if (%s) %s = (0, 0);' % (cond, core))
                else:
                    core = '(%s => %s)' % (vname(src), vname(p.name))
                    if cond:
                        conds.setdefault(key, []).append(cond)
                    else:
                        uncond.add(key)
        for key in conds:
            core = '(%s => %s)' % (vname(key[1]), vname(p.name))
            for c in conds[key]:
                add('    if (%s) %s = (0, 0);' % (c, core))
            if key not in uncond:
                add('    ifnone %s = (0, 0);' % core)
        for key in uncond:
            add('    (%s => %s) = (0, 0);' % (vname(key[1]), vname(p.name)))
    return paths


def cell_module(cell, warns, with_specify):
    ports = [p for p in cell.pins if p.direction in ('input', 'output', 'inout')]
    inputs = [p.name for p in ports if p.direction in ('input', 'inout')]
    outputs = [p.name for p in ports if p.direction in ('output', 'inout')]
    lines = []
    lines.append('`celldefine')
    lines.append('module %s (%s);' % (cell.name, ', '.join([vname(p.name) for p in ports])))
    for p in ports:
        lines.append('  %s %s;' % (p.direction, vname(p.name)))
    seq_ok = True
    seq_vars = []
    if cell.ff is not None:
        seq_vars = cell.ff[0]
    elif cell.latch is not None:
        seq_vars = cell.latch[0]
    if cell.ff is not None:
        seq_ok = ff_block(cell, lines, warns)
    elif cell.latch is not None:
        seq_ok = latch_block(cell, lines, warns)
    elif cell.statetable:
        seq_ok = False
        warns.append('%s: statetable cell - outputs modelled as X' % cell.name)
    for p in ports:
        if p.direction == 'input':
            continue
        if p.function is None:
            if p.direction == 'output':
                lines.append("  assign %s = 1'bx;  // no function in .lib" % vname(p.name))
                warns.append('%s: output %s has no function - modelled as X' % (cell.name, p.name))
            continue
        try:
            f = lib2v(p.function)
            known = set([q.name for q in ports] + seq_vars)
            used = [x for x in re.findall(r'[A-Za-z_][A-Za-z0-9_]*', p.function)]
            if (not seq_ok and [x for x in used if x in seq_vars]) or [x for x in used if x not in known]:
                f = "1'bx"
                warns.append('%s: output %s depends on unmodelled state - modelled as X' % (cell.name, p.name))
            if p.three_state:
                lines.append("  assign %s = %s ? 1'bz : %s;" % (vname(p.name), lib2v(p.three_state), f))
            else:
                lines.append('  assign %s = %s;' % (vname(p.name), f))
        except ExprError:
            lines.append("  assign %s = 1'bx;  // unparsed: %s" % (vname(p.name), p.function))
            warns.append('%s: could not parse function of %s' % (cell.name, p.name))
    if with_specify:
        sp = specify_lines(cell, inputs, outputs)
        if sp:
            lines.append('  specify')
            lines.extend(sp)
            lines.append('  endspecify')
    lines.append('endmodule')
    lines.append('`endcelldefine')
    return '\n'.join(lines) + '\n'


def lef_macros(path):
    """{macro: [(pin, direction), ...]} for signal pins of every LEF MACRO."""
    macros = {}
    cur = None
    pin = None
    pdir = 'INPUT'
    puse = 'SIGNAL'
    for raw in read_text(path).splitlines():
        w = raw.split()
        if not w:
            continue
        if w[0] == 'MACRO' and len(w) > 1:
            cur = w[1]
            macros[cur] = []
        elif cur and w[0] == 'PIN' and len(w) > 1:
            pin = w[1]
            pdir = 'INPUT'
            puse = 'SIGNAL'
        elif cur and pin and w[0] == 'DIRECTION' and len(w) > 1:
            pdir = w[1]
        elif cur and pin and w[0] == 'USE' and len(w) > 1:
            puse = w[1]
        elif cur and w[0] == 'END' and len(w) > 1:
            if pin and w[1] == pin:
                if puse.rstrip(';') not in ('POWER', 'GROUND'):
                    macros[cur].append((pin, pdir.rstrip(';').lower()))
                pin = None
            elif w[1] == cur:
                cur = None
    return macros


def do_verilog(lib_path, out_path, lef_path=None):
    text, libname, cells = load_library(lib_path)
    warns = []
    out = []
    out.append('// ' + '=' * 70)
    out.append('// Behavioural Verilog models generated from %s' % lib_path)
    out.append('// Library: %s   cells: %d' % (libname, len(cells)))
    out.append('// Generated by scripts/gpdk045_libtool.py - functional models with')
    out.append('// zero-delay specify paths (annotated by SDF); no timing checks.')
    out.append('// ' + '=' * 70)
    out.append('`timescale 1ns/1ps')
    out.append('')
    names = set()
    for c in cells:
        out.append(cell_module(c, warns, True))
        names.add(c.name)
    extra = 0
    if lef_path:
        for m, pins in sorted(lef_macros(lef_path).items()):
            if m in names:
                continue
            out.append('`celldefine')
            if pins:
                out.append('module %s (%s);  // physical-only LEF macro' % (m, ', '.join([vname(p[0]) for p in pins])))
            else:
                out.append('module %s;  // physical-only LEF macro (no signal pins)' % m)
            for pn, pd in pins:
                d = pd if pd in ('output', 'inout') else 'input'
                out.append('  %s %s;' % (d, vname(pn)))
            out.append('endmodule')
            out.append('`endcelldefine')
            out.append('')
            extra += 1
    write_text(out_path, '\n'.join(out) + '\n')
    nseq = len([c for c in cells if c.ff is not None])
    nlat = len([c for c in cells if c.latch is not None])
    print('verilog: library %s, %d cells read from %s' % (libname, len(cells), lib_path))
    print('verilog: %d flip-flop cells, %d latch cells, %d combinational cells'
          % (nseq, nlat, len(cells) - nseq - nlat))
    if lef_path:
        print('verilog: %d physical-only LEF macros added as empty modules' % extra)
    print('verilog: %d warnings' % len(warns))
    for w in warns[:40]:
        print('  WARNING: ' + w)
    print('verilog: wrote %s' % out_path)


# ---------------------------------------------------------------------
#  scan mode
# ---------------------------------------------------------------------
QUOTED = ('next_state', 'clocked_on', 'clocked_on_also', 'clear', 'preset')
SCAN_NAME = re.compile(r'^SDFF')
SCAN_SKIP = re.compile(r'^SDFFTR')       # synchronous-reset scan flops: next_state is not just D


def test_cell_text(cell):
    vars_, a = cell.ff
    out = []
    out.append('    test_cell () {')
    for p in cell.pins:
        if p.direction != 'input':
            continue
        extra = ''
        if p.name == 'SI':
            extra = ' signal_type : test_scan_in ;'
        elif p.name == 'SE':
            extra = ' signal_type : test_scan_enable ;'
        out.append('      pin (%s) { direction : input ;%s }' % (p.name, extra))
    ffa = []
    ffa.append('next_state : "D" ;')
    for k in ('clocked_on', 'clocked_on_also', 'clear', 'preset', 'clear_preset_var1', 'clear_preset_var2'):
        if k in a:
            if k in QUOTED:
                ffa.append('%s : "%s" ;' % (k, a[k]))
            else:
                ffa.append('%s : %s ;' % (k, a[k]))
    out.append('      ff (%s) { %s }' % (','.join(vars_), ' '.join(ffa)))
    for p in cell.pins:
        if p.direction != 'output':
            continue
        f = (p.function or '').replace(' ', '').replace('(', '').replace(')', '')
        if f == vars_[0]:
            st = 'test_scan_out'
        elif len(vars_) > 1 and f == vars_[1]:
            st = 'test_scan_out_inverted'
        else:
            return None
        out.append('      pin (%s) { direction : output ; function : "%s" ; signal_type : %s ; }'
                   % (p.name, f, st))
    out.append('    }')
    return '\n'.join(out) + '\n  '


def do_scan(lib_path, out_path):
    text, libname, cells = load_library(lib_path)
    inserts = []
    done = []
    skipped = []
    for c in cells:
        if not SCAN_NAME.match(c.name):
            continue
        why = None
        if SCAN_SKIP.match(c.name):
            why = 'synchronous reset (next_state is not D)'
        elif c.has_test_cell:
            why = 'already has a test_cell'
        elif c.ff is None:
            why = 'no ff group'
        elif c.pin('SE') is None or c.pin('SI') is None or c.pin('D') is None:
            why = 'missing D/SI/SE pin'
        tc = None
        if why is None:
            tc = test_cell_text(c)
            if tc is None:
                why = 'output function is not IQ/IQN'
        if why:
            skipped.append('%s (%s)' % (c.name, why))
            continue
        # insert just before the closing brace of the cell
        q = c.end
        while q > c.start and text[q - 1] in ' \t':
            q -= 1
        inserts.append((q, tc))
        done.append(c.name)
    pieces = []
    last = 0
    for pos, t in sorted(inserts):
        pieces.append(text[last:pos])
        pieces.append(t)
        last = pos
    pieces.append(text[last:])
    new = ''.join(pieces)
    # sanity: the new file must still parse
    match_brace(new, new.index('{', new.find('library')))
    write_text(out_path, new)
    print('scan: library %s, %d cells read from %s' % (libname, len(cells), lib_path))
    print('scan: test_cell added to %d scan flops:' % len(done))
    for i in range(0, len(done), 8):
        print('   ' + ' '.join(done[i:i + 8]))
    print('scan: %d SDFF cells left unchanged:' % len(skipped))
    for s in skipped:
        print('   ' + s)
    print('scan: wrote %s' % out_path)


# ---------------------------------------------------------------------
def main(argv):
    if len(argv) >= 4 and argv[1] == 'verilog':
        lef = None
        if len(argv) >= 5:
            lef = argv[4]
        do_verilog(argv[2], argv[3], lef)
    elif len(argv) >= 4 and argv[1] == 'scan':
        do_scan(argv[2], argv[3])
    else:
        sys.stderr.write(__doc__ or '')
        sys.stderr.write('usage:\n  python gpdk045_libtool.py verilog <in.lib> <out.v> [cells.lef]\n'
                         '  python gpdk045_libtool.py scan    <in.lib> <out.lib>\n')
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
