#!/usr/bin/env python3
"""
check_vga_test.py - checks the bring-up step 1 test pictures (bringup/step1_vga/vga_pattern.v)
pixel by pixel against an independent model, and writes PNGs.

    python3 scripts/check_vga_test.py [build/vga_test]

The .hex files come from sim/tb_vga_test.v (run_sims.sh stage 7).
"""
import os, sys

D = sys.argv[1] if len(sys.argv) > 1 else 'build/vga_test'
BARS = [0xFFF, 0xFF0, 0x0FF, 0x0F0, 0xF0F, 0xF00, 0x00F, 0x000]

def model(sel, x, y, invert=False):
    cx, cy, ix, iy = x // 40, y // 40, x % 40, y % 40
    if sel == 0:
        c = 0xF00 if x in (0, 639) or y in (0, 479) else (0x000 if (cx ^ cy) & 1 else 0xFFF)
    elif sel == 1:
        c = BARS[cx // 2] if y < 320 else cx * 0x111
    elif sel == 2:
        c = [cx << 8, cx << 4, cx, cx * 0x111][min(y // 120, 3)]
    else:
        c = 0xFFF if ix == 0 or iy == 0 or x == 639 or y == 479 or x == 320 or y == 240 else 0x000
    return c ^ 0xFFF if invert else c

cases = [(0, 0, False, 'checkerboard'), (1, 1, False, 'colour bars + grey ramp'), (2, 2, False, 'DAC ramps'),
         (3, 3, False, 'grid'), (4, 0, True, 'inverted checkerboard')]
bad = 0
for n, sel, inv, name in cases:
    px = [int(l, 16) for l in open(f'{D}/pattern_{n}.hex').read().split()]
    if len(px) != 640 * 480:
        print(f'pattern {n}: {len(px)} pixels'); bad += 1; continue
    wrong = sum(1 for i, p in enumerate(px) if p != model(sel, i % 640, i // 640, inv))
    print(f'pattern {n} ({name:24s}): {"OK" if not wrong else str(wrong) + " pixels differ"}')
    bad += wrong != 0
    try:
        from PIL import Image
        im = Image.new('RGB', (640, 480))
        im.putdata([(((p >> 8) & 15) * 17, ((p >> 4) & 15) * 17, (p & 15) * 17) for p in px])
        im.save(f'{D}/pattern_{n}.png')
    except ImportError:
        pass
print('RESULT:', 'ALL 5 PICTURES MATCH THE MODEL' if not bad else f'{bad} PROBLEM(S)')
sys.exit(1 if bad else 0)
