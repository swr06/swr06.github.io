#!/usr/bin/env python3
"""
check_pins.py - cross-checks every pin / connection in the project.

    cd ~/asic_projects/raster_gpu
    python3 scripts/check_pins.py

  A. FPGA   : every fpga_top port bit is constrained exactly once in the XDC,
              no pin is used twice, every pin is a real PYNQ-Z2 pin with the
              connector label written in the XDC comment
  B. Arduino: the sketch pins + the XDC header sockets form the wiring table;
              the on-board test host drives the SPI header (loopback wires)
  C. Macro  : pin_order.cfg places every gpu_asic signal port exactly once
  D. Chip   : every GPIO pad in chip_top.v is configured for its direction
              (DM / OE_N / INP_DIS), drives / is driven by the right macro
              pin, has its own tie_lo[] index, and is enabled by power-good
  E. Layout : 01_floorplan.tcl places every pad once, on the same die side as
              the macro pin it is wired to
  F. Electr.: divider level + rise time, READY level at the Uno, VGA DAC
              level and why the ASIC board needs a buffer after the pads
  G. ROM    : fpga/selftest.mem has the size of the test host ROM and 6 tests
Exit code 0 = everything consistent.
"""
import os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p): return open(os.path.join(ROOT, p), encoding='utf-8').read()
errors = []
def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond: errors.append(msg)

# Official PYNQ-Z2 PL pins and their board labels (PYNQ-Z2 reference manual,
# tables 16-19, and the base overlay constraints). The Arduino header sockets
# are labelled AR0..AR13 on the PYNQ-Z2 (not D0..D13 as on an Uno).
PYNQ = {'H16': 'sysclk', 'D19': 'BTN0', 'D20': 'BTN1', 'L20': 'BTN2', 'L19': 'BTN3', 'M20': 'SW0', 'M19': 'SW1',
        'R14': 'LD0', 'P14': 'LD1', 'N16': 'LD2', 'M14': 'LD3',
        # PMOD labels: <connector>-<physical pin> (the manual's names in brackets in the XDC)
        'Y18': 'JA-1', 'Y19': 'JA-2', 'Y16': 'JA-3', 'Y17': 'JA-4', 'U18': 'JA-7', 'U19': 'JA-8', 'W18': 'JA-9', 'W19': 'JA-10',
        'W14': 'JB-1', 'Y14': 'JB-2', 'T11': 'JB-3', 'T10': 'JB-4', 'V16': 'JB-7', 'W16': 'JB-8', 'V12': 'JB-9', 'W13': 'JB-10',
        'T14': 'AR0', 'U12': 'AR1', 'U13': 'AR2', 'V13': 'AR3', 'V15': 'AR4', 'T15': 'AR5', 'R16': 'AR6', 'U17': 'AR7',
        'V17': 'AR8', 'V18': 'AR9', 'T16': 'AR10', 'R17': 'AR11', 'P18': 'AR12', 'N17': 'AR13',
        'Y13': 'A', 'P16': 'AR_SDA', 'P15': 'AR_SCL',
        'W15': 'AR_MISO', 'H15': 'AR_SCK', 'T12': 'AR_MOSI', 'F16': 'AR_SS'}

def ports_of(verilog, module):
    """{name: (dir, width)} from an ANSI-style module header."""
    m = re.search(r'module\s+' + module + r'\s*(?:#\(.*?\))?\s*\((.*?)\);', verilog, re.S)
    body = re.sub(r'//[^\n]*', '', m.group(1))
    body = re.sub(r'`ifdef USE_POWER_PINS.*?`endif', '', body, flags=re.S)
    out = {}
    for d, rng, names in re.findall(r'(input|output|inout)\s+(?:wire|reg)?\s*(\[\d+:\d+\])?\s*([\w\s,]+?)(?=,\s*(?:input|output|inout)|$)', body.strip(), re.S):
        w = 1
        if rng:
            a, b = map(int, rng[1:-1].split(':')); w = abs(a - b) + 1
        for n in [x.strip() for x in names.split(',') if x.strip()]:
            out[n] = (d, w)
    return out

# ======================================================================= A
print('\n[A] FPGA: fpga_top.v <-> pynq_gpu.xdc')
top = ports_of(rd('fpga/fpga_top.v'), 'fpga_top')
xdc = rd('fpga/pynq_gpu.xdc')
cons = re.findall(r'PACKAGE_PIN\s+(\w+).*?get_ports\s+\{?([\w\[\]]+)\}?\]\s*(?:;#\s*(\S+))?', xdc)
bits_needed = {f'{n}[{i}]' if w > 1 else n for n, (d, w) in top.items() for i in range(w)}
bits_have = [p for _, p, _ in cons]
check(sorted(bits_needed) == sorted(set(bits_have)) and len(bits_have) == len(set(bits_have)),
      f'all {len(bits_needed)} port bits constrained exactly once')
pins = [pin for pin, _, _ in cons]
check(len(pins) == len(set(pins)), 'no FPGA pin used twice')
for pin, port, cmt in cons:
    lab = PYNQ.get(pin)
    check(lab is not None and (not cmt or cmt == lab), f'{port:11s} -> {pin:4s} = {lab}' + (f' (comment {cmt})' if cmt else ''))

# PMOD pins: the manual's P/N signal name in brackets must match the physical pin
# (manual tables 13/14: pins 1/2 = J?1_P/N, 3/4 = J?2_P/N, 7/8 = J?3_P/N, 9/10 = J?4_P/N)
PAIR = {1: '1_P', 2: '1_N', 3: '2_P', 4: '2_N', 7: '3_P', 8: '3_N', 9: '4_P', 10: '4_N'}
pm = re.findall(r';#\s*(J[AB])-(\d+)\s*\((J[AB]\d_[PN])\)', xdc)
check(len(pm) == 14 and all(nm == c + PAIR[int(n)] for c, n, nm in pm),
      f'{len(pm)} PMOD comments: physical pin <-> manual name (e.g. JA-2 = JA1_N) all consistent')

# ======================================================================= B
print('\n[B] Arduino sketch <-> PYNQ Arduino header')
ino = rd('arduino/gpu_demo/gpu_demo.ino')
cs = int(re.search(r'const\s+\w+\s+PIN_CS\s*=\s*(\d+)', ino).group(1))
rdy = int(re.search(r'const\s+\w+\s+PIN_READY\s*=\s*(\d+)', ino).group(1))
sock = {port: PYNQ[pin] for pin, port, _ in cons if re.fullmatch(r'AR\d+', PYNQ.get(pin, ''))}
wiring = [('D13 (hw SCK)', sock['spi_sck'], 'spi_sck'), ('D11 (hw MOSI)', sock['spi_mosi'], 'spi_mosi'),
          (f'D{cs} (CS)', sock['spi_cs_n'], 'spi_cs_n'), (f'D{rdy} (READY in)', sock['gpu_ready'], 'gpu_ready')]
for a, s, sig in wiring:
    print(f'         Uno {a:15s} <-> PYNQ-Z2 {s:5s}  {sig}')
check(cs == 10 and rdy not in (10, 11, 12, 13), 'sketch CS = Uno D10 (SS) and READY on a free GPIO (D8)')
check(sock['spi_cs_n'] == 'AR10' and sock['spi_mosi'] == 'AR11' and sock['spi_sck'] == 'AR13',
      'PYNQ-Z2 side uses the shield SPI sockets AR10 / AR11 / AR13 (same positions as Uno D10 / D11 / D13)')

# on-board test host: drives the 2x3 SPI header, loopback wires go to the AR sockets
hdr = {port: PYNQ[pin] for pin, port, _ in cons if PYNQ.get(pin, '').startswith('AR_')}
loop = [('test_cs_n', 'spi_cs_n'), ('test_sck', 'spi_sck'), ('test_mosi', 'spi_mosi')]
for src, dst in loop:
    print(f'         loopback wire: {hdr.get(src, "?"):7s} ({src}) -> {sock[dst]:4s} ({dst})')
check(hdr.get('test_cs_n') == 'AR_SS' and hdr.get('test_sck') == 'AR_SCK' and hdr.get('test_mosi') == 'AR_MOSI',
      'test host SPI goes out on the SPI header AR_SS / AR_SCK / AR_MOSI')

# ======================================================================= C
print('\n[C] gpu_asic ports <-> pin_order.cfg')
asic = ports_of(rd('asic/src/gpu_asic.v'), 'gpu_asic')
cfg = rd('asic/pin_order.cfg')
side, side_of = None, {}
for line in cfg.splitlines():
    line = line.strip()
    if line.startswith('#'): side = line[1]; continue
    if line: side_of.setdefault(line.replace('\\', ''), side)
asic_bits = {f'{n}[{i}]' if w > 1 else n for n, (d, w) in asic.items() for i in range(w)}
check(set(side_of) == asic_bits, f'all {len(asic_bits)} macro pins placed exactly once')
for b in sorted(asic_bits):
    print(f'         {b:12s} side {side_of.get(b)}')

# ======================================================================= D
print('\n[D] chip_top.v pad configuration and macro hookup')
exp = subprocess.run(['iverilog', '-E', '-o', '-', os.path.join(ROOT, 'chip/rtl/chip_top.v')],
                     capture_output=True, text=True, check=True).stdout
INST_RE = r'(sky130_ef_io__\w+|sky130_fd_sc_hd__conb_1|gpu_asic)\s+(\w+)\s*\((.*?)\);'
insts = {i: (c, b) for c, i, b in re.findall(INST_RE, exp, re.S)}
def conns(body):
    return {p: re.sub(r'\s+', '', v) for p, v in re.findall(r'\.(\w+)\s*\(([^()]*)\)', body)}
core = conns(insts['u_core'][1])
net2pin = {}
for p, v in core.items():                      # expand buses: .vga_rgb(rgb) -> rgb[i] = vga_rgb[i]
    w = asic.get(p, ('', 1))[1]
    if w > 1:
        for i in range(w): net2pin[f'{v}[{i}]'] = f'{p}[{i}]'
    else:
        net2pin[v] = p
gpios = {i: conns(b) for i, (c, b) in insts.items() if c == 'sky130_ef_io__gpiov2_pad_wrapped' and i != 'u_power_good'}
check(len(gpios) == 11, f'{len(gpios)} signal GPIOs (+ u_power_good)')
ties = []
pad_to_macro = {}
for name, c in sorted(gpios.items()):
    is_out = c.get('OUT') not in (None, 'cfg_lo')
    net = c['OUT'] if is_out else c['IN']
    mpin = net2pin.get(net)
    want_dir = 'output' if is_out else 'input'
    mdir = asic.get(re.sub(r'\[\d+\]', '', mpin or ''), ('?',))[0]
    cfg_ok = (c['DM'] == '{cfg_hi,cfg_hi,cfg_lo}' and c['OE_N'] == 'cfg_lo' and c['INP_DIS'] == 'cfg_hi') if is_out else \
             (c['DM'] == '{cfg_lo,cfg_lo,cfg_hi}' and c['OE_N'] == 'cfg_hi' and c['INP_DIS'] == 'cfg_lo')
    en_ok = c['ENABLE_H'] == 'por_h' and c['ENABLE_VDDIO'] == 'por_lv'
    tie = c['TIE_LO_ESD']; ties.append(tie)
    tie_ok = c['ENABLE_INP_H'] == tie and c['ENABLE_VDDA_H'] == tie and c['ENABLE_VSWITCH_H'] == tie
    pad_to_macro[name] = mpin or '?'
    check(mpin is not None and mdir == want_dir and cfg_ok and en_ok and tie_ok,
          f'{name:8s} {"OUT" if is_out else "IN ":3s} {c["PAD"]:12s} <-> macro {mpin}  (DM {c["DM"]})')
check(len(set(ties)) == len(ties), 'every GPIO uses its own tie_lo[] index')
pg = conns(insts['u_power_good'][1])
check(pg['IN_H'] == 'por_h' and pg['IN'] == 'por_lv' and pg['ENABLE_INP_H'] == pg['TIE_HI_ESD'],
      'u_power_good drives por_h / por_lv and keeps its own input enabled')
check(core.get('VPWR') == 'VCCD' and core.get('VGND') == 'VSSD', 'macro VPWR/VGND -> VCCD/VSSD')
supplies = {i: c for i, (c, b) in insts.items() if 'clamped_pad' in c}
check(len(supplies) == 6, f'{len(supplies)} supply pads: ' + ' '.join(sorted(supplies)))

# ======================================================================= E
print('\n[E] 01_floorplan.tcl pad sides <-> macro pin sides')
fp = rd('chip/tcl/01_floorplan.tcl')
rows = {s: l.split() for s, l in re.findall(r'^place_pads\s+-row\s+IO_(\w+)\s+-mode\s+uniform\s+\{([^}]*)\}', fp, re.M)}
placed = [p for l in rows.values() for p in l]
all_pads = [i for i, (c, b) in insts.items() if c.startswith('sky130_ef_io__')]
check(sorted(placed) == sorted(all_pads), f'all {len(all_pads)} pads placed exactly once')
S = {'NORTH': 'N', 'SOUTH': 'S', 'EAST': 'E', 'WEST': 'W'}
for row, pads in rows.items():
    for p in pads:
        if p in pad_to_macro:
            mside = side_of.get(pad_to_macro[p])
            check(mside == S[row], f'{p:8s} on {row:5s}  <-> macro {pad_to_macro[p]} on side {mside}')

# ======================================================================= F
print('\n[F] Electrical: level dividers (FPGA) and VGA DAC (ASIC board)')
v_div = 5.0 * 3.3 / (2.2 + 3.3)                       # Uno 5 V -> PYNQ 3.3 V input
check(2.0 <= v_div <= 3.4, f'divider 2.2k/3.3k: 5 V -> {v_div:.2f} V (VIH >= 2.0 V; PYNQ-Z2 header: 3.4 V recommended max, 3.75 V abs. max)')
r_th = 2.2e3 * 3.3e3 / (2.2e3 + 3.3e3); t_r = 2.2 * r_th * 10e-12
check(t_r < 0.25 * 0.5 / 2e6, f'divider source {r_th:.0f} ohm, 10-90 % rise {t_r*1e9:.0f} ns << 250 ns SCK half period')
check(3.3 >= 0.6 * 5.0, 'READY 3.3 V >= ATmega328P VIH (0.6 x 5 V = 3.0 V)')
v = 3.3 * 75 / (270 + 75); i = 3.3 / (270 + 75)
check(0.6 <= v <= 0.75, f'3.3 V through 270 ohm into 75 ohm = {v:.3f} V (VGA full scale 0.7 V)')
check(i > 4e-3 and i < 24e-3, f'DAC current {i*1e3:.1f} mA: above the 4 mA GPIO pad rating -> driven by a 74LVC244A (24 mA)')

print('\n[G] on-board test ROM (fpga/selftest.mem)')
words = [int(l, 16) for l in rd('fpga/selftest.mem').split()]
tests = 0; cmd = 0; ok_ops = True
for w in words:
    if w == 0:
        if cmd: tests += 1
        cmd = 0
    else:
        cmd += 1
        ok_ops &= (w >> 72) in (1, 2, 3, 4, 5)
check(len(words) == 256, f'{len(words)} words = ROM_DEPTH of spi_test_host.v')
check(tests == 6 and ok_ops, f'{tests} tests, every command has a valid opcode (BTN1..3 x SW1 = 6 tests)')
print('\nRESULT:', 'ALL CONNECTIONS CONSISTENT' if not errors else f'{len(errors)} PROBLEM(S)')
sys.exit(1 if errors else 0)
