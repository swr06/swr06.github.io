#!/usr/bin/env python3
"""
check_pins.py - cross-checks every pin / connection in the project.

    cd ~/asic_projects/raster_gpu
    python3 scripts/check_pins.py

  A. FPGA   : every fpga_top port bit is constrained exactly once in the XDC,
              no pin is used twice, every pin is a real PYNQ-Z2 pin with the
              connector label written in the XDC comment
  B. Arduino: the sketch pins + the XDC header sockets form the wiring table
  C. Macro  : pin_order.cfg places every gpu_asic signal port exactly once
  D. Chip   : every GPIO pad in chip_top.v is configured for its direction
              (DM / OE_N / INP_DIS), drives / is driven by the right macro
              pin, has its own tie_lo[] index, and is enabled by power-good
  E. Layout : 01_floorplan.tcl places every pad once, on the same die side as
              the macro pin it is wired to
  F. Electr.: divider level + rise time, READY level at the Uno, VGA DAC
              level and why the ASIC board needs a buffer after the pads
Exit code 0 = everything consistent.
"""
import os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def rd(p): return open(os.path.join(ROOT, p), encoding='utf-8').read()
errors = []
def check(cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + msg)
    if not cond: errors.append(msg)

# Official PYNQ-Z2 PL pins (from the PYNQ-Z2 base overlay constraints)
PYNQ = {'H16': 'sysclk', 'D19': 'BTN0', 'D20': 'BTN1', 'L20': 'BTN2', 'L19': 'BTN3', 'M20': 'SW0', 'M19': 'SW1',
        'R14': 'LD0', 'P14': 'LD1', 'N16': 'LD2', 'M14': 'LD3',
        'Y18': 'JA1', 'Y19': 'JA2', 'Y16': 'JA3', 'Y17': 'JA4', 'U18': 'JA7', 'U19': 'JA8', 'W18': 'JA9', 'W19': 'JA10',
        'W14': 'JB1', 'Y14': 'JB2', 'T11': 'JB3', 'T10': 'JB4', 'V16': 'JB7', 'W16': 'JB8', 'V12': 'JB9', 'W13': 'JB10',
        'T14': 'D0', 'U12': 'D1', 'U13': 'D2', 'V13': 'D3', 'V15': 'D4', 'T15': 'D5', 'R16': 'D6', 'U17': 'D7',
        'V17': 'D8', 'V18': 'D9', 'T16': 'D10', 'R17': 'D11', 'P18': 'D12', 'N17': 'D13'}

def ports_of(verilog, module):
    """{name: (dir, width)} from an ANSI-style module header."""
    m = re.search(r'module\s+' + module + r'\s*(?:#\(.*?\))?\s*\((.*?)\);', verilog, re.S)
    body = re.sub(r'//[^\n]*', '', m.group(1))
    body = re.sub(r'`ifdef USE_POWER_PINS.*?`endif', '', body, flags=re.S)
    out = {}
    for d, rng, names in re.findall(r'(input|output|inout)\s+(?:wire|reg)?\s*(\[\d+:\d+\])?\s*([\w\s,]+?)(?=,\s*(?:input|output|inout)|$)', body.strip(), re.S):
        w = 1
        if rng:
            a, b = map(int, rng[1:-1].split(':')); w = abs(a - b) + 1
        for n in [x.strip() for x in names.split(',') if x.strip()]:
            out[n] = (d, w)
    return out

# ======================================================================= A
print('\n[A] FPGA: fpga_top.v <-> pynq_gpu.xdc')
top = ports_of(rd('fpga/fpga_top.v'), 'fpga_top')
xdc = rd('fpga/pynq_gpu.xdc')
cons = re.findall(r'PACKAGE_PIN\s+(\w+).*?get_ports\s+\{?([\w\[\]]+)\}?\]\s*(?:;#\s*(\S+))?', xdc)
bits_needed = {f'{n}[{i}]' if w > 1 else n for n, (d, w) in top.items() for i in range(w)}
bits_have = [p for _, p, _ in cons]
check(sorted(bits_needed) == sorted(set(bits_have)) and len(bits_have) == len(set(bits_have)),
      f'all {len(bits_needed)} port bits constrained exactly once')
pins = [pin for pin, _, _ in cons]
check(len(pins) == len(set(pins)), 'no FPGA pin used twice')
for pin, port, cmt in cons:
    lab = PYNQ.get(pin)
    check(lab is not None and (not cmt or cmt == lab), f'{port:11s} -> {pin:4s} = {lab}' + (f' (comment {cmt})' if cmt else ''))

# ======================================================================= B
print('\n[B] Arduino sketch <-> PYNQ Arduino header')
ino = rd('arduino/gpu_demo/gpu_demo.ino')
cs = int(re.search(r'const\s+\w+\s+PIN_CS\s*=\s*(\d+)', ino).group(1))
rdy = int(re.search(r'const\s+\w+\s+PIN_READY\s*=\s*(\d+)', ino).group(1))
sock = {port: PYNQ[pin] for pin, port, _ in cons if PYNQ.get(pin, '').startswith('D')}
wiring = [('D13 (hw SCK)', sock['spi_sck'], 'spi_sck'), ('D11 (hw MOSI)', sock['spi_mosi'], 'spi_mosi'),
          (f'D{cs} (CS)', sock['spi_cs_n'], 'spi_cs_n'), (f'D{rdy} (READY in)', sock['gpu_ready'], 'gpu_ready')]
for a, s, sig in wiring:
    print(f'         Arduino {a:15s} <-> PYNQ header {s:4s}  {sig}')
check(cs == 10 and rdy not in (10, 11, 12, 13), 'sketch CS = D10 (Uno SS) and READY on a free GPIO')
check(sock['spi_cs_n'] == 'D10' and sock['spi_mosi'] == 'D11' and sock['spi_sck'] == 'D13',
      'PYNQ side uses the standard Arduino SPI socket positions')

# ======================================================================= C
print('\n[C] gpu_asic ports <-> pin_order.cfg')
asic = ports_of(rd('asic/src/gpu_asic.v'), 'gpu_asic')
cfg = rd('asic/pin_order.cfg')
side, side_of = None, {}
for line in cfg.splitlines():
    line = line.strip()
    if line.startswith('#'): side = line[1]; continue
    if line: side_of.setdefault(line.replace('\\', ''), side)
asic_bits = {f'{n}[{i}]' if w > 1 else n for n, (d, w) in asic.items() for i in range(w)}
check(set(side_of) == asic_bits, f'all {len(asic_bits)} macro pins placed exactly once')
for b in sorted(asic_bits):
    print(f'         {b:12s} side {side_of.get(b)}')

# ======================================================================= D
print('\n[D] chip_top.v pad configuration and macro hookup')
exp = subprocess.run(['iverilog', '-E', '-o', '-', os.path.join(ROOT, 'chip/rtl/chip_top.v')],
                     capture_output=True, text=True, check=True).stdout
INST_RE = r'(sky130_ef_io__\w+|sky130_fd_sc_hd__conb_1|gpu_asic)\s+(\w+)\s*\((.*?)\);'
insts = {i: (c, b) for c, i, b in re.findall(INST_RE, exp, re.S)}
def conns(body):
    return {p: re.sub(r'\s+', '', v) for p, v in re.findall(r'\.(\w+)\s*\(([^()]*)\)', body)}
core = conns(insts['u_core'][1])
net2pin = {}
for p, v in core.items():                      # expand buses: .vga_rgb(rgb) -> rgb[i] = vga_rgb[i]
    w = asic.get(p, ('', 1))[1]
    if w > 1:
        for i in range(w): net2pin[f'{v}[{i}]'] = f'{p}[{i}]'
    else:
        net2pin[v] = p
gpios = {i: conns(b) for i, (c, b) in insts.items() if c == 'sky130_ef_io__gpiov2_pad_wrapped' and i != 'u_power_good'}
check(len(gpios) == 11, f'{len(gpios)} signal GPIOs (+ u_power_good)')
ties = []
pad_to_macro = {}
for name, c in sorted(gpios.items()):
    is_out = c.get('OUT') not in (None, 'cfg_lo')
    net = c['OUT'] if is_out else c['IN']
    mpin = net2pin.get(net)
    want_dir = 'output' if is_out else 'input'
    mdir = asic.get(re.sub(r'\[\d+\]', '', mpin or ''), ('?',))[0]
    cfg_ok = (c['DM'] == '{cfg_hi,cfg_hi,cfg_lo}' and c['OE_N'] == 'cfg_lo' and c['INP_DIS'] == 'cfg_hi') if is_out else \
             (c['DM'] == '{cfg_lo,cfg_lo,cfg_hi}' and c['OE_N'] == 'cfg_hi' and c['INP_DIS'] == 'cfg_lo')
    en_ok = c['ENABLE_H'] == 'por_h' and c['ENABLE_VDDIO'] == 'por_lv'
    tie = c['TIE_LO_ESD']; ties.append(tie)
    tie_ok = c['ENABLE_INP_H'] == tie and c['ENABLE_VDDA_H'] == tie and c['ENABLE_VSWITCH_H'] == tie
    pad_to_macro[name] = mpin or '?'
    check(mpin is not None and mdir == want_dir and cfg_ok and en_ok and tie_ok,
          f'{name:8s} {"OUT" if is_out else "IN ":3s} {c["PAD"]:12s} <-> macro {mpin}  (DM {c["DM"]})')
check(len(set(ties)) == len(ties), 'every GPIO uses its own tie_lo[] index')
pg = conns(insts['u_power_good'][1])
check(pg['IN_H'] == 'por_h' and pg['IN'] == 'por_lv' and pg['ENABLE_INP_H'] == pg['TIE_HI_ESD'],
      'u_power_good drives por_h / por_lv and keeps its own input enabled')
check(core.get('VPWR') == 'VCCD' and core.get('VGND') == 'VSSD', 'macro VPWR/VGND -> VCCD/VSSD')
supplies = {i: c for i, (c, b) in insts.items() if 'clamped_pad' in c}
check(len(supplies) == 6, f'{len(supplies)} supply pads: ' + ' '.join(sorted(supplies)))

# ======================================================================= E
print('\n[E] 01_floorplan.tcl pad sides <-> macro pin sides')
fp = rd('chip/tcl/01_floorplan.tcl')
rows = {s: l.split() for s, l in re.findall(r'^place_pads\s+-row\s+IO_(\w+)\s+-mode\s+uniform\s+\{([^}]*)\}', fp, re.M)}
placed = [p for l in rows.values() for p in l]
all_pads = [i for i, (c, b) in insts.items() if c.startswith('sky130_ef_io__')]
check(sorted(placed) == sorted(all_pads), f'all {len(all_pads)} pads placed exactly once')
S = {'NORTH': 'N', 'SOUTH': 'S', 'EAST': 'E', 'WEST': 'W'}
for row, pads in rows.items():
    for p in pads:
        if p in pad_to_macro:
            mside = side_of.get(pad_to_macro[p])
            check(mside == S[row], f'{p:8s} on {row:5s}  <-> macro {pad_to_macro[p]} on side {mside}')

# ======================================================================= F
print('\n[F] Electrical: level dividers (FPGA) and VGA DAC (ASIC board)')
v_div = 5.0 * 3.3 / (2.2 + 3.3)                       # Uno 5 V -> PYNQ 3.3 V input
check(2.0 <= v_div <= 3.465, f'divider 2.2k/3.3k: 5 V -> {v_div:.2f} V (LVCMOS33 VIH >= 2.0 V, VCCO + 5 %)')
r_th = 2.2e3 * 3.3e3 / (2.2e3 + 3.3e3); t_r = 2.2 * r_th * 10e-12
check(t_r < 0.25 * 0.5 / 2e6, f'divider source {r_th:.0f} ohm, 10-90 % rise {t_r*1e9:.0f} ns << 250 ns SCK half period')
check(3.3 >= 0.6 * 5.0, 'READY 3.3 V >= ATmega328P VIH (0.6 x 5 V = 3.0 V)')
v = 3.3 * 75 / (270 + 75); i = 3.3 / (270 + 75)
check(0.6 <= v <= 0.75, f'3.3 V through 270 ohm into 75 ohm = {v:.3f} V (VGA full scale 0.7 V)')
check(i > 4e-3 and i < 24e-3, f'DAC current {i*1e3:.1f} mA: above the 4 mA GPIO pad rating -> driven by a 74LVC244A (24 mA)')

print('\nRESULT:', 'ALL CONNECTIONS CONSISTENT' if not errors else f'{len(errors)} PROBLEM(S)')
sys.exit(1 if errors else 0)
