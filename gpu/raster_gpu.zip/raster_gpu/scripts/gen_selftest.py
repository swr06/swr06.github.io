#!/usr/bin/env python3
"""
gen_selftest.py - builds fpga/selftest.mem, the command ROM of the on-board
SPI test host (fpga/spi_test_host.v).

    python3 scripts/gen_selftest.py              # writes fpga/selftest.mem
                                                 # + build/selftest/test_N.cmd

Each test is a list of 80-bit commands followed by an all-zero word.
The board runs test N when you press a button (SW0 up):

    BTN1  BTN2  BTN3        SW1 down -> tests 1 2 3,  SW1 up -> tests 4 5 6

To add your own test: write a function like the ones below (use the same
helpers as the demos: clear, rect, line, circle, fill_circle, swap), add it to
TESTS, run this script, then re-run synthesis + implementation in Vivado
(the .mem file is read when the bitstream is built). At most 6 tests and
255 commands in total. Every test should start with clear() and end with
swap(): the FPGA build is double buffered, so nothing shows before the SWAP.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_demo as g

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROM_DEPTH = 256
g.setup("fpga")
W, H = g.W, g.H                                   # 320 x 240


def t1_alive():
    """BTN1 - is it alive? blue screen, 1-pixel white border, centre square.
    Uses only CLEAR, RECT and SWAP: SPI receiver + rect engine + VGA."""
    g.clear(g.BLUE)
    g.rect(0, 0, W, 1, g.WHITE)                   # top    row 0
    g.rect(0, H - 1, W, 1, g.WHITE)               # bottom row 239
    g.rect(0, 0, 1, H, g.WHITE)                   # left   column 0
    g.rect(W - 1, 0, 1, H, g.WHITE)               # right  column 319
    g.rect(W // 2 - 8, H // 2 - 8, 16, 16, g.WHITE)
    g.swap()


def t2_rects():
    """BTN2 - rectangles and every palette colour: 8 colour bars, grey band,
    nested squares (w/h = 1 and 2 at the centre)."""
    g.clear(g.BLACK)
    bw = W // 8
    for i in range(8):
        g.rect(i * bw, 0, bw, H // 2, g.PALETTE[i])
    g.rect(0, H // 2, W, H // 6, g.GREY)
    cx, cy = W // 2, (H * 5) // 6
    for i, s in enumerate((32, 24, 16, 8, 2, 1)):
        g.rect(cx - s // 2, cy - s // 2, s, s, g.PALETTE[i])
    g.swap()


def t3_lines():
    """BTN3 - lines in all 8 octants (starburst) plus a white frame drawn with
    4 lines: tests the Bresenham engine and the end points."""
    g.starburst()                                 # clear + 72 lines + swap
    g.cmds.pop()                                  # remove its swap ...
    g.line(0, 0, W - 1, 0, g.WHITE); g.line(W - 1, 0, W - 1, H - 1, g.WHITE)
    g.line(W - 1, H - 1, 0, H - 1, g.WHITE); g.line(0, H - 1, 0, 0, g.WHITE)
    g.swap()                                      # ... and add it at the end


def t4_circles():
    """SW1 + BTN1 - circles: filled target, 8 outlines, clipped bubbles."""
    g.circles()


def t5_clipping():
    """SW1 + BTN2 - everything partly or fully off screen. Nothing may wrap
    around to the other side; the green frame shows the screen edge."""
    g.clear(g.BLACK)
    g.rect(0, 0, W, 1, g.GREEN); g.rect(0, H - 1, W, 1, g.GREEN)
    g.rect(0, 0, 1, H, g.GREEN); g.rect(W - 1, 0, 1, H, g.GREEN)
    g.rect(-40, 20, 80, 40, g.RED)                # off the left edge
    g.rect(W - 40, 20, 80, 40, g.YELLOW)          # off the right edge
    g.rect(W // 2 - 30, -20, 60, 40, g.CYAN)      # off the top
    g.rect(W // 2 - 30, H - 20, 60, 40, g.MAGENTA)# off the bottom
    g.rect(-100, -100, 50, 50, g.WHITE)           # fully off: draws nothing
    g.line(-50, H // 2, W + 50, H // 2 + 30, g.ORANGE)   # both ends off screen
    g.line(W // 2, -500, W // 2 + 40, H + 500, g.WHITE)
    g.fill_circle(0, H - 1, 50, g.BLUE)           # centre on the corner
    g.circle(W - 1, H // 2, 60, g.WHITE)          # centre on the right edge
    g.fill_circle(W + 200, H + 200, 100, g.RED)   # fully off: draws nothing
    g.swap()


def t6_scene():
    """SW1 + BTN3 - everything in one picture: the test pattern with the
    circles demo drawn on top (all engines in one frame)."""
    g.test_pattern()                              # clear, bars, lines, circle, swap
    g.cmds.pop()                                  # keep drawing into the same buffer
    n = len(g.cmds)
    g.circles()                                   # clear ... swap
    del g.cmds[n]                                 # drop the circles' CLEAR


TESTS = [t1_alive, t2_rects, t3_lines, t4_circles, t5_clipping, t6_scene]


def main():
    words = []
    os.makedirs(os.path.join(ROOT, "build", "selftest"), exist_ok=True)
    for n, t in enumerate(TESTS, 1):
        g.cmds.clear()
        t()
        if any(w == 0 for w in g.cmds):
            sys.exit(f"test {n}: an all-zero command would end the test early")
        with open(os.path.join(ROOT, "build", "selftest", f"test_{n}.cmd"), "w") as fh:
            fh.writelines("%020x\n" % w for w in g.cmds)
        words += g.cmds + [0]
        print(f"test {n}  {t.__name__:12s} {len(g.cmds):3d} commands   {t.__doc__.splitlines()[0]}")
    if len(words) > ROM_DEPTH:
        sys.exit(f"{len(words)} words do not fit the {ROM_DEPTH}-word ROM")
    words += [0] * (ROM_DEPTH - len(words))
    with open(os.path.join(ROOT, "fpga", "selftest.mem"), "w") as fh:
        fh.writelines("%020x\n" % w for w in words)
    used = len([w for w in words if w]) + len(TESTS)
    print(f"fpga/selftest.mem: {used} of {ROM_DEPTH} ROM words used")


if __name__ == "__main__":
    main()
