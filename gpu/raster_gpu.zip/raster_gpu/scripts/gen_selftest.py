#!/usr/bin/env python3
"""
gen_selftest.py - builds the command ROMs of the on-board SPI test host
(fpga/spi_test_host.v), one per bring-up step:

    bringup/step2_rect/selftest.mem   step 2: SPI + framebuffer + RECT
    bringup/step3_line/selftest.mem   step 3: + LINE
    fpga/selftest.mem                 step 4: + CIRCLE (the final GPU)

    python3 scripts/gen_selftest.py   # writes the three ROMs
                                      # + build/selftest/step<S>_test<N>.cmd

On the board (SW0 up), every step works the same way:

    test 1 runs by itself after programming / BTN0
    SW1 down:  BTN1 / BTN2 / BTN3 = tests 1 / 2 / 3   the NEW tests of this step
    SW1 up:    BTN1 / BTN2 / BTN3 = tests 4 / 5 / 6   the tests of the step
                                                      before (regression: the new
                                                      engine must not break the
                                                      old ones). Empty in step 2.

A ROM only contains commands its step's gpu_core can draw.

Each test is a list of 80-bit commands followed by an all-zero word.
To add your own test: write a function like the ones below (same helpers as
the demos: clear, rect, line, circle, fill_circle, swap), put it in STEPS,
run this script, then rebuild the bitstream in Vivado (the .mem file is read
when the bitstream is built). Start every test with clear() and end it with
swap(): the FPGA build is double buffered, nothing shows before the SWAP.
"""
import math, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_demo as g

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROM_DEPTH = 256
g.setup("fpga")
W, H = g.W, g.H                                   # 320 x 240

# a few extra RGB332 colours (RRRGGGBB)
SKY, GRASS, CREAM, BROWN = 0x53, 0x0C, 0xF9, 0x88
NIGHT, MOON, GLASS = 0x02, 0xFD, 0x9F


# ================================================================ step 2: RECT
# CLEAR, RECT and SWAP only.

def r1_hello():
    """Hello over SPI - blue screen, 1-pixel white border, "HI" in block letters."""
    g.clear(g.BLUE)
    g.rect(0, 0, W, 1, g.WHITE)                   # top    row 0
    g.rect(0, H - 1, W, 1, g.WHITE)               # bottom row 239
    g.rect(0, 0, 1, H, g.WHITE)                   # left   column 0
    g.rect(W - 1, 0, 1, H, g.WHITE)               # right  column 319
    x, y, s, h = 90, 80, 16, 80                   # letter origin, stroke, height
    g.rect(x, y, s, h, g.WHITE)                   # H: left bar
    g.rect(x + 44, y, s, h, g.WHITE)              #    right bar
    g.rect(x, y + 32, 60, s, g.WHITE)             #    middle
    x = 170
    g.rect(x, y, 60, s, g.WHITE)                  # I: top
    g.rect(x + 22, y, s, h, g.WHITE)              #    stem
    g.rect(x, y + h - s, 60, s, g.WHITE)          #    bottom
    g.swap()


def r2_colours():
    """Colours and sizes - 8 colour bars, a grey band, squares from 32x32 down to 1x1."""
    g.clear(g.BLACK)
    bw = W // 8
    for i in range(8):
        g.rect(i * bw, 0, bw, H // 2, g.PALETTE[i])
    g.rect(0, H // 2, W, H // 6, g.GREY)
    cx, cy = W // 2, (H * 5) // 6
    for i, sz in enumerate((32, 24, 16, 8, 2, 1)):
        g.rect(cx - sz // 2, cy - sz // 2, sz, sz, g.PALETTE[i])
    g.swap()


def r3_blocks():
    """Blocks off the edges - a Mondrian-style composition whose blocks and bars
    run off all four edges (clipping); two rectangles that must draw nothing."""
    g.clear(g.WHITE)
    g.rect(-40, -30, 160, 120, g.RED)             # off the top-left corner
    g.rect(226, 186, 140, 100, g.BLUE)            # off the bottom-right corner
    g.rect(226, -20, 120, 70, g.YELLOW)           # off top and right
    g.rect(-20, 186, 146, 80, g.YELLOW)           # off left and bottom
    g.rect(126, 96, 100, 90, g.BLUE)              # fully inside
    g.rect(120, -100, 6, 500, g.BLACK)            # vertical bars, both ends off
    g.rect(220, -100, 6, 500, g.BLACK)
    g.rect(-100, 90, 600, 6, g.BLACK)             # horizontal bars, both ends off
    g.rect(-100, 180, 600, 6, g.BLACK)
    g.rect(226, 50, 200, 6, g.BLACK)              # short bar off the right edge
    g.rect(400, 300, 50, 50, g.RED)               # fully off screen: nothing
    g.rect(60, 130, 0, 40, g.RED)                 # width 0: nothing
    g.swap()


# ================================================================ step 3: LINE

def l1_starburst():
    """Starburst - 32 rays from the centre in every direction (all 8 octants),
    a frame drawn with 4 lines, both diagonals."""
    g.clear(g.BLACK)
    cx, cy, r = W // 2, H // 2, H // 2 - 4
    for i in range(32):
        a = i * 2 * math.pi / 32
        g.line(cx, cy, g.ctrunc(cx + r * math.cos(a)), g.ctrunc(cy + r * math.sin(a)), g.PALETTE[i % 7])
    g.line(0, 0, W - 1, 0, g.WHITE); g.line(W - 1, 0, W - 1, H - 1, g.WHITE)
    g.line(W - 1, H - 1, 0, H - 1, g.WHITE); g.line(0, H - 1, 0, 0, g.WHITE)
    g.line(0, 0, W - 1, H - 1, g.GREY); g.line(W - 1, 0, 0, H - 1, g.GREY)
    g.swap()


def l2_string_art():
    """String art - 52 straight lines whose ends walk along the screen edges;
    together they bend into a smooth curve in each corner."""
    g.clear(g.BLACK)
    n, xm, ym = 12, W - 1, H - 1
    for i in range(n + 1):
        t = i / n
        x, y = round(t * xm), round(t * ym)
        xr, yr = round((1 - t) * xm), round((1 - t) * ym)
        g.line(0, y, xr, 0, g.CYAN)               # top-left corner
        g.line(xm, y, x, 0, g.MAGENTA)            # top-right corner
        g.line(0, yr, xr, ym, g.YELLOW)           # bottom-left corner
        g.line(xm, yr, x, ym, g.GREEN)            # bottom-right corner
    g.swap()


def l3_house():
    """House - rectangles and lines together: walls, door, windows, a hatched
    roof, a sun in the corner with rays and a road whose lines start far off
    screen (line clipping)."""
    g.clear(SKY)
    for dx, dy in ((-1, 0), (-3, 1), (-1, 1), (-1, 3), (0, 1)):
        g.line(300, 20, 300 + dx * 400, 20 + dy * 400, g.YELLOW)   # sun rays leave the screen
    g.rect(268, -12, 64, 64, g.YELLOW)            # sun, off the top-right corner
    g.rect(-20, 190, 360, 70, GRASS)              # ground, off 3 edges
    g.line(-400, 300, 150, 190, g.WHITE)          # road: both lines start
    g.line(720, 300, 170, 190, g.WHITE)           # below and beside the screen
    g.rect(100, 110, 120, 80, CREAM)              # walls
    g.rect(196, 60, 14, 40, BROWN)                # chimney
    g.line(90, 110, 160, 56, g.RED)               # roof outline
    g.line(160, 56, 230, 110, g.RED)
    g.line(90, 110, 230, 110, g.RED)
    for x in range(100, 230, 10):                 # roof hatching
        g.line(160, 56, x, 110, g.RED)
    g.rect(148, 146, 24, 44, BROWN)               # door
    for wx in (114, 186):                         # windows with crosses
        g.rect(wx - 12, 126, 24, 24, GLASS)
        g.line(wx, 126, wx, 149, g.WHITE)
        g.line(wx - 12, 138, wx + 11, 138, g.WHITE)
    g.swap()


# ================================================================ step 4: CIRCLE

def c1_target():
    """Target and rings - a filled target, 8 outlines, bubbles cut by the bottom edge."""
    g.circles()


def c2_snowman():
    """Snowman at night - every engine in one picture: a crescent moon (two
    filled circles, cut by the top edge), snowman, hat, scarf, stick arms,
    snowflakes of radius 0 and 1."""
    g.clear(NIGHT)
    g.fill_circle(292, 22, 40, MOON)              # moon ...
    g.fill_circle(310, 10, 38, NIGHT)             # ... minus a circle = crescent
    g.rect(-10, 200, 340, 50, g.WHITE)            # snow on the ground
    g.fill_circle(160, 170, 40, g.WHITE)          # body
    g.fill_circle(160, 113, 28, g.WHITE)
    g.fill_circle(160, 70, 19, g.WHITE)           # head
    g.rect(138, 50, 44, 4, g.BLACK)               # hat brim
    g.rect(148, 24, 24, 26, g.BLACK)              # hat
    g.fill_circle(153, 66, 2, g.BLACK)            # eyes
    g.fill_circle(167, 66, 2, g.BLACK)
    g.rect(160, 71, 12, 3, g.ORANGE)              # nose
    g.rect(141, 86, 38, 6, g.RED)                 # scarf
    for y in (104, 116, 128):                     # buttons
        g.fill_circle(160, y, 3, g.BLACK)
    g.line(134, 108, 96, 82, BROWN)               # arms
    g.line(96, 82, 86, 74, BROWN)
    g.line(186, 108, 224, 84, BROWN)
    g.line(224, 84, 236, 78, BROWN)
    for i, (x, y) in enumerate(((30, 40), (70, 110), (40, 170), (110, 30),
                                (230, 140), (270, 100), (290, 175), (215, 30))):
        g.circle(x, y, i & 1, g.WHITE)            # r = 0: one pixel, r = 1: a ring
    g.swap()


def c3_edges():
    """Edges and extremes - every shape partly or fully off every edge, a huge
    circle (r = 1000) whose centre is far below the screen, r = 0 and r = 1.
    Nothing may wrap around to the other side."""
    g.clear(g.BLACK)
    g.rect(0, 0, W, 1, g.GREEN); g.rect(0, H - 1, W, 1, g.GREEN)
    g.rect(0, 0, 1, H, g.GREEN); g.rect(W - 1, 0, 1, H, g.GREEN)
    g.rect(-40, 20, 80, 40, g.RED)                # off the left edge
    g.rect(W - 40, 20, 80, 40, g.YELLOW)          # off the right edge
    g.line(-50, H // 2, W + 50, H // 2 + 30, g.ORANGE)   # both ends off screen
    g.circle(W // 2, H + 900, 1000, g.CYAN)       # top of a huge circle: an arc
    g.fill_circle(0, H - 1, 50, g.BLUE)           # centre on the corner
    g.circle(W - 1, H // 2, 60, g.WHITE)          # centre on the right edge
    g.fill_circle(W // 2, -10, 40, g.MAGENTA)     # centre above the screen
    g.fill_circle(W // 2, H // 2, 30, g.ORANGE)
    g.circle(W // 2, H // 2, 45, g.CYAN)
    g.fill_circle(40, 120, 0, g.WHITE)            # r = 0: one pixel
    g.circle(60, 120, 1, g.WHITE)                 # r = 1
    g.fill_circle(W + 200, H + 200, 100, g.RED)   # fully off: draws nothing
    g.swap()


# ================================================================ the ROMs
STEPS = {
    2: ("bringup/step2_rect/selftest.mem", [r1_hello, r2_colours, r3_blocks], {1, 3, 4}),
    3: ("bringup/step3_line/selftest.mem", [l1_starburst, l2_string_art, l3_house], {1, 2, 3, 4}),
    4: ("fpga/selftest.mem",               [c1_target, c2_snowman, c3_edges], {1, 2, 3, 4, 5}),
}


def build(t):
    g.cmds.clear()
    t()
    if any(w == 0 for w in g.cmds):
        sys.exit(f"{t.__name__}: an all-zero command would end the test early")
    return list(g.cmds)


def main():
    out = os.path.join(ROOT, "build", "selftest")
    os.makedirs(out, exist_ok=True)
    for step, (path, new, ops) in STEPS.items():
        old = STEPS[step - 1][1] if step - 1 in STEPS else []
        words = []
        print(f"step {step}: {path}")
        for n, t in enumerate(new + old + [None] * (3 - len(old)), 1):
            cmds = build(t) if t else []
            if any((w >> 72) not in ops for w in cmds):
                sys.exit(f"step {step} test {n}: uses an opcode this step's gpu_core does not have")
            words += cmds + [0]
            with open(os.path.join(out, f"step{step}_test{n}.cmd"), "w") as fh:
                fh.writelines("%020x\n" % w for w in cmds)
            if t:
                tag = "new" if n <= 3 else f"regression (step {step - 1})"
                print(f"  test {n}  {t.__name__:14s} {len(cmds):3d} commands  [{tag}]  {t.__doc__.split(' - ')[0]}")
            else:
                print(f"  test {n}  (empty: no earlier step)")
        if len(words) > ROM_DEPTH:
            sys.exit(f"{len(words)} words do not fit the {ROM_DEPTH}-word ROM")
        print(f"  {len(words)} of {ROM_DEPTH} ROM words used")
        words += [0] * (ROM_DEPTH - len(words))
        with open(os.path.join(ROOT, path), "w") as fh:
            fh.writelines("%020x\n" % w for w in words)


if __name__ == "__main__":
    main()
