#!/usr/bin/env python3
"""Generate SPI command streams identical to arduino/gpu_demo.ino.

Usage: gen_demo.py <fpga|asic|sram> <pattern|starburst|circles|cube|orbit> <out.hex> [frames]
Each line of the output is one 80-bit command in hex.
Also importable (scripts/gen_selftest.py uses the drawing helpers).
"""
import math, sys

OP_CLEAR, OP_LINE, OP_RECT, OP_SWAP, OP_CIRCLE = 1, 2, 3, 4, 5
BLACK, WHITE, RED, GREEN, BLUE = 0x00, 0xFF, 0xE0, 0x1C, 0x03
YELLOW, CYAN, MAGENTA, ORANGE, GREY = 0xFC, 0x1F, 0xE3, 0xF0, 0x92
PALETTE = [WHITE, YELLOW, CYAN, GREEN, MAGENTA, RED, BLUE, ORANGE]

FPGA, W, H = True, 320, 240
cmds = []

def setup(target):
    """select the build: fpga (320x240), sram (80x60) or asic (40x30)"""
    global FPGA, W, H
    FPGA = target == "fpga"
    W, H = (320, 240) if FPGA else ((80, 60) if target == "sram" else (40, 30))
    cmds.clear()

def send(op, a=0, b=0, c=0, d=0, col=0):
    w = op
    for v in (a, b, c, d):
        w = (w << 16) | (v & 0xFFFF)
    w = (w << 8) | col
    cmds.append(w)

clear = lambda c: send(OP_CLEAR, col=c)
line = lambda x0, y0, x1, y1, c: send(OP_LINE, x0, y0, x1, y1, c)
rect = lambda x, y, w, h, c: send(OP_RECT, x, y, w, h, c)
swap = lambda: send(OP_SWAP)
circle = lambda cx, cy, r, c: send(OP_CIRCLE, cx, cy, r, 0, c)
fill_circle = lambda cx, cy, r, c: send(OP_CIRCLE, cx, cy, r, 1, c)
begin_frame = lambda: None if FPGA else swap()
end_frame = lambda: swap() if FPGA else None

def ctrunc(v):  # C (int16_t) cast truncates toward zero
    return int(v)

def test_pattern():
    begin_frame(); clear(BLACK)
    bw = W // 8
    for i in range(8):
        rect(i * bw, 0, bw, (H * 2) // 3, PALETTE[i])
    rect(0, (H * 2) // 3, W, H // 3, GREY)
    line(0, 0, W - 1, 0, WHITE); line(W - 1, 0, W - 1, H - 1, WHITE)
    line(W - 1, H - 1, 0, H - 1, WHITE); line(0, H - 1, 0, 0, WHITE)
    line(0, 0, W - 1, H - 1, RED); line(W - 1, 0, 0, H - 1, BLUE)
    circle(W // 2, H // 2, H // 3, WHITE)
    end_frame()

def starburst():
    begin_frame(); clear(BLACK)
    cx, cy, k = W // 2, H // 2, 0
    step = 16 if W >= 160 else 4
    for x in range(0, W, step):        line(cx, cy, x, 0, PALETTE[k & 7]); k += 1
    for y in range(0, H, step):        line(cx, cy, W - 1, y, PALETTE[k & 7]); k += 1
    for x in range(W - 1, 0, -step):   line(cx, cy, x, H - 1, PALETTE[k & 7]); k += 1
    for y in range(H - 1, 0, -step):   line(cx, cy, 0, y, PALETTE[k & 7]); k += 1
    end_frame()

def circles():
    begin_frame(); clear(BLACK)
    r, cy = (H * 3) // 10, H // 2
    for i in range(5):
        fill_circle(W // 4, cy, r - i * (r // 5), WHITE if i & 1 else RED)
    for i in range(8):
        circle((W * 3) // 4, cy, r - i * (r // 8), PALETTE[i])
    for i in range(9):
        fill_circle(i * (W // 8), H - 1, H // 12, PALETTE[i & 7])
    end_frame()

def orbit(t):
    cx, cy = W // 2, H // 2
    R, m = (H * 2) // 5, H // 10
    px = ctrunc(cx + R * math.cos(t)); py = ctrunc(cy + R * math.sin(t))
    mx = ctrunc(px + m * math.cos(4 * t)); my = ctrunc(py + m * math.sin(4 * t))
    begin_frame(); clear(BLACK)
    circle(cx, cy, R, GREY)
    fill_circle(cx, cy, H // 8, YELLOW)
    fill_circle(px, py, H // 16, BLUE)
    fill_circle(mx, my, H // 40, WHITE)
    end_frame()

V = [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]
E = [(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]

def cube(ax, ay):
    sx, cx, sy, cy = math.sin(ax), math.cos(ax), math.sin(ay), math.cos(ay)
    f = H * 0.6
    px, py = [], []
    for x, y, z in V:
        y1 = y * cx - z * sx; z1 = y * sx + z * cx
        x2 = x * cy + z1 * sy; z2 = -x * sy + z1 * cy
        zc = z2 + 4.0
        px.append(ctrunc(W / 2 + (x2 * f) / zc)); py.append(ctrunc(H / 2 + (y1 * f) / zc))
    begin_frame(); clear(BLACK)
    for e, (a, b) in enumerate(E):
        c = BLUE if e < 4 else (YELLOW if e < 8 else MAGENTA)
        line(px[a], py[a], px[b], py[b], c)
    end_frame()

def main():
    target, demo, out = sys.argv[1], sys.argv[2], sys.argv[3]
    setup(target)
    run_demo(demo)
    if not FPGA:      # single buffer: one extra vblank wait so the frame we capture is complete
        swap()
    with open(out, "w") as fh:
        for w in cmds:
            fh.write("%020x\n" % w)
    print(f"{len(cmds)} commands -> {out}")

def run_demo(demo, frames=None, first=0):
    if demo == "pattern":
        test_pattern()
    elif demo == "starburst":
        starburst()
    elif demo == "circles":
        circles()
    elif demo == "orbit":
        n = frames if frames is not None else (int(sys.argv[4]) if len(sys.argv) > 4 else 1)
        for i in range(n):
            orbit(i * 0.157)
    elif demo == "cube":
        n = frames if frames is not None else (int(sys.argv[4]) if len(sys.argv) > 4 else 1)
        first = int(sys.argv[5]) if frames is None and len(sys.argv) > 5 else first
        for i in range(first, first + n):
            cube(i * 0.035, i * 0.05)
    else:
        sys.exit("unknown demo")

if __name__ == "__main__":
    main()
