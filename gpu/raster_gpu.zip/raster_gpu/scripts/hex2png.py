#!/usr/bin/env python3
"""Turn a captured VGA frame (.hex, 640x480 lines) into a PNG.
   python3 scripts/hex2png.py <fpga|asic|sram> build/fpga_test.hex out.png
   needs:  pip install pillow --break-system-packages
"""
import sys
from PIL import Image
kind, src, dst = sys.argv[1], sys.argv[2], sys.argv[3]
vals = [int(l, 16) for l in open(src) if l.strip()]
img = Image.new('RGB', (640, 480))
px = []
for v in vals:
    if kind in ('fpga', 'sram'):                   # RGB332 -> RGB444 -> 8 bit
        r4 = ((v >> 5) << 1) | (v >> 7)
        g4 = (((v >> 2) & 7) << 1) | ((v >> 4) & 1)
        b4 = ((v & 3) << 2) | (v & 3)
        px.append((r4 * 17, g4 * 17, b4 * 17))
    else:                                          # RGB111
        px.append((255 * ((v >> 2) & 1), 255 * ((v >> 1) & 1), 255 * (v & 1)))
img.putdata(px)
img.save(dst)
print('wrote', dst)
