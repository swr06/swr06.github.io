#!/usr/bin/env python3
"""
check_circle.py - checks the circle algorithm of rtl/circle_renderer.v
(independent of the RTL and of the testbench model).

    python3 scripts/check_circle.py [max_r]        (default 400)

For every radius 0..max_r:
  1. every outline pixel is within half a pixel of the true circle
     ( |x^2 + y^2 - r^2| <= r )
  2. the outline has no gaps (every pixel has an 8-neighbour, r >= 1)
  3. the filled disc writes no pixel twice
  4. the filled disc is exactly "each row filled between the leftmost and
     the rightmost outline pixel" (so outline and fill always match)
Then prints the clock counts used in the guide.
"""
import math, sys

def steps(r):
    """octant 0 of the midpoint circle: yields (x, y, d, last) per step"""
    x, y, d = r, 0, 1 - r
    while True:
        yn = y + 1
        xn = x if d < 0 else x - 1
        dn = d + 2 * yn + 1 if d < 0 else d + 2 * (yn - xn) + 1
        last = xn < yn
        yield x, y, d, last
        if last:
            return
        x, y, d = xn, yn, dn

def outline(r):
    pts = []
    for x, y, d, last in steps(r):
        pts += [(x, y), (y, x), (-y, x), (-x, y), (-x, -y), (-y, -x), (y, -x), (x, -y)]
    return pts

def spans(r):
    """the spans circle_renderer.v walks in filled mode: (row, half_width)"""
    out = []
    for x, y, d, last in steps(r):
        out.append((y, x))                          # s = 0
        if y != 0:
            out.append((-y, x))                     # s = 1
        if (d >= 0 or last) and x != y:
            out += [(x, y), (-x, y)]                # s = 2, 3
    return out

max_r = int(sys.argv[1]) if len(sys.argv) > 1 else 400
bad = 0
for r in range(max_r + 1):
    out = set(outline(r))
    fill = [(i, row) for row, h in spans(r) for i in range(-h, h + 1)]
    if any(abs(px * px + py * py - r * r) > r for px, py in out):
        bad += 1; print('r =', r, ': outline pixel too far from the circle')
    if r >= 1 and any(not any((px + a, py + b) in out for a in (-1, 0, 1) for b in (-1, 0, 1) if a or b)
                      for px, py in out):
        bad += 1; print('r =', r, ': gap in the outline')
    if len(fill) != len(set(fill)):
        bad += 1; print('r =', r, ': filled disc writes a pixel twice')
    hull = set()
    for row in {py for _, py in out}:
        xs = [px for px, py in out if py == row]
        hull |= {(i, row) for i in range(min(xs), max(xs) + 1)}
    if set(fill) != hull:
        bad += 1; print('r =', r, ': filled disc does not match the outline')

print(f'radii 0..{max_r}:', 'ALL CHECKS PASSED' if not bad else f'{bad} PROBLEM(S)')
print()
print('   r  steps  outline clocks  filled pixels  (pi r^2)  filled clocks   @25 MHz')
for r in (3, 10, 50, 100, 200):
    n = sum(1 for _ in steps(r))
    fp = sum(2 * h + 1 for _, h in spans(r))
    print(f'{r:4d} {n:6d} {8*n:15d} {fp:14d} {math.pi*r*r:9.0f} {fp+4*n:14d} {(fp+4*n)/25e3:8.2f} ms')
sys.exit(1 if bad else 0)
