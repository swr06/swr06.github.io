`timescale 1ns / 1ps

// =============================================================
// PYNQ-Z2 top level for the SPI rasterizer GPU
//
//   125 MHz sysclk (H16) -> Clocking Wizard -> 25 MHz core/pixel clock
//   12-bit VGA on PMOD A / PMOD B (your video adapter, pins unchanged)
//   SPI from an external Arduino on the PYNQ-Z2 Arduino header:
//       header D10 -> spi_cs_n   (T16)      header D11 -> spi_mosi (R17)
//       header D13 -> spi_sck    (N17)      header D12 <- gpu_ready (P18)
//   LD0 READY, LD1 clock locked, LD2 command toggle, LD3 heartbeat, BTN0 reset
//
// Pure PL design: no Zynq PS, no AXI, no block design needed.
// The Arduino header sockets are wired straight to PL I/O pins, so they are
// ordinary top-level ports here, exactly like the PMOD pins.
// =============================================================

module fpga_top (
    input  wire sysclk,          // 125 MHz
    input  wire reset,           // BTN0, active high

    // SPI from Arduino (PYNQ Arduino header D10 / D11 / D13)
    input  wire spi_cs_n,
    input  wire spi_sck,
    input  wire spi_mosi,
    output wire gpu_ready,       // PYNQ Arduino header D12

    // VGA (PMOD A + PMOD B)
    output wire vga_hs,
    output wire vga_vs,
    output wire [3:0] vga_r,
    output wire [3:0] vga_g,
    output wire [3:0] vga_b,

    output wire [3:0] led
);

    // hardware nets
    wire clk_25m;
    wire clk_locked;

    // Clocking Wizard IP (created in the IP Catalog, see the guide)
    clk_wiz_0 u_clk (
        .clk_in1(sysclk),
        .reset(1'b0),
        .clk_out1(clk_25m),
        .locked(clk_locked)
    );

    // core stays in reset until the clock is stable and BTN0 is released
    wire rst_n = clk_locked & ~reset;

    wire [7:0] pix;      // RGB332
    wire cmd_toggle;

    gpu_core #(
        .FB_W(320),
        .FB_H(240),
        .SCALE_SHIFT(1),
        .PIX_BITS(8),
        .DOUBLE_BUF(1)
    ) u_gpu (
        .clk(clk_25m),
        .rst_n(rst_n),
        .spi_cs_n(spi_cs_n),
        .spi_sck(spi_sck),
        .spi_mosi(spi_mosi),
        .gpu_ready(gpu_ready),
        .vga_hs(vga_hs),
        .vga_vs(vga_vs),
        .vga_pix(pix),
        .dbg_cmd_toggle(cmd_toggle)
    );

    // RGB332 -> RGB444 for the 12-bit adapter (repeat MSBs into the LSBs)
    assign vga_r = {pix[7:5], pix[7]};
    assign vga_g = {pix[4:2], pix[4]};
    assign vga_b = {pix[1:0], pix[1:0]};

    // ---- status LEDs ----
    // LD0 = READY, LD1 = clock locked, LD2 = toggles per command, LD3 = ~1 Hz heartbeat
    reg [24:0] heartbeat = 25'd0;
    always @(posedge clk_25m)
        heartbeat <= heartbeat + 1'b1;

    assign led[0] = gpu_ready;
    assign led[1] = clk_locked;
    assign led[2] = cmd_toggle;
    assign led[3] = heartbeat[24];

endmodule
