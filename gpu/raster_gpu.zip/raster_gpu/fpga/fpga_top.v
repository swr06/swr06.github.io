`timescale 1ns / 1ps

// =============================================================
// PYNQ-Z2 top level for the SPI rasterizer GPU
//
//   125 MHz sysclk (H16) -> Clocking Wizard -> 25 MHz core/pixel clock
//   12-bit VGA on PMOD A / PMOD B (your video adapter, pins unchanged)
//
//   SPI from an external Arduino on the PYNQ-Z2 Arduino header
//   (the board labels these sockets AR0 .. AR13):
//       AR10 -> spi_cs_n  (T16)      AR11 -> spi_mosi (R17)
//       AR13 -> spi_sck   (N17)      AR12 <- gpu_ready (P18)
//
//   On-board test host (no Arduino needed):
//       SW0 = 1 : the GPU listens to the built-in test host
//       SW0 = 0 : the GPU listens to the Arduino header pins
//       BTN1 / BTN2 / BTN3 : run test 1 / 2 / 3   (SW1 = 1: tests 4 / 5 / 6)
//       The test host's SPI is also driven out on the 2x3 SPI header
//       (AR_SS F16, AR_SCK H15, AR_MOSI T12) for the loopback test:
//       wire AR_SS -> AR10, AR_SCK -> AR13, AR_MOSI -> AR11, set SW0 = 0.
//
//   LD0 READY, LD1 clock locked, LD2 toggles per command,
//   LD3 heartbeat (steady on while a test runs), BTN0 reset.
//
// Pure PL design: no Zynq PS, no AXI, no block design needed.
// =============================================================

module fpga_top #(
    parameter DEBOUNCE_BITS = 17,       // buttons sampled every 2^17 clocks = 5.2 ms
    parameter ROM_FILE = "selftest.mem" // test commands (add the file to Vivado)
)(
    input  wire       sysclk,           // 125 MHz
    input  wire       reset,            // BTN0, active high
    input  wire [2:0] btn,              // BTN1 .. BTN3: start a test
    input  wire [1:0] sw,               // SW0: SPI source, SW1: test bank

    // SPI from the Arduino (PYNQ Arduino header AR10 / AR11 / AR13)
    input  wire       spi_cs_n,
    input  wire       spi_sck,
    input  wire       spi_mosi,
    output wire       gpu_ready,        // AR12

    // test host SPI out on the 2x3 SPI header (loopback test)
    output wire       test_cs_n,        // AR_SS
    output wire       test_sck,         // AR_SCK
    output wire       test_mosi,        // AR_MOSI

    // VGA (PMOD A + PMOD B)
    output wire       vga_hs,
    output wire       vga_vs,
    output wire [3:0] vga_r,
    output wire [3:0] vga_g,
    output wire [3:0] vga_b,

    output wire [3:0] led
);

    // ---------------------------------------------------------
    // Clock
    // ---------------------------------------------------------
    wire clk_25m;
    wire clk_locked;

    clk_wiz_0 u_clk (                   // Clocking Wizard IP (see the guide)
        .clk_in1(sysclk),
        .reset(1'b0),
        .clk_out1(clk_25m),
        .locked(clk_locked)
    );

    // core stays in reset until the clock is stable and BTN0 is released
    wire rst_n = clk_locked & ~reset;

    // the same reset, synchronized, for the logic in this file
    (* ASYNC_REG = "TRUE" *) reg [1:0] rst_s;
    always @(posedge clk_25m or negedge rst_n)
        if (!rst_n) rst_s <= 2'b11;
        else        rst_s <= {rst_s[0], 1'b0};
    wire top_reset = rst_s[1];


    // ---------------------------------------------------------
    // Buttons and switches: synchronize, then debounce by sampling
    // slowly (a bouncing contact settles in well under 5 ms)
    // ---------------------------------------------------------
    (* ASYNC_REG = "TRUE" *) reg [4:0] in_m, in_s;     // {sw1, sw0, btn3, btn2, btn1}
    reg [DEBOUNCE_BITS-1:0] tick;
    reg [2:0] btn_q;                                   // buttons at the last sample
    reg       test_start;
    reg [2:0] test_sel;

    always @(posedge clk_25m) begin
        in_m <= {sw, btn};
        in_s <= in_m;
    end

    wire [2:0] btn_s = in_s[2:0];
    wire       sw0_s = in_s[3];
    wire       sw1_s = in_s[4];
    wire [2:0] press = btn_s & ~btn_q;                 // newly pressed at this sample

    always @(posedge clk_25m) begin
        test_start <= 1'b0;
        if (top_reset) begin
            tick  <= 0;
            btn_q <= 3'b000;
        end
        else begin
            tick <= tick + 1'b1;
            if (tick == 0) begin                       // one sample per period
                btn_q <= btn_s;
                if (press != 3'b000) begin
                    test_start <= 1'b1;
                    // BTN1/2/3 -> test 0/1/2, +3 when SW1 is up
                    test_sel <= (press[0] ? 3'd0 : press[1] ? 3'd1 : 3'd2) + (sw1_s ? 3'd3 : 3'd0);
                end
            end
        end
    end


    // ---------------------------------------------------------
    // On-board SPI test host
    // ---------------------------------------------------------
    wire test_busy;

    spi_test_host #(.ROM_FILE(ROM_FILE)) u_test (
        .clk(clk_25m), .reset(top_reset),
        .start(test_start), .test_sel(test_sel), .gpu_ready(gpu_ready),
        .busy(test_busy),
        .spi_cs_n(test_cs_n), .spi_sck(test_sck), .spi_mosi(test_mosi)
    );

    // SPI source for the GPU. Both sources are asynchronous to the GPU's
    // synchronizers anyway, so a plain multiplexer is fine here.
    wire core_cs_n = sw0_s ? test_cs_n : spi_cs_n;
    wire core_sck  = sw0_s ? test_sck  : spi_sck;
    wire core_mosi = sw0_s ? test_mosi : spi_mosi;


    // ---------------------------------------------------------
    // The GPU
    // ---------------------------------------------------------
    wire [7:0] pix;                     // RGB332
    wire       cmd_toggle;

    gpu_core #(
        .FB_W(320), .FB_H(240), .SCALE_SHIFT(1), .PIX_BITS(8), .DOUBLE_BUF(1)
    ) u_gpu (
        .clk(clk_25m), .rst_n(rst_n),
        .spi_cs_n(core_cs_n), .spi_sck(core_sck), .spi_mosi(core_mosi),
        .gpu_ready(gpu_ready),
        .vga_hs(vga_hs), .vga_vs(vga_vs), .vga_pix(pix),
        .dbg_cmd_toggle(cmd_toggle)
    );

    // RGB332 -> RGB444 for the 12-bit adapter (repeat MSBs into the LSBs)
    assign vga_r = {pix[7:5], pix[7]};
    assign vga_g = {pix[4:2], pix[4]};
    assign vga_b = {pix[1:0], pix[1:0]};


    // ---------------------------------------------------------
    // Status LEDs
    // ---------------------------------------------------------
    reg [24:0] heartbeat = 25'd0;
    always @(posedge clk_25m)
        heartbeat <= heartbeat + 1'b1;

    assign led[0] = gpu_ready;
    assign led[1] = clk_locked;
    assign led[2] = cmd_toggle;
    assign led[3] = test_busy | heartbeat[24];

endmodule
