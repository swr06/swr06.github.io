## =============================================================================
## pynq_gpu.xdc  -  PYNQ-Z2 constraints for fpga_top (SPI rasterizer GPU)
##
##  Connector map (all pins are 3.3 V LVCMOS33 programmable-logic pins):
##
##    PMOD A  (JA)  : your video adapter  -> HSYNC, VSYNC, BLUE[3:0]
##    PMOD B  (JB)  : your video adapter  -> RED[3:0], GREEN[3:0]
##    Arduino hdr   : SPI from the external Arduino
##                    D10 = CS_N, D11 = MOSI, D12 = READY (out), D13 = SCK
##    LD0..LD3      : status LEDs        BTN0 : reset
##
##  PMOD numbering (looking at the connector):  top row 1 2 3 4 [5=GND] [6=3V3]
##                                              bottom 7 8 9 10 [11=GND] [12=3V3]
## =============================================================================

## ---------------------------------------------------------------- clock / reset
## 125 MHz oscillator (from the Ethernet PHY) on PL pin H16
set_property -dict { PACKAGE_PIN H16 IOSTANDARD LVCMOS33 } [get_ports sysclk]
create_clock -add -name sys_clk_pin -period 8.00 -waveform {0 4} [get_ports sysclk]

## BTN0, active high
set_property -dict { PACKAGE_PIN D19 IOSTANDARD LVCMOS33 } [get_ports reset]

## ---------------------------------------------------------------- LEDs
## LD0 = READY   LD1 = clock locked   LD2 = toggles per command   LD3 = heartbeat
set_property -dict { PACKAGE_PIN R14 IOSTANDARD LVCMOS33 } [get_ports {led[0]}]
set_property -dict { PACKAGE_PIN P14 IOSTANDARD LVCMOS33 } [get_ports {led[1]}]
set_property -dict { PACKAGE_PIN N16 IOSTANDARD LVCMOS33 } [get_ports {led[2]}]
set_property -dict { PACKAGE_PIN M14 IOSTANDARD LVCMOS33 } [get_ports {led[3]}]

## ---------------------------------------------------------------- VGA, PMOD A (JA)
## unchanged from your old pynq.xdc.   JA1 (Y18) and JA7 (U18) stay unused.
set_property -dict { PACKAGE_PIN Y19 IOSTANDARD LVCMOS33 } [get_ports vga_hs]      ;# JA2
set_property -dict { PACKAGE_PIN U19 IOSTANDARD LVCMOS33 } [get_ports vga_vs]      ;# JA8
set_property -dict { PACKAGE_PIN Y17 IOSTANDARD LVCMOS33 } [get_ports {vga_b[0]}]  ;# JA4
set_property -dict { PACKAGE_PIN W19 IOSTANDARD LVCMOS33 } [get_ports {vga_b[1]}]  ;# JA10
set_property -dict { PACKAGE_PIN Y16 IOSTANDARD LVCMOS33 } [get_ports {vga_b[2]}]  ;# JA3
set_property -dict { PACKAGE_PIN W18 IOSTANDARD LVCMOS33 } [get_ports {vga_b[3]}]  ;# JA9

## ---------------------------------------------------------------- VGA, PMOD B (JB)
set_property -dict { PACKAGE_PIN T10 IOSTANDARD LVCMOS33 } [get_ports {vga_r[0]}]  ;# JB4
set_property -dict { PACKAGE_PIN W13 IOSTANDARD LVCMOS33 } [get_ports {vga_r[1]}]  ;# JB10
set_property -dict { PACKAGE_PIN T11 IOSTANDARD LVCMOS33 } [get_ports {vga_r[2]}]  ;# JB3
set_property -dict { PACKAGE_PIN V12 IOSTANDARD LVCMOS33 } [get_ports {vga_r[3]}]  ;# JB9
set_property -dict { PACKAGE_PIN Y14 IOSTANDARD LVCMOS33 } [get_ports {vga_g[0]}]  ;# JB2
set_property -dict { PACKAGE_PIN W16 IOSTANDARD LVCMOS33 } [get_ports {vga_g[1]}]  ;# JB8
set_property -dict { PACKAGE_PIN W14 IOSTANDARD LVCMOS33 } [get_ports {vga_g[2]}]  ;# JB1
set_property -dict { PACKAGE_PIN V16 IOSTANDARD LVCMOS33 } [get_ports {vga_g[3]}]  ;# JB7

## ---------------------------------------------------------------- SPI, Arduino header
## Same header positions an Arduino SPI shield uses. 3.3 V ONLY - see the wiring step.
## Pull-ups/downs keep the bus idle when the Arduino is unplugged or in reset.
set_property -dict { PACKAGE_PIN T16 IOSTANDARD LVCMOS33 PULLUP   true } [get_ports spi_cs_n]   ;# D10
set_property -dict { PACKAGE_PIN R17 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports spi_mosi]   ;# D11
set_property -dict { PACKAGE_PIN N17 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports spi_sck]    ;# D13
set_property -dict { PACKAGE_PIN P18 IOSTANDARD LVCMOS33 DRIVE 8 }        [get_ports gpu_ready]  ;# D12

## ---------------------------------------------------------------- timing exceptions
## SPI pins and BTN0 are asynchronous: they only enter 2-flop synchronizers.
set_false_path -from [get_ports {spi_cs_n spi_sck spi_mosi reset}]
## Board outputs have no timing relationship we need to analyse.
set_false_path -to [get_ports {vga_* gpu_ready led[*]}]
