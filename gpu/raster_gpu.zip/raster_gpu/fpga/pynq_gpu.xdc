## =============================================================================
## pynq_gpu.xdc  -  PYNQ-Z2 constraints for fpga_top (SPI rasterizer GPU)
##
##  All pins are 3.3 V LVCMOS33 programmable-logic pins. Names in the ;# comments
##  are the labels of the PYNQ-Z2 reference manual / schematic.
##
##    PMOD A  (JA)   : your video adapter -> HSYNC, VSYNC, BLUE[3:0]
##    PMOD B  (JB)   : your video adapter -> RED[3:0], GREEN[3:0]
##    Arduino header : SPI from the external Arduino (board labels AR0 .. AR13)
##                     AR10 = CS_N, AR11 = MOSI, AR12 = READY (out), AR13 = SCK
##    SPI header 2x3 : on-board test host OUT (loopback test)
##                     AR_SS (pin 5), AR_SCK (pin 3), AR_MOSI (pin 4)
##    BTN0 reset, BTN1..BTN3 run a test, SW0 SPI source, SW1 test bank
##    LD0..LD3 status LEDs
##
##  PMOD pins: JA-2 means PMOD A physical pin 2. The PYNQ-Z2 manual calls that
##  pin JA1_N (pins come in P/N pairs: 1/2 = JA1_P/N, 3/4 = JA2_P/N, 7/8 = JA3_P/N,
##  9/10 = JA4_P/N), so "JA2" alone is ambiguous. Pins 5/11 = GND, 6/12 = 3.3 V.
## =============================================================================

## ---------------------------------------------------------------- clock / reset
## 125 MHz oscillator (from the Ethernet PHY) on PL pin H16
set_property -dict { PACKAGE_PIN H16 IOSTANDARD LVCMOS33 } [get_ports sysclk]
create_clock -add -name sys_clk_pin -period 8.00 -waveform {0 4} [get_ports sysclk]

## BTN0, active high
set_property -dict { PACKAGE_PIN D19 IOSTANDARD LVCMOS33 } [get_ports reset]        ;# BTN0

## ---------------------------------------------------------------- test buttons / switches
set_property -dict { PACKAGE_PIN D20 IOSTANDARD LVCMOS33 } [get_ports {btn[0]}]     ;# BTN1
set_property -dict { PACKAGE_PIN L20 IOSTANDARD LVCMOS33 } [get_ports {btn[1]}]     ;# BTN2
set_property -dict { PACKAGE_PIN L19 IOSTANDARD LVCMOS33 } [get_ports {btn[2]}]     ;# BTN3
set_property -dict { PACKAGE_PIN M20 IOSTANDARD LVCMOS33 } [get_ports {sw[0]}]      ;# SW0
set_property -dict { PACKAGE_PIN M19 IOSTANDARD LVCMOS33 } [get_ports {sw[1]}]      ;# SW1

## ---------------------------------------------------------------- LEDs
## LD0 = READY   LD1 = clock locked   LD2 = toggles per command   LD3 = heartbeat / test running
set_property -dict { PACKAGE_PIN R14 IOSTANDARD LVCMOS33 } [get_ports {led[0]}]     ;# LD0
set_property -dict { PACKAGE_PIN P14 IOSTANDARD LVCMOS33 } [get_ports {led[1]}]     ;# LD1
set_property -dict { PACKAGE_PIN N16 IOSTANDARD LVCMOS33 } [get_ports {led[2]}]     ;# LD2
set_property -dict { PACKAGE_PIN M14 IOSTANDARD LVCMOS33 } [get_ports {led[3]}]     ;# LD3

## ---------------------------------------------------------------- VGA, PMOD A (JA)
## unchanged from your old pynq.xdc.   JA-1 (Y18) and JA-7 (U18) stay unused.
set_property -dict { PACKAGE_PIN Y19 IOSTANDARD LVCMOS33 } [get_ports vga_hs]      ;# JA-2 (JA1_N)
set_property -dict { PACKAGE_PIN U19 IOSTANDARD LVCMOS33 } [get_ports vga_vs]      ;# JA-8 (JA3_N)
set_property -dict { PACKAGE_PIN Y17 IOSTANDARD LVCMOS33 } [get_ports {vga_b[0]}]  ;# JA-4 (JA2_N)
set_property -dict { PACKAGE_PIN W19 IOSTANDARD LVCMOS33 } [get_ports {vga_b[1]}]  ;# JA-10 (JA4_N)
set_property -dict { PACKAGE_PIN Y16 IOSTANDARD LVCMOS33 } [get_ports {vga_b[2]}]  ;# JA-3 (JA2_P)
set_property -dict { PACKAGE_PIN W18 IOSTANDARD LVCMOS33 } [get_ports {vga_b[3]}]  ;# JA-9 (JA4_P)

## ---------------------------------------------------------------- VGA, PMOD B (JB)
set_property -dict { PACKAGE_PIN T10 IOSTANDARD LVCMOS33 } [get_ports {vga_r[0]}]  ;# JB-4 (JB2_N)
set_property -dict { PACKAGE_PIN W13 IOSTANDARD LVCMOS33 } [get_ports {vga_r[1]}]  ;# JB-10 (JB4_N)
set_property -dict { PACKAGE_PIN T11 IOSTANDARD LVCMOS33 } [get_ports {vga_r[2]}]  ;# JB-3 (JB2_P)
set_property -dict { PACKAGE_PIN V12 IOSTANDARD LVCMOS33 } [get_ports {vga_r[3]}]  ;# JB-9 (JB4_P)
set_property -dict { PACKAGE_PIN Y14 IOSTANDARD LVCMOS33 } [get_ports {vga_g[0]}]  ;# JB-2 (JB1_N)
set_property -dict { PACKAGE_PIN W16 IOSTANDARD LVCMOS33 } [get_ports {vga_g[1]}]  ;# JB-8 (JB3_N)
set_property -dict { PACKAGE_PIN W14 IOSTANDARD LVCMOS33 } [get_ports {vga_g[2]}]  ;# JB-1 (JB1_P)
set_property -dict { PACKAGE_PIN V16 IOSTANDARD LVCMOS33 } [get_ports {vga_g[3]}]  ;# JB-7 (JB3_P)

## ---------------------------------------------------------------- SPI in, Arduino header
## The sockets an Arduino SPI shield uses (AR10..AR13). 3.3 V ONLY - see the wiring step.
## Pull-ups/downs keep the bus idle when nothing is plugged in.
set_property -dict { PACKAGE_PIN T16 IOSTANDARD LVCMOS33 PULLUP   true } [get_ports spi_cs_n]   ;# AR10
set_property -dict { PACKAGE_PIN R17 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports spi_mosi]   ;# AR11
set_property -dict { PACKAGE_PIN N17 IOSTANDARD LVCMOS33 PULLDOWN true } [get_ports spi_sck]    ;# AR13
set_property -dict { PACKAGE_PIN P18 IOSTANDARD LVCMOS33 DRIVE 8 }        [get_ports gpu_ready]  ;# AR12

## ---------------------------------------------------------------- SPI out, 2x3 SPI header
## The on-board test host's SPI, for the loopback test (jumper these to AR10/AR13/AR11).
set_property -dict { PACKAGE_PIN F16 IOSTANDARD LVCMOS33 DRIVE 8 } [get_ports test_cs_n]  ;# AR_SS
set_property -dict { PACKAGE_PIN H15 IOSTANDARD LVCMOS33 DRIVE 8 } [get_ports test_sck]   ;# AR_SCK
set_property -dict { PACKAGE_PIN T12 IOSTANDARD LVCMOS33 DRIVE 8 } [get_ports test_mosi]  ;# AR_MOSI

## ---------------------------------------------------------------- timing exceptions
## SPI pins, buttons and switches are asynchronous: they only enter 2-flop synchronizers.
set_false_path -from [get_ports {spi_cs_n spi_sck spi_mosi reset btn[*] sw[*]}]
## Board outputs have no timing relationship we need to analyse.
set_false_path -to [get_ports {vga_* gpu_ready led[*] test_*}]
