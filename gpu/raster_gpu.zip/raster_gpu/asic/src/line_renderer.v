`timescale 1ns / 1ps

// =============================================================
// line_renderer : Bresenham line, all 8 octants, integer only
//
//   dx  = |x1 - x0|          sx = +1 if x0 < x1 else -1
//   dy  = -|y1 - y0|         sy = +1 if y0 < y1 else -1
//   err = dx + dy
//   loop:  plot(x, y)
//          if (x, y) == (x1, y1): done
//          e2 = 2 * err
//          if e2 >= dy: err += dy, x += sx      (step in x)
//          if e2 <= dx: err += dx, y += sy      (step in y)
//
// One pixel per clock, both end points included. Coordinates are
// signed, so a line may start or end off screen: gpu_core clips
// every pixel, this module only walks the line.
// =============================================================

module line_renderer #(
    parameter CW = 12                   // signed coordinate width
)(
    input  wire clk,
    input  wire reset,

    input  wire start,                  // 1-clock pulse, args valid
    input  wire signed [CW-1:0] x0,
    input  wire signed [CW-1:0] y0,
    input  wire signed [CW-1:0] x1,
    input  wire signed [CW-1:0] y1,

    output reg  busy,
    output wire plot,                   // (x, y) is a pixel of the line
    output reg  signed [CW-1:0] x,
    output reg  signed [CW-1:0] y
);

    // |dx|, |dy| need CW+1 bits, their sum one more, plus sign
    localparam EW = CW + 2;

    // ---- set-up values, computed straight from the inputs ----
    // sign-extend first, so x1 - x0 can never overflow
    wire signed [EW-1:0] x0_e = {{2{x0[CW-1]}}, x0};
    wire signed [EW-1:0] x1_e = {{2{x1[CW-1]}}, x1};
    wire signed [EW-1:0] y0_e = {{2{y0[CW-1]}}, y0};
    wire signed [EW-1:0] y1_e = {{2{y1[CW-1]}}, y1};

    wire signed [EW-1:0] dx_in  = x1_e - x0_e;
    wire signed [EW-1:0] dy_in  = y1_e - y0_e;
    wire signed [EW-1:0] adx_in = dx_in[EW-1] ? -dx_in : dx_in;
    wire signed [EW-1:0] ady_in = dy_in[EW-1] ? -dy_in : dy_in;

    // ---- line state ----
    reg signed [EW-1:0] dx;             // +|x1 - x0|
    reg signed [EW-1:0] dy;             // -|y1 - y0|
    reg signed [EW-1:0] err;
    reg                 sx, sy;         // 1 = step +1, 0 = step -1
    reg signed [CW-1:0] x_end, y_end;

    // ---- one Bresenham step ----
    // compare at EW+1 bits. Note: {..} is always UNSIGNED in Verilog,
    // so the extended copies get their own signed wires.
    wire signed [EW:0]  e2     = {err, 1'b0};        // 2 * err
    wire signed [EW:0]  dx_w   = {dx[EW-1], dx};
    wire signed [EW:0]  dy_w   = {dy[EW-1], dy};
    wire                step_x = (e2 >= dy_w);
    wire                step_y = (e2 <= dx_w);
    wire signed [EW-1:0] add_x = step_x ? dy : {EW{1'b0}};
    wire signed [EW-1:0] add_y = step_y ? dx : {EW{1'b0}};
    wire                at_end = (x == x_end) && (y == y_end);

    assign plot = busy;                 // every busy clock is one pixel

    always @(posedge clk) begin
        if (reset)
            busy <= 1'b0;

        else if (!busy) begin
            if (start) begin
                busy  <= 1'b1;
                x     <= x0;
                y     <= y0;
                x_end <= x1;
                y_end <= y1;
                dx    <= adx_in;
                dy    <= -ady_in;
                err   <= adx_in - ady_in;
                sx    <= (x0 < x1);
                sy    <= (y0 < y1);
            end
        end

        else if (at_end)
            busy <= 1'b0;               // last pixel was plotted this clock

        else begin
            if (step_x) x <= sx ? x + 1'b1 : x - 1'b1;
            if (step_y) y <= sy ? y + 1'b1 : y - 1'b1;
            err <= err + add_x + add_y;
        end
    end

endmodule
