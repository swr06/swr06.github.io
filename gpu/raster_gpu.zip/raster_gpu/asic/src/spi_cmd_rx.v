`timescale 1ns / 1ps

// =============================================================
// spi_cmd_rx : SPI command receiver (mode 0, MSB first, write only)
//
// SCK is never used as a clock. The three SPI pins are sampled by
// the 25 MHz core clock through 2-flop synchronizers and the SCK
// edges are found inside the clk domain, so the whole GPU stays in
// ONE clock domain.  Rule of thumb: f_sck <= f_clk / 8  (~3 MHz).
//
// A frame = CS falls, exactly CMD_BITS rising SCK edges, CS rises.
// Short or long frames are dropped. After reset the receiver waits
// for a CS falling edge, so half a frame can never become a command.
// =============================================================

module spi_cmd_rx #(
    parameter CMD_BITS = 80
)(
    input  wire clk,
    input  wire reset,

    // SPI pins (asynchronous to clk)
    input  wire spi_cs_n,
    input  wire spi_sck,
    input  wire spi_mosi,

    output wire bus_idle,                  // CS has been high for 2 clocks
    output reg  cmd_valid,                 // 1-clock pulse: cmd_word is new
    output reg  [CMD_BITS-1:0] cmd_word
);

    localparam CNT_BITS = $clog2(CMD_BITS + 2);
    localparam [CNT_BITS-1:0] FULL = CMD_BITS;       // a complete frame
    localparam [CNT_BITS-1:0] OVER = CMD_BITS + 1;   // too long / not started

    // ---------------------------------------------------------
    // Synchronizers. Each pin goes through a shift register:
    //   [0] may go metastable, [1] is the clean synchronized value,
    //   [2] is [1] one clock older (for edge detection).
    // ---------------------------------------------------------
    (* ASYNC_REG = "TRUE" *) reg [2:0] cs_s;
    (* ASYNC_REG = "TRUE" *) reg [2:0] sck_s;
    (* ASYNC_REG = "TRUE" *) reg [1:0] mosi_s;

    always @(posedge clk) begin
        if (reset) begin
            cs_s   <= 3'b111;                // idle: CS high
            sck_s  <= 3'b000;                // idle: SCK low (mode 0)
            mosi_s <= 2'b00;
        end
        else begin
            cs_s   <= {cs_s[1:0],  spi_cs_n};
            sck_s  <= {sck_s[1:0], spi_sck};
            mosi_s <= {mosi_s[0],  spi_mosi};
        end
    end

    wire cs_low   = !cs_s[1];
    wire cs_fall  = !cs_s[1] &&  cs_s[2];
    wire cs_rise  =  cs_s[1] && !cs_s[2];
    wire sck_rise =  sck_s[1] && !sck_s[2];
    wire mosi     =  mosi_s[1];

    assign bus_idle = cs_s[1] && cs_s[2];


    // ---------------------------------------------------------
    // Frame receiver
    // ---------------------------------------------------------
    reg [CNT_BITS-1:0] bit_count;
    reg [CMD_BITS-1:0] shift_reg;

    always @(posedge clk) begin
        cmd_valid <= 1'b0;                              // default: no pulse

        if (reset)
            bit_count <= OVER;                          // wait for a CS fall
        else if (cs_fall)
            bit_count <= 0;                             // frame starts
        else if (cs_rise) begin                         // frame ends
            if (bit_count == FULL) begin
                cmd_word  <= shift_reg;
                cmd_valid <= 1'b1;
            end
        end
        else if (cs_low && sck_rise) begin              // one bit
            shift_reg <= {shift_reg[CMD_BITS-2:0], mosi};
            if (bit_count != OVER)                      // saturate: a long
                bit_count <= bit_count + 1'b1;          // frame stays invalid
        end
    end

endmodule
