`timescale 1ns / 1ps

// =============================================================
// circle_renderer : midpoint (Bresenham) circle, outline or filled
//
// Walks one octant (from (r, 0) up to the 45 degree diagonal) and
// uses the 8-way symmetry of the circle for the rest:
//
//   x = r, y = 0, d = 1 - r
//   while x >= y:
//       draw step (x, y)                       <- 8 points or 4 spans
//       y = y + 1
//       if d < 0:  d = d + 2*y + 1             (stay on this column)
//       else:      x = x - 1
//                  d = d + 2*(y - x) + 1       (step inwards)
//
// OUTLINE : 8 pixels per step, one per clock
//           (cx+-x, cy+-y) and (cx+-y, cy+-x)
// FILLED  : up to 4 horizontal spans per step
//           rows cy+-y from cx-x to cx+x      (every step)
//           rows cy+-x from cx-y to cx+y      (only on the last step
//                                              before x changes, so
//                                              each row is drawn once)
//           Spans are clipped to the screen before they are walked,
//           so off-screen parts cost no clocks.
//
// Only adds, subtracts and compares: no multiplier, no square root.
// gpu_core clips every pixel again, so nothing can be written
// outside the framebuffer whatever cx, cy and r are.
// =============================================================

module circle_renderer #(
    parameter CW       = 15,            // signed width of cx, cy, x, y, d
    parameter RW       = 11,            // radius bits (0 .. 2047)
    parameter SCREEN_W = 320,
    parameter SCREEN_H = 240
)(
    input  wire clk,
    input  wire reset,

    input  wire start,                  // 1-clock pulse, args valid
    input  wire fill,                   // 0 = outline, 1 = filled disc
    input  wire signed [CW-1:0] cx_in,
    input  wire signed [CW-1:0] cy_in,
    input  wire [RW-1:0]        r_in,

    output reg  busy,
    output wire plot,
    output wire signed [CW-1:0] px,
    output wire signed [CW-1:0] py
);

    localparam signed [CW-1:0] ONE  = 1;
    localparam signed [CW-1:0] ZERO = 0;
    localparam X_LAST = SCREEN_W - 1;
    localparam Y_LAST = SCREEN_H - 1;
    localparam signed [CW-1:0] XMAX = X_LAST[CW-1:0];
    localparam signed [CW-1:0] YMAX = Y_LAST[CW-1:0];

    localparam [1:0] S_POINTS   = 2'd0;  // outline: 8 points per step
    localparam [1:0] S_SPAN_SET = 2'd1;  // filled: choose + clip a span
    localparam [1:0] S_SPAN_RUN = 2'd2;  // filled: walk the span

    reg [1:0] state;
    reg signed [CW-1:0] cx, cy;          // centre
    reg signed [CW-1:0] x, y, d;         // octant position + decision
    reg [2:0] k;                         // outline: which of the 8 points
    reg [1:0] s;                         // filled:  which of the 4 spans
    reg signed [CW-1:0] run_x, run_end, run_row;   // span being walked


    // ---------------------------------------------------------
    // Next midpoint step (used by both modes)
    // ---------------------------------------------------------
    wire                 d_neg = d[CW-1];             // d < 0
    wire signed [CW-1:0] y_n   = y + ONE;
    wire signed [CW-1:0] x_n   = d_neg ? x : x - ONE;
    wire signed [CW-1:0] inc   = d_neg ? y_n : y_n - x_n;
    wire signed [CW-1:0] d_n   = d + (inc <<< 1) + ONE;
    wire                 last  = (x_n < y_n);         // octant finished


    // ---------------------------------------------------------
    // OUTLINE: point k of the 8 symmetric points
    // ---------------------------------------------------------
    reg signed [CW-1:0] ox, oy;          // offset from the centre

    always @(*) begin
        case (k)
            3'd0:    begin ox =  x; oy =  y; end
            3'd1:    begin ox =  y; oy =  x; end
            3'd2:    begin ox = -y; oy =  x; end
            3'd3:    begin ox = -x; oy =  y; end
            3'd4:    begin ox = -x; oy = -y; end
            3'd5:    begin ox = -y; oy = -x; end
            3'd6:    begin ox =  y; oy = -x; end
            default: begin ox =  x; oy = -y; end
        endcase
    end


    // ---------------------------------------------------------
    // FILLED: span s of the current step
    //   s = 0 : row cy + y, half width x      s = 2 : row cy + x, half width y
    //   s = 1 : row cy - y, half width x      s = 3 : row cy - x, half width y
    // ---------------------------------------------------------
    wire signed [CW-1:0] row_off = s[1] ? x : y;
    wire signed [CW-1:0] half    = s[1] ? y : x;
    wire signed [CW-1:0] row     = s[0] ? cy - row_off : cy + row_off;

    // which spans are needed in this step (each row exactly once)
    wire span_on = s[1] ? ((!d_neg || last) && (x != y))   // x rows: widest span only
                        : (!s[0] || (y != ZERO));          // y rows: row cy-0 = cy+0

    // clip the span to the screen
    wire signed [CW-1:0] left   = cx - half;
    wire signed [CW-1:0] right  = cx + half;
    wire signed [CW-1:0] left_c = (left  < ZERO) ? ZERO : left;
    wire signed [CW-1:0] rght_c = (right > XMAX) ? XMAX : right;

    wire span_visible = span_on && (row >= ZERO) && (row <= YMAX) && (left_c <= rght_c);


    // ---------------------------------------------------------
    // Control
    // ---------------------------------------------------------
    wire span_done = (state == S_SPAN_SET && !span_visible) ||
                     (state == S_SPAN_RUN && run_x == run_end);

    // advance (x, y, d) after the 8th point or after the 4th span
    wire step = (state == S_POINTS) ? (k == 3'd7) : (span_done && s == 2'd3);

    assign plot = busy && (state == S_POINTS || state == S_SPAN_RUN);
    assign px   = (state == S_POINTS) ? cx + ox : run_x;
    assign py   = (state == S_POINTS) ? cy + oy : run_row;

    always @(posedge clk) begin
        if (reset)
            busy <= 1'b0;

        else if (!busy) begin
            if (start) begin
                busy  <= 1'b1;
                state <= fill ? S_SPAN_SET : S_POINTS;
                cx    <= cx_in;
                cy    <= cy_in;
                x     <= $signed({{(CW-RW){1'b0}}, r_in});
                y     <= ZERO;
                d     <= ONE - $signed({{(CW-RW){1'b0}}, r_in});
                k     <= 3'd0;
                s     <= 2'd0;
            end
        end

        else begin
            case (state)
                S_POINTS:
                    k <= k + 1'b1;                      // wraps 7 -> 0

                S_SPAN_SET:
                    if (span_visible) begin
                        run_x   <= left_c;
                        run_end <= rght_c;
                        run_row <= row;
                        state   <= S_SPAN_RUN;
                    end

                default:                                // S_SPAN_RUN
                    if (run_x != run_end)
                        run_x <= run_x + ONE;
                    else
                        state <= S_SPAN_SET;
            endcase

            if (span_done)
                s <= s + 1'b1;                          // wraps 3 -> 0

            if (step) begin
                x <= x_n;
                y <= y_n;
                d <= d_n;
                if (last)
                    busy <= 1'b0;
            end
        end
    end

endmodule
