`timescale 1ns / 1ps

// =============================================================
// vga_controller : 640x480 @ 60 Hz scan-out (25 MHz pixel clock)
//
// The framebuffer is smaller than the screen: every FB pixel is
// repeated (1 << SCALE_SHIFT) times in X and in Y.
//    FPGA : 320 x 240, SCALE_SHIFT = 1   ( 2 x  2 screen pixels)
//    SRAM :  80 x  60, SCALE_SHIFT = 3   ( 8 x  8)
//    ASIC :  40 x  30, SCALE_SHIFT = 4   (16 x 16)
//
// Timing of one pixel (the FB read takes one clock):
//    clock t   : counters -> fb_addr
//    clock t+1 : FB returns fb_data, sync/visible delayed by 1
//    clock t+2 : hsync, vsync, pixel registered on the pins
// =============================================================

module vga_controller #(
    parameter FB_WIDTH    = 320,
    parameter SCALE_SHIFT = 1,
    parameter PIX_BITS    = 8,
    parameter ADDR_BITS   = 17          // >= 11, address of one buffer
)(
    input  wire clk,
    input  wire reset,
    input  wire frame_valid,            // black until the FB is cleared

    output wire [ADDR_BITS-1:0] fb_addr,   // pixel index into the FB
    input  wire [PIX_BITS-1:0]  fb_data,   // arrives one clock later

    output wire vblank_start,           // 1-clock pulse, first blank line

    output reg  hsync,                  // active low
    output reg  vsync,                  // active low
    output reg  [PIX_BITS-1:0] pixel
);

    // 640x480 @ 60 Hz (VESA): visible, front porch, sync, back porch
    localparam H_VIS = 640, H_FP = 16, H_SYNC = 96, H_BP = 48;
    localparam V_VIS = 480, V_FP = 10, V_SYNC = 2,  V_BP = 33;
    localparam H_TOTAL = H_VIS + H_FP + H_SYNC + H_BP;      // 800
    localparam V_TOTAL = V_VIS + V_FP + V_SYNC + V_BP;      // 525

    reg [9:0] h_count;                  // 0 .. 799
    reg [9:0] v_count;                  // 0 .. 524

    wire visible = (h_count < H_VIS) && (v_count < V_VIS);
    wire h_sync  = (h_count >= H_VIS + H_FP) && (h_count < H_VIS + H_FP + H_SYNC);
    wire v_sync  = (v_count >= V_VIS + V_FP) && (v_count < V_VIS + V_FP + V_SYNC);

    assign vblank_start = (h_count == 0) && (v_count == V_VIS);

    // framebuffer coordinate = screen coordinate / scale
    wire [ADDR_BITS-1:0] fb_x = {{(ADDR_BITS-10){1'b0}}, h_count >> SCALE_SHIFT};
    wire [ADDR_BITS-1:0] fb_y = {{(ADDR_BITS-10){1'b0}}, v_count >> SCALE_SHIFT};

    // y * FB_WIDTH is a constant multiply: synthesis builds it from
    // shifts and adds (320: (y<<8)+(y<<6), 40: (y<<5)+(y<<3)).
    localparam [ADDR_BITS-1:0] STRIDE = FB_WIDTH[ADDR_BITS-1:0];
    assign fb_addr = visible ? fb_y * STRIDE + fb_x : {ADDR_BITS{1'b0}};

    reg visible_d, h_sync_d, v_sync_d;   // delayed by the FB read latency

    always @(posedge clk) begin
        if (reset) begin
            h_count   <= 0;
            v_count   <= 0;
            visible_d <= 1'b0;
            h_sync_d  <= 1'b0;
            v_sync_d  <= 1'b0;
            hsync     <= 1'b1;
            vsync     <= 1'b1;
            pixel     <= 0;
        end
        else begin
            // counters: h wraps every 800 clocks, v every 525 lines
            if (h_count == H_TOTAL - 1) begin
                h_count <= 0;
                v_count <= (v_count == V_TOTAL - 1) ? 10'd0 : v_count + 1'b1;
            end
            else
                h_count <= h_count + 1'b1;

            // stage 1: wait for the FB data
            visible_d <= visible && frame_valid;
            h_sync_d  <= h_sync;
            v_sync_d  <= v_sync;

            // stage 2: registered outputs, sync pulses are negative
            hsync <= !h_sync_d;
            vsync <= !v_sync_d;
            pixel <= visible_d ? fb_data : {PIX_BITS{1'b0}};
        end
    end

endmodule
