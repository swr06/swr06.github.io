`timescale 1ns / 1ps

// =============================================================
// rect_filler : filled rectangle, one pixel per clock
//
// Walks x from x0 to x1, then the next row, until (x1, y1).
// The corners are inclusive and already clipped to the screen by
// gpu_core (0 <= x0 <= x1 < W, 0 <= y0 <= y1 < H), so every clock
// is a visible pixel. CLEAR is a full-screen rectangle.
// =============================================================

module rect_filler #(
    parameter XW = 9,                   // x bits (320 -> 9)
    parameter YW = 8                    // y bits (240 -> 8)
)(
    input  wire clk,
    input  wire reset,

    input  wire start,                  // 1-clock pulse, args valid
    input  wire [XW-1:0] x0,
    input  wire [YW-1:0] y0,
    input  wire [XW-1:0] x1,
    input  wire [YW-1:0] y1,

    output reg  busy,
    output wire plot,
    output reg  [XW-1:0] x,
    output reg  [YW-1:0] y
);

    reg [XW-1:0] x_first, x_last;
    reg [YW-1:0] y_last;

    assign plot = busy;

    always @(posedge clk) begin
        if (reset)
            busy <= 1'b0;

        else if (!busy) begin
            if (start) begin
                busy    <= 1'b1;
                x       <= x0;
                y       <= y0;
                x_first <= x0;
                x_last  <= x1;
                y_last  <= y1;
            end
        end

        else if (x != x_last)
            x <= x + 1'b1;              // next pixel in the row

        else if (y != y_last) begin
            x <= x_first;               // next row
            y <= y + 1'b1;
        end

        else
            busy <= 1'b0;               // (x1, y1) was the last pixel
    end

endmodule
