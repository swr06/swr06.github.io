`timescale 1ns / 1ps

// =============================================================
// Frame buffer : 1 write port (draw engines) + 1 read port (VGA)
//
//  FPGA : DEPTH = 2 * 320 * 240 (double buffered), PIX_BITS = 8
//         -> Vivado infers block RAM
//  ASIC : DEPTH = 40 * 30 (single buffer), PIX_BITS = 3
//         -> Yosys builds it out of flip-flops + a read mux
//
// Read data is registered: it appears 1 clock after addr_read.
// No "initial" block on purpose: an ASIC has no power-on contents,
// gpu_core clears the memory after reset instead.
// =============================================================

module frame_buffer #(
    parameter PIX_BITS  = 8,
    parameter DEPTH     = 153600,
    parameter ADDR_BITS = 18
)(
    input wire clk,

    // Write port
    input wire                 write_en,
    input wire [ADDR_BITS-1:0] addr_write,
    input wire [PIX_BITS-1:0]  write_data,

    // Read port
    input  wire [ADDR_BITS-1:0] addr_read,
    output reg  [PIX_BITS-1:0]  read_data
);

    (* ram_style = "block" *)
    reg [PIX_BITS-1:0] mem [0 : DEPTH-1];

    // Write port
    always @(posedge clk) begin
        if (write_en)
            mem[addr_write] <= write_data;
    end

    // Read port
    always @(posedge clk) begin
        read_data <= mem[addr_read];
    end

endmodule
