`timescale 1ns / 1ps

// =============================================================
// gpu_asic : the block we harden with LibreLane (Classic flow)
//
// Same gpu_core as the FPGA, smaller framebuffer (standard-cell
// flip-flops, no SRAM yet):
//     40 x 30 pixels, 3 bits (RGB111), single buffer, 16x16 scaling
//
// 11 signal pins -> 11 GPIO pads later in chip_top.v
//     in : clk, rst_n, spi_cs_n, spi_sck, spi_mosi
//     out: gpu_ready, vga_hs, vga_vs, vga_rgb[2:0]
// =============================================================

module gpu_asic (
`ifdef USE_POWER_PINS
    inout  wire VPWR,         // only visible in powered netlists / chip_top sim
    inout  wire VGND,
`endif
    input  wire clk,          // 25.175 MHz oscillator
    input  wire rst_n,

    input  wire spi_cs_n,
    input  wire spi_sck,
    input  wire spi_mosi,
    output wire gpu_ready,

    output wire vga_hs,
    output wire vga_vs,
    output wire [2:0] vga_rgb   // {R, G, B}
);

    gpu_core #(
        .FB_W(40),
        .FB_H(30),
        .SCALE_SHIFT(4),
        .PIX_BITS(3),
        .DOUBLE_BUF(0)
    ) u_gpu (
        .clk(clk),
        .rst_n(rst_n),
        .spi_cs_n(spi_cs_n),
        .spi_sck(spi_sck),
        .spi_mosi(spi_mosi),
        .gpu_ready(gpu_ready),
        .vga_hs(vga_hs),
        .vga_vs(vga_vs),
        .vga_pix(vga_rgb),
        /* verilator lint_off PINCONNECTEMPTY */
        .dbg_cmd_toggle()                  // debug LED output, not needed on the chip
        /* verilator lint_on PINCONNECTEMPTY */
    );

endmodule
