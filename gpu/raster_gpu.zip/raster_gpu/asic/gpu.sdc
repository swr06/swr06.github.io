# =============================================================
# gpu.sdc : timing constraints for the gpu_asic macro
# =============================================================

# 25.175 MHz VGA pixel clock (39.72 ns)
create_clock -name clk -period 39.72 [get_ports clk]
set_clock_uncertainty 0.5 [get_clocks clk]
set_clock_transition  0.15 [get_clocks clk]

# Realistic edges at the macro pins (pads sit ~200 um away)
set_input_transition 0.5 [get_ports {rst_n spi_cs_n spi_sck spi_mosi}]
set_load 0.05 [all_outputs]

# ---- CDC: asynchronous inputs ----
# spi_* and rst_n are NOT synchronous to clk. They only enter the first
# flop of a 2-FF synchronizer, so the path pin -> first flop has no
# meaningful setup/hold requirement. Everything after the first flop
# (meta -> sync -> logic) is still fully timed.
set_false_path -from [get_ports {rst_n spi_cs_n spi_sck spi_mosi}]

# ---- outputs ----
# All outputs come straight from flip-flops. Budget 10 ns for the pad +
# board, the rest of the 39.7 ns period is for the clock-to-Q path.
set_output_delay -clock clk -max 10.0 [get_ports {gpu_ready vga_hs vga_vs vga_rgb*}]
set_output_delay -clock clk -min 0.0  [get_ports {gpu_ready vga_hs vga_vs vga_rgb*}]
