// =============================================================
// gpu_demo.ino  -  host for the SPI rasterizer GPU (PYNQ-Z2 or SKY130 ASIC)
//
// Board : Arduino Uno / Nano (ATmega328P, 5 V)  -> needs the 3 dividers
//         from the wiring step, or any 3.3 V board wired directly.
//
//   Arduino pin      PYNQ-Z2 Arduino header      GPU signal
//   -----------      ----------------------      ----------
//   D13 (SCK)   -->  D13  (FPGA pin N17)          spi_sck
//   D11 (MOSI)  -->  D11  (FPGA pin R17)          spi_mosi
//   D10 (CS)    -->  D10  (FPGA pin T16)          spi_cs_n
//   D8          <--  D12  (FPGA pin P18)          gpu_ready
//   GND         ---  GND                          (must be shared!)
//
// Serial Monitor (115200 baud):
//   1 = test pattern   2 = starburst   3 = cube (300 frames)
//   4 = circles        5 = orbit (120 frames)
//   a = auto loop (default after reset)   s = stop auto loop
// =============================================================

#include <SPI.h>

// ---------------- pick the target ----------------
#define TARGET_FPGA 1          // 1 = PYNQ-Z2 (320x240, RGB332, double buffer)
                               // 0 = SKY130 ASIC (40x30, RGB111, single buffer)

#if TARGET_FPGA
const int16_t SCREEN_W = 320;
const int16_t SCREEN_H = 240;
#else
const int16_t SCREEN_W = 40;
const int16_t SCREEN_H = 30;
#endif

// ---------------- pins (Uno hardware SPI: SCK = D13, MOSI = D11) ----------------
// 3.3 V boards, no dividers needed (SCK/MOSI are the board's default SPI pins):
//   ESP32 DevKit  : SCK GPIO18, MOSI GPIO23  -> PIN_CS = 5,  PIN_READY = 4
//   Pico (arduino-pico core): SCK GP18, MOSI GP19 -> PIN_CS = 17, PIN_READY = 20
const uint8_t  PIN_CS    = 10;
const uint8_t  PIN_READY = 8;
const uint32_t SPI_HZ    = 2000000;     // keep <= GPU clock / 8 (25 MHz / 8 = 3.1 MHz)

// ---------------- protocol (see gpu_core.v) ----------------
const uint8_t OP_CLEAR = 0x01;          // fill the (back) buffer
const uint8_t OP_LINE  = 0x02;          // A=x0 B=y0 C=x1 D=y1
const uint8_t OP_RECT  = 0x03;          // A=x  B=y  C=w  D=h
const uint8_t OP_SWAP  = 0x04;          // flip buffers / wait for vblank
const uint8_t OP_CIRCLE = 0x05;         // A=cx B=cy C=r D=fill (0 outline, 1 filled)

// RGB332 colours (RRRGGGBB). The ASIC keeps only the MSB of each channel.
const uint8_t BLACK   = 0x00;
const uint8_t WHITE   = 0xFF;
const uint8_t RED     = 0xE0;
const uint8_t GREEN   = 0x1C;
const uint8_t BLUE    = 0x03;
const uint8_t YELLOW  = 0xFC;
const uint8_t CYAN    = 0x1F;
const uint8_t MAGENTA = 0xE3;
const uint8_t ORANGE  = 0xF0;
const uint8_t GREY    = 0x92;

const uint8_t PALETTE[8] = { WHITE, YELLOW, CYAN, GREEN, MAGENTA, RED, BLUE, ORANGE };

uint32_t timeouts = 0;                  // READY never came back (should stay 0)
uint32_t commands = 0;                  // commands sent since reset

// =============================================================
// Low level: one 10-byte frame per command
// =============================================================
bool gpuWaitReady(uint16_t limit_ms = 100) {
  uint32_t t0 = millis();
  while (digitalRead(PIN_READY) == LOW) {
    if (millis() - t0 > limit_ms) {     // CLEAR takes ~3 ms, SWAP <= 17 ms
      timeouts++;
      return false;
    }
  }
  return true;
}

void spi16(int16_t v) {
  SPI.transfer((uint8_t)(v >> 8));      // big endian: high byte first
  SPI.transfer((uint8_t)(v & 0xFF));
}

void gpuSend(uint8_t op, int16_t a, int16_t b, int16_t c, int16_t d, uint8_t color) {
  gpuWaitReady();
  SPI.beginTransaction(SPISettings(SPI_HZ, MSBFIRST, SPI_MODE0));
  digitalWrite(PIN_CS, LOW);
  SPI.transfer(op);
  spi16(a);
  spi16(b);
  spi16(c);
  spi16(d);
  SPI.transfer(color);
  digitalWrite(PIN_CS, HIGH);           // the GPU executes the command now
  SPI.endTransaction();
  delayMicroseconds(2);                 // let the GPU see CS high before polling READY
  commands++;
}

// =============================================================
// "GL" style API
// =============================================================
void gpuClear(uint8_t c)                                                { gpuSend(OP_CLEAR, 0, 0, 0, 0, c); }
void gpuLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint8_t c) { gpuSend(OP_LINE, x0, y0, x1, y1, c); }
void gpuRect(int16_t x, int16_t y, int16_t w, int16_t h, uint8_t c)     { gpuSend(OP_RECT, x, y, w, h, c); }
void gpuSwap()                                                          { gpuSend(OP_SWAP, 0, 0, 0, 0, 0); }
void gpuCircle(int16_t cx, int16_t cy, int16_t r, uint8_t c)            { gpuSend(OP_CIRCLE, cx, cy, r, 0, c); }
void gpuFillCircle(int16_t cx, int16_t cy, int16_t r, uint8_t c)        { gpuSend(OP_CIRCLE, cx, cy, r, 1, c); }

// FPGA: draw into the hidden back buffer, then SWAP.
// ASIC: one buffer -> wait for vblank first, then draw quickly.
void beginFrame() {
#if !TARGET_FPGA
  gpuSwap();
#endif
}
void endFrame() {
#if TARGET_FPGA
  gpuSwap();
#endif
}

// =============================================================
// Demos (scripts/gen_demo.py draws exactly the same things)
// =============================================================
void demoTestPattern() {
  beginFrame();
  gpuClear(BLACK);
  int16_t bar_w = SCREEN_W / 8;
  for (int16_t i = 0; i < 8; i++)
    gpuRect(i * bar_w, 0, bar_w, (SCREEN_H * 2) / 3, PALETTE[i]);
  gpuRect(0, (SCREEN_H * 2) / 3, SCREEN_W, SCREEN_H / 3, GREY);
  // border + diagonals
  gpuLine(0, 0, SCREEN_W - 1, 0, WHITE);
  gpuLine(SCREEN_W - 1, 0, SCREEN_W - 1, SCREEN_H - 1, WHITE);
  gpuLine(SCREEN_W - 1, SCREEN_H - 1, 0, SCREEN_H - 1, WHITE);
  gpuLine(0, SCREEN_H - 1, 0, 0, WHITE);
  gpuLine(0, 0, SCREEN_W - 1, SCREEN_H - 1, RED);
  gpuLine(SCREEN_W - 1, 0, 0, SCREEN_H - 1, BLUE);
  gpuCircle(SCREEN_W / 2, SCREEN_H / 2, SCREEN_H / 3, WHITE);
  endFrame();
}

void demoStarburst() {
  beginFrame();
  gpuClear(BLACK);
  int16_t cx = SCREEN_W / 2, cy = SCREEN_H / 2;
  uint8_t k = 0;
  int16_t step = (SCREEN_W >= 160) ? 16 : 4;
  for (int16_t x = 0; x < SCREEN_W; x += step)     gpuLine(cx, cy, x, 0, PALETTE[(k++) & 7]);
  for (int16_t y = 0; y < SCREEN_H; y += step)     gpuLine(cx, cy, SCREEN_W - 1, y, PALETTE[(k++) & 7]);
  for (int16_t x = SCREEN_W - 1; x > 0; x -= step) gpuLine(cx, cy, x, SCREEN_H - 1, PALETTE[(k++) & 7]);
  for (int16_t y = SCREEN_H - 1; y > 0; y -= step) gpuLine(cx, cy, 0, y, PALETTE[(k++) & 7]);
  endFrame();
}

void demoCircles() {
  beginFrame();
  gpuClear(BLACK);
  int16_t r  = (SCREEN_H * 3) / 10;
  int16_t cy = SCREEN_H / 2;
  // left: a target of filled discs, biggest first
  for (int16_t i = 0; i < 5; i++)
    gpuFillCircle(SCREEN_W / 4, cy, r - i * (r / 5), (i & 1) ? WHITE : RED);
  // right: 8 concentric outlines
  for (int16_t i = 0; i < 8; i++)
    gpuCircle((SCREEN_W * 3) / 4, cy, r - i * (r / 8), PALETTE[i]);
  // bottom: a row of bubbles, cut off by the screen edge (clipping)
  for (int16_t i = 0; i < 9; i++)
    gpuFillCircle(i * (SCREEN_W / 8), SCREEN_H - 1, SCREEN_H / 12, PALETTE[i & 7]);
  endFrame();
}

// ---- a planet and its moon going round the sun ----
void drawOrbit(float t) {
  int16_t cx = SCREEN_W / 2, cy = SCREEN_H / 2;
  int16_t R  = (SCREEN_H * 2) / 5;                     // orbit radius
  int16_t m  = SCREEN_H / 10;                          // moon distance
  int16_t px = (int16_t)(cx + R * cos(t));
  int16_t py = (int16_t)(cy + R * sin(t));
  int16_t mx = (int16_t)(px + m * cos(4 * t));
  int16_t my = (int16_t)(py + m * sin(4 * t));
  beginFrame();
  gpuClear(BLACK);
  gpuCircle(cx, cy, R, GREY);                          // orbit path
  gpuFillCircle(cx, cy, SCREEN_H / 8, YELLOW);         // sun
  gpuFillCircle(px, py, SCREEN_H / 16, BLUE);          // planet
  gpuFillCircle(mx, my, SCREEN_H / 40, WHITE);         // moon
  endFrame();
}

void demoOrbit(uint16_t frames) {
  for (uint16_t n = 0; n < frames; n++)
    drawOrbit(n * 0.157f);                             // 40 frames per turn
}

// ---- rotating wireframe cube (the "3D" demo) ----
const int8_t CUBE_V[8][3] = {
  {-1,-1,-1}, { 1,-1,-1}, { 1, 1,-1}, {-1, 1,-1},
  {-1,-1, 1}, { 1,-1, 1}, { 1, 1, 1}, {-1, 1, 1}
};
const uint8_t CUBE_E[12][2] = {
  {0,1},{1,2},{2,3},{3,0},     // back face
  {4,5},{5,6},{6,7},{7,4},     // front face
  {0,4},{1,5},{2,6},{3,7}      // connecting edges
};

void drawCube(float ax, float ay) {
  int16_t px[8], py[8];
  float sx = sin(ax), cx = cos(ax), sy = sin(ay), cy = cos(ay);
  float f = SCREEN_H * 0.6f;                 // focal length in pixels (cube fits on screen)
  for (uint8_t i = 0; i < 8; i++) {
    float x = CUBE_V[i][0], y = CUBE_V[i][1], z = CUBE_V[i][2];
    float y1 = y * cx - z * sx;              // rotate around X
    float z1 = y * sx + z * cx;
    float x2 = x * cy + z1 * sy;             // rotate around Y
    float z2 = -x * sy + z1 * cy;
    float zc = z2 + 4.0f;                    // push away from the camera
    px[i] = (int16_t)(SCREEN_W / 2 + (x2 * f) / zc);   // perspective divide
    py[i] = (int16_t)(SCREEN_H / 2 + (y1 * f) / zc);
  }
  beginFrame();
  gpuClear(BLACK);
  for (uint8_t e = 0; e < 12; e++) {
    uint8_t a = CUBE_E[e][0], b = CUBE_E[e][1];
    uint8_t c = (e < 4) ? BLUE : (e < 8) ? YELLOW : MAGENTA;
    gpuLine(px[a], py[a], px[b], py[b], c);
  }
  endFrame();
}

void demoCube(uint16_t frames) {
  uint32_t t0 = millis();
  for (uint16_t n = 0; n < frames; n++)
    drawCube(n * 0.035f, n * 0.05f);
  Serial.print(F("  cube fps = "));
  Serial.println(frames * 1000.0 / (millis() - t0));
}

// =============================================================
// Start-up wiring check: tells you WHAT is wrong instead of hanging
// =============================================================
void wiringCheck() {
  Serial.println(F("Waiting for READY (GPU clears its framebuffer after reset)..."));
  uint32_t t0 = millis();
  while (digitalRead(PIN_READY) == LOW) {
    if (millis() - t0 > 3000) {
      Serial.println(F("READY is still LOW after 3 s. Check:"));
      Serial.println(F("  - FPGA programmed? LD1 (locked) on, LD0 (READY) on?"));
      Serial.println(F("  - PYNQ header D12 -> Arduino D8 wire"));
      Serial.println(F("  - GND of both boards connected"));
      Serial.println(F("  - BTN0 not pressed"));
      t0 = millis();
    }
  }
  Serial.println(F("READY is HIGH - link OK."));
}

void printStats() {
  Serial.print(F("  commands = "));
  Serial.print(commands);
  Serial.print(F("   READY timeouts = "));
  Serial.println(timeouts);             // must stay 0
}

// =============================================================
// setup / loop
// =============================================================
bool autoLoop = true;

void setup() {
  Serial.begin(115200);
  digitalWrite(PIN_CS, HIGH);           // set the HIGH level first ...
  pinMode(PIN_CS, OUTPUT);              // ... so CS never glitches low (idle high before SPI.begin())
  pinMode(PIN_READY, INPUT);
  SPI.begin();

  Serial.println(F("\n=== SPI rasterizer GPU demo ==="));
  Serial.print(F("target "));
  Serial.print(TARGET_FPGA ? F("FPGA ") : F("ASIC "));
  Serial.print(SCREEN_W);
  Serial.print('x');
  Serial.print(SCREEN_H);
  Serial.print(F(", SPI "));
  Serial.print(SPI_HZ / 1000);
  Serial.println(F(" kHz"));
  wiringCheck();
  Serial.println(F("keys: 1 pattern, 2 starburst, 3 cube, 4 circles, 5 orbit, a auto, s stop"));
}

void loop() {
  if (Serial.available()) {
    char c = Serial.read();
    if (c == '1') { Serial.println(F("test pattern")); demoTestPattern(); printStats(); }
    if (c == '2') { Serial.println(F("starburst"));    demoStarburst();   printStats(); }
    if (c == '3') { Serial.println(F("cube"));         demoCube(300);     printStats(); }
    if (c == '4') { Serial.println(F("circles"));      demoCircles();     printStats(); }
    if (c == '5') { Serial.println(F("orbit"));        demoOrbit(120);    printStats(); }
    if (c == 'a') { autoLoop = true;  Serial.println(F("auto loop on")); }
    if (c == 's') { autoLoop = false; Serial.println(F("auto loop off")); }
  }
  if (!autoLoop) return;

  Serial.println(F("test pattern"));
  demoTestPattern();
  delay(3000);
  Serial.println(F("starburst"));
  demoStarburst();
  delay(3000);
  Serial.println(F("circles"));
  demoCircles();
  delay(3000);
  Serial.println(F("cube"));
  demoCube(600);
  Serial.println(F("orbit"));
  demoOrbit(240);
  printStats();
}
