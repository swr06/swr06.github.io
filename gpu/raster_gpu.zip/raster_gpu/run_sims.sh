#!/usr/bin/env bash
# =============================================================
# run_sims.sh : every simulation + the pin cross-check, one command
#   cd ~/asic_projects/raster_gpu && bash run_sims.sh
# Stops at the first failure (set -e + $fatal in the testbenches).
# =============================================================
set -e
mkdir -p build/demo

RTL="rtl/spi_cmd_rx.v rtl/vga_controller.v rtl/frame_buffer.v
     rtl/line_renderer.v rtl/rect_filler.v rtl/circle_renderer.v rtl/gpu_core.v"
# SRAM build: same RTL, but the SRAM frame_buffer + a stand-in macro model
SRAM_RTL="rtl/spi_cmd_rx.v rtl/vga_controller.v rtl/line_renderer.v rtl/rect_filler.v
     rtl/circle_renderer.v rtl/gpu_core.v asic_sram/src/frame_buffer.v sim/sram_model_sim.v"

show() { grep -E "^\[|PASS|FATAL|mismatch" || true; }

echo "=== 1/8  FPGA config (320x240, RGB332, double buffer)"
iverilog -g2012 -s tb_gpu -o build/tb_fpga $RTL sim/tb_gpu.v
vvp -n build/tb_fpga +frames=build/fpga | show

echo "=== 2/8  ASIC v1 config (40x30, RGB111, single buffer)"
iverilog -g2012 -DASIC_CFG -s tb_gpu -o build/tb_asic $RTL sim/tb_gpu.v
vvp -n build/tb_asic +frames=build/asic | show

echo "=== 3/8  ASIC v2 config (80x60, RGB332, 5 SRAM macros)"
iverilog -g2012 -DSRAM_CFG -s tb_gpu -o build/tb_sram $SRAM_RTL sim/tb_gpu.v
vvp -n build/tb_sram +frames=build/sram | show

echo "=== 4/8  short waveform run -> build/wave.vcd"
iverilog -g2012 -s tb_wave -o build/tb_wave $RTL asic/src/gpu_asic.v sim/tb_wave.v
vvp -n build/tb_wave > /dev/null && echo "wave.vcd written (open with: gtkwave sim/wave.gtkw)"

echo "=== 5/8  chip_top wiring with pad stand-ins"
iverilog -g2012 -DUSE_POWER_PINS -s tb_chip -o build/tb_chip $RTL asic/src/gpu_asic.v \
    chip/rtl/chip_top.v sim/pad_models_sim.v sim/tb_chip.v
vvp -n build/tb_chip | show

echo "=== 6/8  demos on the FPGA config: circles + cube (6 frames)"
python3 scripts/gen_demo.py fpga circles build/demo/fpga_circles.cmd
vvp -n build/tb_fpga +demo=build/demo/fpga_circles.cmd +frames=build/demo/fpga_circles | grep -E "PASS|FATAL"
python3 scripts/gen_demo.py fpga cube build/demo/fpga_cube.cmd 6
vvp -n build/tb_fpga +demo=build/demo/fpga_cube.cmd +frames=build/demo/fpga_cube | grep -E "PASS|FATAL"

echo "=== 7/8  on-board SPI test host: fpga_top + selftest.mem, 6 tests + loopback"
mkdir -p build/selftest
python3 scripts/gen_selftest.py > build/selftest/gen.log
iverilog -g2012 -s tb_selftest -o build/tb_selftest $RTL fpga/spi_test_host.v fpga/fpga_top.v \
    sim/clk_wiz_sim.v sim/tb_selftest.v
vvp -n build/tb_selftest | grep -E "^\[3\]|PASS|FATAL"
for n in 1 2 3 4 5 6; do
    vvp -n build/tb_fpga +demo=build/selftest/test_$n.cmd +frames=build/selftest/ref_$n | grep -q PASS
    cmp -s build/selftest/board_$n.hex build/selftest/ref_${n}_000.hex || { echo "FAIL: test $n frame differs"; exit 1; }
done
cmp -s build/selftest/board_2_loop.hex build/selftest/ref_2_000.hex || { echo "FAIL: loopback frame differs"; exit 1; }
echo "all 6 test frames + loopback frame == golden-model frames"

echo "=== 8/8  circle algorithm check + pin/connection cross-check"
python3 scripts/check_circle.py 200 > build/check_circle.log || { cat build/check_circle.log; exit 1; }
head -n 1 build/check_circle.log
python3 scripts/check_pins.py > build/check_pins.log || { cat build/check_pins.log; exit 1; }
tail -n 1 build/check_pins.log

echo "ALL SIMULATIONS PASSED"
