`timescale 1ns / 1ps

// =============================================================
// gpu_core : SPI rasterizer GPU - BRING-UP STEP 2 (rect only)
//            SPI receiver + framebuffer + VGA scan-out + CLEAR/RECT/SWAP
//
// The first core you build: one drawing engine (rect_filler), so the
// command path, the framebuffer, double buffering and the VGA read side
// can be tested with nothing else in the way. LINE (0x02) and CIRCLE
// (0x05) frames are received, acknowledged and ignored.
// Step 3 = bringup/step3_line/gpu_core.v, step 4 = rtl/gpu_core.v.
//
// Parameters as in the final core (the ASIC builds use only the final
// rtl/gpu_core.v):
//
//   parameter     FPGA (PYNQ-Z2)   ASIC v1 (SKY130)   ASIC v2 (SRAM)
//   FB_W x FB_H   320 x 240        40 x 30            80 x 60
//   SCALE_SHIFT   1  (2 x 2)       4  (16 x 16)       3  (8 x 8)
//   PIX_BITS      8  (RGB332)      3  (RGB111)        8
//   DOUBLE_BUF    1                0                  0
//
// Host protocol: one 10-byte SPI frame per command (mode 0, MSB
// first, CS low for the whole frame). Wait for gpu_ready = 1
// before every frame.
//
//   byte 0      opcode
//   byte 1..2   A  (int16, big endian)
//   byte 3..4   B
//   byte 5..6   C
//   byte 7..8   D
//   byte 9      colour, RGB332 (RRRGGGBB)
//
//   0x01 CLEAR   -                       fill the whole back buffer
//   0x02 LINE    (step 3)                accepted and ignored here
//   0x03 RECT    A=x  B=y  C=w  D=h      filled
//   0x04 SWAP    -                       show the back buffer at the
//                                        next vblank (single buffer:
//                                        just wait for vblank)
//   0x05 CIRCLE  (step 4)                accepted and ignored here
//
// Coordinates use the low COORD_BITS bits as a signed number
// (-2048 .. 2047), w/h the low COORD_BITS bits unsigned.
// A rectangle that is partly off screen is clipped.
// =============================================================

module gpu_core #(
    parameter FB_W        = 320,
    parameter FB_H        = 240,
    parameter SCALE_SHIFT = 1,
    parameter PIX_BITS    = 8,
    parameter DOUBLE_BUF  = 1,
    parameter COORD_BITS  = 12
)(
    input  wire clk,                    // 25 MHz pixel + system clock
    input  wire rst_n,                  // asynchronous, active low

    input  wire spi_cs_n,               // SPI from the host MCU
    input  wire spi_sck,
    input  wire spi_mosi,
    output wire gpu_ready,

    output wire vga_hs,
    output wire vga_vs,
    output wire [PIX_BITS-1:0] vga_pix,

    output reg  dbg_cmd_toggle          // LED on the FPGA, unused on the ASIC
);

    // ---------------------------------------------------------
    // Sizes
    // ---------------------------------------------------------
    localparam FB_PIXELS = FB_W * FB_H;
    localparam DEPTH     = DOUBLE_BUF ? 2 * FB_PIXELS : FB_PIXELS;
    localparam ADDR_BITS = $clog2(DEPTH);
    localparam XW        = $clog2(FB_W);          // bits of an on-screen x
    localparam YW        = $clog2(FB_H);
    localparam CB        = COORD_BITS;

    localparam [7:0] OP_CLEAR  = 8'h01;
    localparam [7:0] OP_RECT   = 8'h03;
    localparam [7:0] OP_SWAP   = 8'h04;


    // ---------------------------------------------------------
    // Reset synchronizer: assert at once, release on a clock edge
    // ---------------------------------------------------------
    (* ASYNC_REG = "TRUE" *) reg [1:0] reset_s;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            reset_s <= 2'b11;
        else
            reset_s <= {reset_s[0], 1'b0};
    end

    wire reset = reset_s[1];


    // ---------------------------------------------------------
    // Power-up clear: write 0 to every word once after reset
    // (silicon has no initial values)
    // ---------------------------------------------------------
    localparam LAST_I = DEPTH - 1;
    localparam [ADDR_BITS-1:0] LAST_ADDR = LAST_I[ADDR_BITS-1:0];

    reg                 init_done;
    reg [ADDR_BITS-1:0] init_addr;

    always @(posedge clk) begin
        if (reset) begin
            init_done <= 1'b0;
            init_addr <= 0;
        end
        else if (!init_done) begin
            if (init_addr == LAST_ADDR)
                init_done <= 1'b1;
            else
                init_addr <= init_addr + 1'b1;
        end
    end


    // ---------------------------------------------------------
    // SPI receiver
    // ---------------------------------------------------------
    wire        bus_idle;
    wire        cmd_valid;
    wire [79:0] cmd_word;

    spi_cmd_rx #(.CMD_BITS(80)) u_spi (
        .clk(clk), .reset(reset),
        .spi_cs_n(spi_cs_n), .spi_sck(spi_sck), .spi_mosi(spi_mosi),
        .bus_idle(bus_idle), .cmd_valid(cmd_valid), .cmd_word(cmd_word)
    );


    // ---------------------------------------------------------
    // Command fields
    // ---------------------------------------------------------
    // The protocol carries int16 values; only the low bits are used.
    /* verilator lint_off UNUSEDSIGNAL */
    wire [7:0]  op     = cmd_word[79:72];
    wire [15:0] arg_a  = cmd_word[71:56];
    wire [15:0] arg_b  = cmd_word[55:40];
    wire [15:0] arg_c  = cmd_word[39:24];
    wire [15:0] arg_d  = cmd_word[23:8];
    wire [7:0]  rgb332 = cmd_word[7:0];
    /* verilator lint_on UNUSEDSIGNAL */

    wire signed [CB-1:0] a = arg_a[CB-1:0];
    wire signed [CB-1:0] b = arg_b[CB-1:0];

    // RGB332 -> framebuffer pixel (ASIC: keep the MSB of R, G and B)
    wire [PIX_BITS-1:0] cmd_color;
    generate
        if (PIX_BITS == 3) begin : g_rgb111
            assign cmd_color = {rgb332[7], rgb332[4], rgb332[1]};
        end
        else begin : g_rgb332
            assign cmd_color = rgb332[PIX_BITS-1:0];
        end
    endgenerate


    // ---------------------------------------------------------
    // Accepting a command
    // ---------------------------------------------------------
    wire rect_busy;
    reg  swap_pending;

    wire idle   = init_done && !rect_busy && !swap_pending;
    wire accept = cmd_valid && idle;      // a command sent while busy is dropped

    assign gpu_ready = idle && !cmd_valid && bus_idle;

    wire is_clear  = (op == OP_CLEAR);
    wire is_rect   = (op == OP_RECT);
    wire is_swap   = (op == OP_SWAP);

    // colour for the whole command, latched once
    reg [PIX_BITS-1:0] draw_color;

    always @(posedge clk) begin
        if (reset)
            dbg_cmd_toggle <= 1'b0;
        else if (accept) begin
            dbg_cmd_toggle <= !dbg_cmd_toggle;
            draw_color     <= cmd_color;
        end
    end


    // ---------------------------------------------------------
    // RECT / CLEAR: clip [x, x+w) x [y, y+h) to the screen.
    // The filler then only walks visible pixels.
    // ---------------------------------------------------------
    localparam BW = CB + 2;                         // holds x + w

    localparam X_LAST = FB_W - 1;
    localparam Y_LAST = FB_H - 1;
    localparam signed [BW-1:0] B_ONE  = 1;
    localparam signed [BW-1:0] B_ZERO = 0;
    localparam signed [BW-1:0] B_XMAX = X_LAST[BW-1:0];
    localparam signed [BW-1:0] B_YMAX = Y_LAST[BW-1:0];

    wire signed [BW-1:0] rx0 = {{2{a[CB-1]}}, a};   // sign-extended
    wire signed [BW-1:0] ry0 = {{2{b[CB-1]}}, b};
    wire signed [BW-1:0] rx1 = rx0 + $signed({2'b00, arg_c[CB-1:0]}) - B_ONE;   // inclusive
    wire signed [BW-1:0] ry1 = ry0 + $signed({2'b00, arg_d[CB-1:0]}) - B_ONE;

    wire signed [BW-1:0] kx0 = (rx0 < B_ZERO) ? B_ZERO : rx0;
    wire signed [BW-1:0] ky0 = (ry0 < B_ZERO) ? B_ZERO : ry0;
    wire signed [BW-1:0] kx1 = (rx1 > B_XMAX) ? B_XMAX : rx1;
    wire signed [BW-1:0] ky1 = (ry1 > B_YMAX) ? B_YMAX : ry1;

    // w = 0 or h = 0 or completely off screen -> nothing to draw
    wire rect_visible = (kx0 <= kx1) && (ky0 <= ky1);

    /* verilator lint_off UNUSEDSIGNAL */
    wire [XW-1:0] fill_x0 = is_clear ? {XW{1'b0}} : kx0[XW-1:0];
    wire [YW-1:0] fill_y0 = is_clear ? {YW{1'b0}} : ky0[YW-1:0];
    wire [XW-1:0] fill_x1 = is_clear ? B_XMAX[XW-1:0] : kx1[XW-1:0];
    wire [YW-1:0] fill_y1 = is_clear ? B_YMAX[YW-1:0] : ky1[YW-1:0];
    /* verilator lint_on UNUSEDSIGNAL */


    // ---------------------------------------------------------
    // Draw engine. It only says "plot (x, y)", one pixel per clock.
    // ---------------------------------------------------------
    wire                 rect_plot;
    wire [XW-1:0]        rect_x;
    wire [YW-1:0]        rect_y;

    rect_filler #(.XW(XW), .YW(YW)) u_rect (
        .clk(clk), .reset(reset),
        .start(accept && (is_clear || (is_rect && rect_visible))),
        .x0(fill_x0), .y0(fill_y0), .x1(fill_x1), .y1(fill_y1),
        .busy(rect_busy), .plot(rect_plot), .x(rect_x), .y(rect_y)
    );


    // ---------------------------------------------------------
    // Pixel writer: address = y * FB_W + x. The rect filler only
    // walks pixels that were clipped to the screen already, so every
    // plot can be written as it is (step 3 adds clipping here).
    // ---------------------------------------------------------
    wire draw_we = rect_plot;

    localparam [ADDR_BITS-1:0] STRIDE = FB_W[ADDR_BITS-1:0];
    wire [ADDR_BITS-1:0] draw_x = {{(ADDR_BITS-XW){1'b0}}, rect_x};
    wire [ADDR_BITS-1:0] draw_y = {{(ADDR_BITS-YW){1'b0}}, rect_y};


    // ---------------------------------------------------------
    // SWAP and double buffering
    //   front_buf = the buffer on screen; we always draw the other one
    // ---------------------------------------------------------
    reg  front_buf;
    wire vblank_start;

    always @(posedge clk) begin
        if (reset) begin
            front_buf    <= 1'b0;
            swap_pending <= 1'b0;
        end
        else if (accept && is_swap)
            swap_pending <= 1'b1;
        else if (swap_pending && vblank_start) begin
            swap_pending <= 1'b0;
            if (DOUBLE_BUF)
                front_buf <= !front_buf;
        end
    end

    localparam BUF1_I = DOUBLE_BUF ? FB_PIXELS : 0;
    localparam [ADDR_BITS-1:0] BUF1 = BUF1_I[ADDR_BITS-1:0];
    wire [ADDR_BITS-1:0] front_base = front_buf ? BUF1 : {ADDR_BITS{1'b0}};
    wire [ADDR_BITS-1:0] back_base  = front_buf ? {ADDR_BITS{1'b0}} : BUF1;


    // ---------------------------------------------------------
    // Framebuffer: the init sweep has the write port until done
    // ---------------------------------------------------------
    wire                 fb_we    = (!init_done && !reset) || draw_we;
    wire [ADDR_BITS-1:0] fb_waddr = init_done ? back_base + draw_y * STRIDE + draw_x : init_addr;
    wire [PIX_BITS-1:0]  fb_wdata = init_done ? draw_color : {PIX_BITS{1'b0}};

    wire [ADDR_BITS-1:0] scan_addr;
    wire [PIX_BITS-1:0]  scan_data;

    frame_buffer #(.PIX_BITS(PIX_BITS), .DEPTH(DEPTH), .ADDR_BITS(ADDR_BITS)) u_fb (
        .clk(clk),
        .write_en(fb_we), .addr_write(fb_waddr), .write_data(fb_wdata),
        .addr_read(front_base + scan_addr), .read_data(scan_data)
    );


    // ---------------------------------------------------------
    // VGA scan-out
    // ---------------------------------------------------------
    vga_controller #(
        .FB_WIDTH(FB_W), .SCALE_SHIFT(SCALE_SHIFT),
        .PIX_BITS(PIX_BITS), .ADDR_BITS(ADDR_BITS)
    ) u_vga (
        .clk(clk), .reset(reset), .frame_valid(init_done),
        .fb_addr(scan_addr), .fb_data(scan_data),
        .vblank_start(vblank_start),
        .hsync(vga_hs), .vsync(vga_vs), .pixel(vga_pix)
    );

endmodule
