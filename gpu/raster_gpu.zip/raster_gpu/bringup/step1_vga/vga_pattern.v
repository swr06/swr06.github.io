`timescale 1ns / 1ps

// =============================================================
// vga_pattern : test pictures for bring-up step 1 (vga_controller + adapter only)
//
// Sits where the framebuffer normally is: vga_controller asks for
// "address" fb_addr and gets a colour one clock later. With
// FB_WIDTH = 1024 and SCALE_SHIFT = 0 the address is simply
//     fb_addr = y * 1024 + x   ->   x = fb_addr[9:0], y = fb_addr[18:10]
// so every one of the 640 x 480 screen pixels can be addressed.
//
//   sel 0  checkerboard, 40 x 40 squares, 1-pixel red frame on the
//          outermost pixels (x = 0, 639 / y = 0, 479)
//   sel 1  8 colour bars + a 16-step grey ramp underneath
//   sel 2  DAC ramps: red, green, blue, grey, 16 steps of 40 pixels
//          (step n = value n on the 4-bit DAC: every bit is visible)
//   sel 3  1-pixel white grid every 40 pixels + centre cross
//   invert inverts every colour (each pixel and each DAC bit both ways)
//
// Colour out is RGB444 = {R[3:0], G[3:0], B[3:0]}, straight to the adapter.
// =============================================================

module vga_pattern (
    input  wire        clk,
    input  wire [1:0]  sel,
    input  wire        invert,            // SW0: every colour inverted
    input  wire [18:0] fb_addr,
    output reg  [11:0] rgb
);

    wire [9:0] x = fb_addr[9:0];          // 0 .. 639
    wire [8:0] y = fb_addr[18:10];        // 0 .. 479

    // 40-pixel cells: column cx 0..15, row cy 0..11, position inside 0..39.
    // v / 40 without a divider: (v * 205) >> 13 is exact for every v < 1024.
    /* verilator lint_off UNUSEDSIGNAL */    // only bits 16:13 are the quotient
    wire [17:0] xm = {8'd0, x} * 18'd205;
    wire [17:0] ym = {9'd0, y} * 18'd205;
    /* verilator lint_on UNUSEDSIGNAL */
    wire [3:0]  cx = xm[16:13];
    wire [3:0]  cy = ym[16:13];
    wire [9:0]  ix = x - ({1'b0, cx, 5'd0} + {3'd0, cx, 3'd0});     // x - 40*cx
    wire [8:0]  iy = y - ({cy, 5'd0} + {2'd0, cy, 3'd0});           // y - 40*cy

    wire border = (x == 10'd0) || (x == 10'd639) || (y == 9'd0) || (y == 9'd479);

    // 8 colour bars, 80 pixels (2 cells) wide:
    // white yellow cyan green magenta red blue black
    reg [11:0] bar;
    always @(*) begin
        case (cx[3:1])
            3'd0:    bar = 12'hFFF;
            3'd1:    bar = 12'hFF0;
            3'd2:    bar = 12'h0FF;
            3'd3:    bar = 12'h0F0;
            3'd4:    bar = 12'hF0F;
            3'd5:    bar = 12'hF00;
            3'd6:    bar = 12'h00F;
            default: bar = 12'h000;
        endcase
    end

    reg [11:0] c;
    always @(*) begin
        case (sel)
            2'd0:    c = border ? 12'hF00 : ((cx[0] ^ cy[0]) ? 12'h000 : 12'hFFF);
            2'd1:    c = (y < 9'd320) ? bar : {3{cx}};
            2'd2:    if      (y < 9'd120) c = {cx, 4'h0, 4'h0};    // red ramp
                     else if (y < 9'd240) c = {4'h0, cx, 4'h0};    // green ramp
                     else if (y < 9'd360) c = {4'h0, 4'h0, cx};    // blue ramp
                     else                 c = {cx, cx, cx};        // grey ramp
            default: c = (ix == 10'd0 || iy == 9'd0 || x == 10'd639 || y == 9'd479 ||
                          x == 10'd320 || y == 9'd240) ? 12'hFFF : 12'h000;
        endcase
    end

    // registered, like a framebuffer read: colour arrives one clock later
    always @(posedge clk)
        rgb <= invert ? ~c : c;

endmodule
