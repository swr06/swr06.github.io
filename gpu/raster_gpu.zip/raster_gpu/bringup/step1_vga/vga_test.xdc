## =============================================================================
## vga_test.xdc  -  PYNQ-Z2 constraints for vga_test_top (bring-up step 1: VGA controller + adapter test)
##
##  Exactly the same pins as pynq_gpu.xdc (check_pins.py verifies that), only the
##  ports this small design has: clock, BTN0..3, SW0..1, LEDs, PMOD A + B (video).
##  PMOD pins: JA-2 = PMOD A physical pin 2 (manual name JA1_N), etc.
## =============================================================================
set_property -dict { PACKAGE_PIN H16 IOSTANDARD LVCMOS33 } [get_ports sysclk]
create_clock -add -name sys_clk_pin -period 8.00 -waveform {0 4} [get_ports sysclk]
set_property -dict { PACKAGE_PIN D19 IOSTANDARD LVCMOS33 } [get_ports reset]        ;# BTN0
set_property -dict { PACKAGE_PIN D20 IOSTANDARD LVCMOS33 } [get_ports {btn[0]}]     ;# BTN1
set_property -dict { PACKAGE_PIN L20 IOSTANDARD LVCMOS33 } [get_ports {btn[1]}]     ;# BTN2
set_property -dict { PACKAGE_PIN L19 IOSTANDARD LVCMOS33 } [get_ports {btn[2]}]     ;# BTN3
set_property -dict { PACKAGE_PIN M20 IOSTANDARD LVCMOS33 } [get_ports {sw[0]}]      ;# SW0
set_property -dict { PACKAGE_PIN M19 IOSTANDARD LVCMOS33 } [get_ports {sw[1]}]      ;# SW1
set_property -dict { PACKAGE_PIN R14 IOSTANDARD LVCMOS33 } [get_ports {led[0]}]     ;# LD0
set_property -dict { PACKAGE_PIN P14 IOSTANDARD LVCMOS33 } [get_ports {led[1]}]     ;# LD1
set_property -dict { PACKAGE_PIN N16 IOSTANDARD LVCMOS33 } [get_ports {led[2]}]     ;# LD2
set_property -dict { PACKAGE_PIN M14 IOSTANDARD LVCMOS33 } [get_ports {led[3]}]     ;# LD3
set_property -dict { PACKAGE_PIN Y19 IOSTANDARD LVCMOS33 } [get_ports vga_hs]      ;# JA-2 (JA1_N)
set_property -dict { PACKAGE_PIN U19 IOSTANDARD LVCMOS33 } [get_ports vga_vs]      ;# JA-8 (JA3_N)
set_property -dict { PACKAGE_PIN Y17 IOSTANDARD LVCMOS33 } [get_ports {vga_b[0]}]  ;# JA-4 (JA2_N)
set_property -dict { PACKAGE_PIN W19 IOSTANDARD LVCMOS33 } [get_ports {vga_b[1]}]  ;# JA-10 (JA4_N)
set_property -dict { PACKAGE_PIN Y16 IOSTANDARD LVCMOS33 } [get_ports {vga_b[2]}]  ;# JA-3 (JA2_P)
set_property -dict { PACKAGE_PIN W18 IOSTANDARD LVCMOS33 } [get_ports {vga_b[3]}]  ;# JA-9 (JA4_P)
set_property -dict { PACKAGE_PIN T10 IOSTANDARD LVCMOS33 } [get_ports {vga_r[0]}]  ;# JB-4 (JB2_N)
set_property -dict { PACKAGE_PIN W13 IOSTANDARD LVCMOS33 } [get_ports {vga_r[1]}]  ;# JB-10 (JB4_N)
set_property -dict { PACKAGE_PIN T11 IOSTANDARD LVCMOS33 } [get_ports {vga_r[2]}]  ;# JB-3 (JB2_P)
set_property -dict { PACKAGE_PIN V12 IOSTANDARD LVCMOS33 } [get_ports {vga_r[3]}]  ;# JB-9 (JB4_P)
set_property -dict { PACKAGE_PIN Y14 IOSTANDARD LVCMOS33 } [get_ports {vga_g[0]}]  ;# JB-2 (JB1_N)
set_property -dict { PACKAGE_PIN W16 IOSTANDARD LVCMOS33 } [get_ports {vga_g[1]}]  ;# JB-8 (JB3_N)
set_property -dict { PACKAGE_PIN W14 IOSTANDARD LVCMOS33 } [get_ports {vga_g[2]}]  ;# JB-1 (JB1_P)
set_property -dict { PACKAGE_PIN V16 IOSTANDARD LVCMOS33 } [get_ports {vga_g[3]}]  ;# JB-7 (JB3_P)

## buttons/switches are asynchronous: they only enter 2-flop synchronizers
set_false_path -from [get_ports {reset btn[*] sw[*]}]
set_false_path -to [get_ports {vga_* led[*]}]
