`timescale 1ns / 1ps

// =============================================================
// vga_test_top : BRING-UP STEP 1 - test vga_controller.v and your video adapter
//
// No SPI, no framebuffer, no GPU: the real vga_controller.v scans the
// screen and vga_pattern.v answers every pixel with a test colour.
// The checkerboard appears as soon as the bitstream is loaded.
//
//   BTN1 checkerboard (default)   BTN2 colour bars + grey ramp
//   BTN3 DAC ramps (each colour, 16 levels)
//   SW1 up: 1-pixel grid + centre cross (overrides the buttons)
//   SW0 up: all colours inverted (every pixel and DAC bit seen both ways)
//   BTN0 reset   LD1 clock locked   LD3 heartbeat   LD0/LD2 pattern number
//
// Same pins as fpga_top (pynq_gpu.xdc), constraints in vga_test.xdc.
// =============================================================

module vga_test_top (
    input  wire       sysclk,           // 125 MHz
    input  wire       reset,            // BTN0
    input  wire [2:0] btn,              // BTN1 .. BTN3
    input  wire [1:0] sw,               // SW0 = invert colours, SW1 = grid
    output wire       vga_hs,
    output wire       vga_vs,
    output wire [3:0] vga_r,
    output wire [3:0] vga_g,
    output wire [3:0] vga_b,
    output wire [3:0] led
);

    wire clk_25m, clk_locked;

    clk_wiz_0 u_clk (
        .clk_in1(sysclk), .reset(1'b0),
        .clk_out1(clk_25m), .locked(clk_locked)
    );

    // reset: asynchronous assert, synchronous release
    wire rst_n = clk_locked & ~reset;
    (* ASYNC_REG = "TRUE" *) reg [1:0] rst_s;
    always @(posedge clk_25m or negedge rst_n)
        if (!rst_n) rst_s <= 2'b11;
        else        rst_s <= {rst_s[0], 1'b0};
    wire top_reset = rst_s[1];

    // buttons/switches: 2-flop synchronizer (no debounce needed:
    // pressing "checkerboard" twice still shows the checkerboard)
    (* ASYNC_REG = "TRUE" *) reg [4:0] in_m, in_s;
    always @(posedge clk_25m) begin
        in_m <= {sw, btn};
        in_s <= in_m;
    end

    reg [1:0] pattern;
    always @(posedge clk_25m) begin
        if (top_reset)       pattern <= 2'd0;           // checkerboard after reset
        else if (in_s[0])    pattern <= 2'd0;
        else if (in_s[1])    pattern <= 2'd1;
        else if (in_s[2])    pattern <= 2'd2;
    end
    wire [1:0] sel = in_s[4] ? 2'd3 : pattern;          // SW1: grid

    // the real VGA controller; the "framebuffer" is the pattern generator
    wire [18:0] addr;
    wire [11:0] rgb, pix;

    /* verilator lint_off PINCONNECTEMPTY */
    vga_controller #(
        .FB_WIDTH(1024), .SCALE_SHIFT(0), .PIX_BITS(12), .ADDR_BITS(19)
    ) u_vga (
        .clk(clk_25m), .reset(top_reset), .frame_valid(1'b1),
        .fb_addr(addr), .fb_data(rgb),
        .vblank_start(),                          // not needed here
        .hsync(vga_hs), .vsync(vga_vs), .pixel(pix)
    );
    /* verilator lint_on PINCONNECTEMPTY */

    vga_pattern u_pat (.clk(clk_25m), .sel(sel), .invert(in_s[3]), .fb_addr(addr), .rgb(rgb));

    assign vga_r = pix[11:8];
    assign vga_g = pix[7:4];
    assign vga_b = pix[3:0];

    reg [24:0] heartbeat = 25'd0;
    always @(posedge clk_25m) heartbeat <= heartbeat + 1'b1;

    assign led = {heartbeat[24], sel[1], clk_locked, sel[0]};

endmodule
