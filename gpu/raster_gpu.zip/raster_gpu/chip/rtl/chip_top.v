`default_nettype none

// =============================================================
// chip_top : SKY130 padframe around the hardened gpu_asic macro
//
// Same structure as counter8_fullchip/rtl/chip_top.v:
//   - 11 signal GPIOs   (5 in, 6 out)  -> tie_lo[10:0]
//   - 1 power-good GPIO  (drives ENABLE_H / ENABLE_VDDIO of the others)
//   - 6 clamped supply pads (VCCD VSSD VDDIO VSSIO VDDA VSSA)
//   - 1 conb tie cell for the 1.8 V pad controls
//   - the hardened GPU macro  u_core
//
// Verilog only describes CONNECTIVITY. Where every cell sits on the
// die is decided later in tcl/01_floorplan.tcl.
// =============================================================

// Shared power/analog connections for SKY130 I/O cells
`define IO_BUSES \
    .VCCD(VCCD), \
    .VSSD(VSSD), \
    .VDDIO(VDDIO), \
    .VSSIO(VSSIO), \
    .VDDA(VDDA), \
    .VSSA(VSSA), \
    .VCCHIB(VCCD), \
    .VSWITCH(VDDIO), \
    .VDDIO_Q(VDDIO), \
    .VSSIO_Q(VSSIO), \
    .AMUXBUS_A(amux_a), \
    .AMUXBUS_B(amux_b)

// Controls common to ordinary signal GPIOs
`define GPIO_COMMON(I) \
    `IO_BUSES, \
    .ENABLE_H(por_h), \
    .ENABLE_VDDIO(por_lv), \
    .ENABLE_VDDA_H(tie_lo[I]), \
    .ENABLE_VSWITCH_H(tie_lo[I]), \
    .ENABLE_INP_H(tie_lo[I]), \
    .TIE_LO_ESD(tie_lo[I]), \
    .TIE_HI_ESD(), \
    .HLD_H_N(cfg_hi), \
    .HLD_OVR(cfg_lo), \
    .SLOW(cfg_lo), \
    .VTRIP_SEL(cfg_lo), \
    .IB_MODE_SEL(cfg_lo), \
    .ANALOG_EN(cfg_lo), \
    .ANALOG_SEL(cfg_lo), \
    .ANALOG_POL(cfg_lo), \
    .IN_H(), \
    .PAD_A_ESD_0_H(), \
    .PAD_A_ESD_1_H(), \
    .PAD_A_NOESD_H()

// DM = 001 : input only (output driver off)
`define INPUT_PAD(INST, PADWIRE, SIGNAL, I) \
    sky130_ef_io__gpiov2_pad_wrapped INST ( \
        .PAD(PADWIRE), \
        .IN(SIGNAL), \
        .OUT(cfg_lo), \
        .DM({cfg_lo, cfg_lo, cfg_hi}), \
        .OE_N(cfg_hi), \
        .INP_DIS(cfg_lo), \
        `GPIO_COMMON(I) \
    );

// DM = 110 : strong push-pull output, input buffer disabled
`define OUTPUT_PAD(INST, PADWIRE, SIGNAL, I) \
    sky130_ef_io__gpiov2_pad_wrapped INST ( \
        .PAD(PADWIRE), \
        .IN(), \
        .OUT(SIGNAL), \
        .DM({cfg_hi, cfg_hi, cfg_lo}), \
        .OE_N(cfg_lo), \
        .INP_DIS(cfg_hi), \
        `GPIO_COMMON(I) \
    );

module chip_top (
    // clock / reset / power good
    inout wire pad_clk,
    inout wire pad_rst_n,
    inout wire pad_power_good,

    // SPI from the host MCU
    inout wire pad_cs_n,
    inout wire pad_sck,
    inout wire pad_mosi,
    inout wire pad_ready,

    // VGA
    inout wire pad_hs,
    inout wire pad_vs,
    inout wire [2:0] pad_rgb,      // {R, G, B}

    // supplies
    inout wire pad_vccd,
    inout wire pad_vssd,
    inout wire pad_vddio,
    inout wire pad_vssio,
    inout wire pad_vdda,
    inout wire pad_vssa
);

    // Supply nets

    wire VCCD;
    wire VSSD;
    wire VDDIO;
    wire VSSIO;
    wire VDDA;
    wire VSSA;

    // Unused analog buses

    wire amux_a;
    wire amux_b;

    // Core signals (core side of the pads)

    wire clk;
    wire rst_n;
    wire cs_n;
    wire sck;
    wire mosi;
    wire ready;
    wire hs;
    wire vs;
    wire [2:0] rgb;

    // Low-voltage constants and GPIO startup signals

    wire cfg_hi;
    wire cfg_lo;

    wire por_h;
    wire por_lv;

    wire por_tie_hi;
    wire por_tie_lo;

    wire [10:0] tie_lo;

    // =============================================
    // Constant driver for 1.8 V GPIO controls
    // =============================================

    sky130_fd_sc_hd__conb_1 u_cfg_tie (
        .HI(cfg_hi),
        .LO(cfg_lo),
        .VPWR(VCCD),
        .VGND(VSSD),
        .VPB(VCCD),
        .VNB(VSSD)
    );

    // =============================================
    // Hardened GPU macro
    // =============================================

    gpu_asic u_core (
        .clk(clk),
        .rst_n(rst_n),
        .spi_cs_n(cs_n),
        .spi_sck(sck),
        .spi_mosi(mosi),
        .gpu_ready(ready),
        .vga_hs(hs),
        .vga_vs(vs),
        .vga_rgb(rgb),
        .VPWR(VCCD),
        .VGND(VSSD)
    );

    // =============================================
    // Power-good input GPIO
    // =============================================

    // External power_good must stay low until
    // the external supplies are stable.
    //
    // ENABLE_INP_H uses this GPIO's own ESD tie.
    // IN_H and IN provide separate voltage-domain
    // versions of the power-good signal.

    sky130_ef_io__gpiov2_pad_wrapped u_power_good (
        .PAD(pad_power_good),

        .IN(por_lv),
        .IN_H(por_h),
        .OUT(cfg_lo),

        .DM({cfg_lo, cfg_lo, cfg_hi}),
        .OE_N(cfg_hi),
        .INP_DIS(cfg_lo),

        .ENABLE_H(por_tie_lo),
        .ENABLE_INP_H(por_tie_hi),
        .ENABLE_VDDIO(cfg_hi),
        .ENABLE_VDDA_H(por_tie_lo),
        .ENABLE_VSWITCH_H(por_tie_lo),

        .TIE_HI_ESD(por_tie_hi),
        .TIE_LO_ESD(por_tie_lo),

        .HLD_H_N(cfg_hi),
        .HLD_OVR(cfg_lo),
        .SLOW(cfg_lo),
        .VTRIP_SEL(cfg_lo),
        .IB_MODE_SEL(cfg_lo),

        .ANALOG_EN(cfg_lo),
        .ANALOG_SEL(cfg_lo),
        .ANALOG_POL(cfg_lo),

        .PAD_A_ESD_0_H(),
        .PAD_A_ESD_1_H(),
        .PAD_A_NOESD_H(),

        `IO_BUSES
    );

    // =============================================
    // Five input GPIOs
    // =============================================

    `INPUT_PAD(u_clk,   pad_clk,   clk,   0)
    `INPUT_PAD(u_rst_n, pad_rst_n, rst_n, 1)
    `INPUT_PAD(u_cs_n,  pad_cs_n,  cs_n,  2)
    `INPUT_PAD(u_sck,   pad_sck,   sck,   3)
    `INPUT_PAD(u_mosi,  pad_mosi,  mosi,  4)

    // =============================================
    // Six output GPIOs
    // =============================================

    `OUTPUT_PAD(u_ready, pad_ready,  ready,  5)
    `OUTPUT_PAD(u_hs,    pad_hs,     hs,     6)
    `OUTPUT_PAD(u_vs,    pad_vs,     vs,     7)
    `OUTPUT_PAD(u_r,     pad_rgb[2], rgb[2], 8)
    `OUTPUT_PAD(u_g,     pad_rgb[1], rgb[1], 9)
    `OUTPUT_PAD(u_b,     pad_rgb[0], rgb[0], 10)

    // =============================================
    // Six supply pads
    // =============================================

    sky130_ef_io__vccd_lvc_clamped_pad u_vccd (
        .VCCD_PAD(pad_vccd),
        `IO_BUSES
    );

    sky130_ef_io__vssd_lvc_clamped_pad u_vssd (
        .VSSD_PAD(pad_vssd),
        `IO_BUSES
    );

    sky130_ef_io__vddio_hvc_clamped_pad u_vddio (
        .VDDIO_PAD(pad_vddio),
        `IO_BUSES
    );

    sky130_ef_io__vssio_hvc_clamped_pad u_vssio (
        .VSSIO_PAD(pad_vssio),
        `IO_BUSES
    );

    sky130_ef_io__vdda_hvc_clamped_pad u_vdda (
        .VDDA_PAD(pad_vdda),
        `IO_BUSES
    );

    sky130_ef_io__vssa_hvc_clamped_pad u_vssa (
        .VSSA_PAD(pad_vssa),
        `IO_BUSES
    );

endmodule

`undef OUTPUT_PAD
`undef INPUT_PAD
`undef GPIO_COMMON
`undef IO_BUSES

`default_nettype wire
