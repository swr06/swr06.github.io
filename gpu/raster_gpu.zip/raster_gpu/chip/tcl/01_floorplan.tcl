# =========================================================
# 01_floorplan.tcl : die, macro, taps, padframe
# Run from the chip/ folder:
#     openroad -gui tcl/01_floorplan.tcl
# =========================================================

# =========================================
# SKY130 libraries
# =========================================

set PDK $::env(SKY130_PDK)

set HD "$PDK/libs.ref/sky130_fd_sc_hd"
set IO "$PDK/libs.ref/sky130_fd_io"

file mkdir results
file mkdir reports

read_lef "$HD/techlef/sky130_fd_sc_hd__nom.tlef"
read_lef "$HD/lef/sky130_fd_sc_hd.lef"

read_lef "$IO/lef/sky130_fd_io.lef"
read_lef "$IO/lef/sky130_ef_io.lef"

read_lef "macros/gpu_asic.lef"

read_liberty \
    "$HD/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"

# =========================================
# Load the chip Verilog (macros already expanded)
# =========================================

read_verilog "results/chip_top_expanded.v"

link_design chip_top

# =========================================
# Floorplan
# =========================================
# Die 1600 x 1600 um. Pads + corners use the outer ~210 um,
# the core ring sits between the pads and the core area.

initialize_floorplan \
    -die_area {0 0 1600 1600} \
    -core_area {350 350 1250 1250} \
    -site unithd

make_tracks

# =========================================
# Place the hardened GPU (720 x 720 um)
# =========================================
# origin = lower-left corner. 440 + 720 = 1160 -> centred in the core.

place_inst \
    -name u_core \
    -origin {440 440} \
    -orientation R0 \
    -status FIRM

# =========================================
# Well taps + end caps
# =========================================
# -halo_* also CUTS the standard-cell rows 10 um around the macro.
# (In counter8_fullchip the rows ran under the macro, which caused
#  all the "Obstructed met1 -> met4" failed vias in 02_failed_vias.rpt)

tapcell \
    -distance 13 \
    -tapcell_master sky130_fd_sc_hd__tapvpwrvgnd_1 \
    -endcap_master sky130_fd_sc_hd__decap_3 \
    -halo_width_x 10 \
    -halo_width_y 10

# =========================================
# I/O placement sites
# =========================================

make_fake_io_site \
    -name IO_SITE \
    -width 1 \
    -height 200

make_fake_io_site \
    -name IO_CORNER_SITE \
    -width 200 \
    -height 204

make_io_sites \
    -horizontal_site IO_SITE \
    -vertical_site IO_SITE \
    -corner_site IO_CORNER_SITE \
    -offset 0 \
    -rotation_horizontal R180 \
    -rotation_vertical R180 \
    -rotation_corner R180

# =========================================
# Corner cells
# =========================================

place_corners sky130_ef_io__corner_pad

# =========================================
# Pads  (order: N/S left -> right, E/W bottom -> top)
#
#                 NORTH:  R  G  B
#   WEST (SPI)                          EAST (status + sync)
#     VSSIO                               VSSA
#     MOSI                                VS
#     SCK                                 HS
#     CS_N                                READY
#     VDDIO                               VDDA
#                 SOUTH:  VCCD CLK RST_N PGOOD VSSD
#
# Each pad sits on the side where its macro pin is (pin_order.cfg),
# so the top-level wires stay short.
# =========================================

place_pads -row IO_SOUTH -mode uniform {u_vccd u_clk u_rst_n u_power_good u_vssd}
place_pads -row IO_WEST  -mode uniform {u_vddio u_cs_n u_sck u_mosi u_vssio}
place_pads -row IO_EAST  -mode uniform {u_vdda u_ready u_hs u_vs u_vssa}
place_pads -row IO_NORTH -mode uniform {u_r u_g u_b}

# ---- OPTIONAL: exact positions by hand instead of "uniform" ----
# Comment out the four place_pads lines above and use place_pad.
# -location is the offset (um) along the row from the die's lower-left
# corner. Check the result: click a pad in the GUI, the Inspector
# shows its bounding box.
#
# place_pad -row IO_SOUTH -location 300  u_vccd
# place_pad -row IO_SOUTH -location 500  u_clk
# place_pad -row IO_SOUTH -location 700  u_rst_n
# place_pad -row IO_SOUTH -location 900  u_power_good
# place_pad -row IO_SOUTH -location 1100 u_vssd
# ... same for IO_WEST / IO_EAST / IO_NORTH

# =========================================
# Fill gaps between I/O cells
# =========================================

set Fillers {
    sky130_ef_io__com_bus_slice_20um
    sky130_ef_io__com_bus_slice_10um
    sky130_ef_io__com_bus_slice_5um
    sky130_ef_io__com_bus_slice_1um
}

foreach Side {NORTH SOUTH EAST WEST} {
    place_io_fill \
        -row "IO_$Side" \
        {*}$Fillers
}

# =========================================
# Connect adjacent padframe terminals (ring buses)
# =========================================

connect_by_abutment

# =========================================
# External pad terminals (the bond openings)
# =========================================

place_io_terminals u_*/PAD

place_io_terminals u_vccd/VCCD_PAD
place_io_terminals u_vssd/VSSD_PAD

place_io_terminals u_vddio/VDDIO_PAD
place_io_terminals u_vssio/VSSIO_PAD

place_io_terminals u_vdda/VDDA_PAD
place_io_terminals u_vssa/VSSA_PAD

# =========================================
# Configuration tie cell (south strip, between core edge and macro)
# =========================================

place_inst \
    -name u_cfg_tie \
    -origin {790 380} \
    -orientation R0 \
    -status PLACED

# Standard-cell legalization (moves the tie cell onto a legal site)
detailed_placement

check_placement -verbose

# =========================================
# Check important instances
# =========================================

set Block [ord::get_db_block]

foreach Name {
    u_core
    u_cfg_tie

    u_clk
    u_rst_n
    u_power_good
    u_cs_n
    u_sck
    u_mosi

    u_ready
    u_hs
    u_vs
    u_r
    u_g
    u_b

    u_vccd
    u_vssd
    u_vddio
    u_vssio
    u_vdda
    u_vssa
} {
    if {[$Block findInst $Name] eq "NULL"} {
        error "Missing instance: $Name"
    }
}

# =========================================
# Save floorplan
# =========================================

write_db "results/01_floorplan.odb"
write_def "results/01_floorplan.def"

write_verilog \
    -include_pwr_gnd \
    "results/01_linked.v"

puts "Floorplan and padframe placement completed."
