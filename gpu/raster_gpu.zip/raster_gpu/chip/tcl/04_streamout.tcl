# =========================================================
# 04_streamout.tcl : merge everything into chip_top.gds (Magic)
# Run from the chip/ folder:
#   magic -dnull -noconsole \
#         -rcfile $SKY130_PDK/libs.tech/magic/sky130A.magicrc \
#         tcl/04_streamout.tcl | tee reports/04_streamout.log
# =========================================================

set PDK $::env(SKY130_PDK)

set HD "$PDK/libs.ref/sky130_fd_sc_hd"
set IO "$PDK/libs.ref/sky130_fd_io"

set TechLEF "$HD/techlef/sky130_fd_sc_hd__nom.tlef"

# Technology information, including via definitions
lef read $TechLEF

# Import the actual layout geometry
gds readonly true
gds rescale false

gds read "$HD/gds/sky130_fd_sc_hd.gds"

set BaseIOGDS "$IO/gds/sky130_fd_io.gds"
if {[file exists $BaseIOGDS]} {
    gds read $BaseIOGDS
}

gds read "$IO/gds/sky130_ef_io.gds"

# Load any separately installed GPIO GDS files
foreach File [glob -nocomplain "$IO/gds/*gpiov2*.gds"] {
    gds read $File
}

# The hardened GPU
gds read "macros/gpu_asic.gds"

# Annotate actual GDS cells with LEF pin information
lef read "$HD/lef/sky130_fd_sc_hd.lef" -annotate
lef read "$IO/lef/sky130_fd_io.lef" -annotate
lef read "$IO/lef/sky130_ef_io.lef" -annotate
lef read "macros/gpu_asic.lef" -annotate

# Import placed cells and routed wires
def read "results/03_routed.def"

load chip_top
select top cell

# Produce candidate chip layout
gds write "results/chip_top.gds"

puts "GDS write command finished"
quit -noprompt
