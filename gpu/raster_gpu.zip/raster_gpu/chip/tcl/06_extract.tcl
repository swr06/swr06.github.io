# =========================================================
# 06_extract.tcl : top-level connectivity extraction (Magic)
# Cells are loaded as LEF ABSTRACTS, so pads / std cells / the macro
# become black boxes and only the TOP-LEVEL wiring is extracted.
# (The macro itself was already LVS-checked inside LibreLane.)
#
#   magic -dnull -noconsole \
#         -rcfile $SKY130_PDK/libs.tech/magic/sky130A.magicrc \
#         tcl/06_extract.tcl | tee reports/06_extract.log
# =========================================================

set PDK $::env(SKY130_PDK)
set HD "$PDK/libs.ref/sky130_fd_sc_hd"
set IO "$PDK/libs.ref/sky130_fd_io"

lef read "$HD/techlef/sky130_fd_sc_hd__nom.tlef"
lef read "$HD/lef/sky130_fd_sc_hd.lef"
lef read "$IO/lef/sky130_fd_io.lef"
lef read "$IO/lef/sky130_ef_io.lef"
lef read "macros/gpu_asic.lef"

def read "results/03_routed.def"

# give the standard cells their real port order (same as LibreLane does)
readspice "$HD/spice/sky130_fd_sc_hd.spice"

load chip_top
select top cell

extract do local
extract all

ext2spice lvs
ext2spice -o results/chip_top_extracted.spice

puts "Extraction finished"
quit -noprompt
