# =========================================================
# 03_route.tcl : signal routing (pads <-> macro, tie cell)
# Run from the chip/ folder:
#     openroad -gui tcl/03_route.tcl
# =========================================================

# =========================================
# Load powered layout
# =========================================

read_db "results/02_power.odb"

set PDK $::env(SKY130_PDK)

read_liberty \
    "$PDK/libs.ref/sky130_fd_sc_hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"

# =========================================
# Find legal access points for pins
# =========================================

pin_access

# =========================================
# Global routing
# =========================================

global_route \
    -guide_file results/03_route.guide \
    -congestion_iterations 100 \
    -verbose

# =========================================
# Detailed routing
# =========================================

detailed_route \
    -output_drc reports/03_route_drc.rpt \
    -output_maze reports/03_maze.log

# =========================================
# Checks
# =========================================

check_antennas -report_file reports/03_antenna.rpt

# =========================================
# Save routed database
# =========================================

write_db results/03_routed.odb

write_def results/03_routed.def

write_verilog \
    -include_pwr_gnd \
    results/03_routed.v

puts "Detailed routing stage completed."
