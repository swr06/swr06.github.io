# =========================================================
# 06_lvs.tcl : compare extracted top level vs 03_routed.v (Netgen)
# Same recipe LibreLane uses internally (steps/netgen.py)
#   netgen -batch source tcl/06_lvs.tcl
# =========================================================

set PDK $::env(SKY130_PDK)

# layout side
set circuit1 [readnet spice results/chip_top_extracted.spice]

# schematic side: std-cell SPICE + the powered top-level netlist
set circuit2 [readnet verilog /dev/null]
readnet spice $PDK/libs.ref/sky130_fd_sc_hd/spice/sky130_fd_sc_hd.spice $circuit2
readnet verilog results/03_routed.v $circuit2

# pads + gpu_asic have no transistor netlist on either side -> black boxes
lvs "$circuit1 chip_top" "$circuit2 chip_top" \
    $PDK/libs.tech/netgen/sky130A_setup.tcl \
    reports/06_lvs.log \
    -blackbox

puts "LVS finished, see reports/06_lvs.log"
