# =========================================================
# 02_power.tcl : power nets, core ring, straps, macro hookup
# Run from the chip/ folder:
#     openroad -gui tcl/02_power.tcl
# =========================================================

# =========================================
# Load completed floorplan
# =========================================

read_db "results/01_floorplan.odb"

set PDK $::env(SKY130_PDK)
set HD "$PDK/libs.ref/sky130_fd_sc_hd"

read_liberty \
    "$HD/lib/sky130_fd_sc_hd__tt_025C_1v80.lib"

set Block [ord::get_db_block]

# =========================================
# Mark the supply networks
# =========================================

foreach {Name Type} {
    VCCD  POWER
    VSSD  GROUND
    VDDIO POWER
    VSSIO GROUND
    VDDA  POWER
    VSSA  GROUND
} {
    set Net [$Block findNet $Name]

    if {$Net eq "NULL"} {
        error "Missing supply net: $Name"
    }

    $Net setSpecial
    $Net setSigType $Type
}

# =========================================
# Register power-pin matching rules
# =========================================
# VPWR/VGND also covers the gpu_asic macro and the tap cells.

add_global_connection \
    -net VCCD \
    -pin_pattern {^(VPWR|VPB|VCCD)$} \
    -power

add_global_connection \
    -net VSSD \
    -pin_pattern {^(VGND|VNB|VSSD)$} \
    -ground

add_global_connection \
    -net VDDIO \
    -pin_pattern {^VDDIO$} \
    -power

add_global_connection \
    -net VSSIO \
    -pin_pattern {^VSSIO$} \
    -ground

add_global_connection \
    -net VDDA \
    -pin_pattern {^VDDA$} \
    -power

add_global_connection \
    -net VSSA \
    -pin_pattern {^VSSA$} \
    -ground

global_connect -verbose

# =========================================
# Digital-core voltage domain
# =========================================

set_voltage_domain \
    -name CORE \
    -power VCCD \
    -ground VSSD

# =========================================
# Define the core PDN grid
# =========================================

define_pdn_grid \
    -name CORE_GRID \
    -voltage_domains {CORE}

# =========================================
# Core power ring  (met4 vertical / met5 horizontal)
# -connect_to_pads joins the ring to the VCCD/VSSD pad pins
# =========================================

add_pdn_ring \
    -grid CORE_GRID \
    -layers {met4 met5} \
    -widths {4 4} \
    -spacings {2 2} \
    -core_offsets 10 \
    -connect_to_pads

# =========================================
# Standard-cell power rails (met1, on every row)
# =========================================

add_pdn_stripe \
    -grid CORE_GRID \
    -layer met1 \
    -width 0.48 \
    -followpins \
    -extend_to_core_ring

# =========================================
# Upper metal power straps
# =========================================
# met5 horizontal straps run OVER the macro (the macro only uses
# met1-met4), that is how the macro gets its power.

add_pdn_stripe \
    -grid CORE_GRID \
    -layer met4 \
    -width 1.6 \
    -pitch 48 \
    -offset 20 \
    -extend_to_core_ring

add_pdn_stripe \
    -grid CORE_GRID \
    -layer met5 \
    -width 1.6 \
    -pitch 48 \
    -offset 20 \
    -extend_to_core_ring

# =========================================
# PDN vias
# =========================================

add_pdn_connect \
    -grid CORE_GRID \
    -layers {met1 met4}

add_pdn_connect \
    -grid CORE_GRID \
    -layers {met4 met5}

# =========================================
# Hard macro power grid
# =========================================
# The macro's VPWR/VGND pins are vertical met4 straps.
# Every top-level met5 strap that crosses them gets a met4-met5 via.
# -halo keeps the top-level met4 straps / rails 10 um away from it.

define_pdn_grid \
    -macro \
    -name GPU_GRID \
    -instances {u_core} \
    -starts_with POWER \
    -halo {10 10}

add_pdn_connect \
    -grid GPU_GRID \
    -layers {met4 met5}

# =========================================
# Check and generate PDN
# =========================================

pdngen -check_only

pdngen \
    -failed_via_report reports/02_failed_vias.rpt

# =========================================
# Save
# =========================================

write_db results/02_power.odb
write_def results/02_power.def

puts "Core power network generated."
