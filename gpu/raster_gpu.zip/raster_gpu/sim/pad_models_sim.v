`timescale 1ns / 1ps

// =============================================================
// SIMULATION-ONLY stand-ins for the SKY130 pad cells and the
// conb tie cell. They only model what the chip_top wiring relies on:
//   - input path : IN = PAD   (when INP_DIS = 0)
//   - output path: PAD = OUT  (when OE_N = 0 and ENABLE_H = 1)
//   - TIE_HI_ESD = 1, TIE_LO_ESD = 0
// This lets us check the chip_top.v connectivity with Icarus.
// The real views come from the PDK (LEF/GDS/CDL).
// =============================================================

module sky130_ef_io__gpiov2_pad_wrapped (
    output IN, output IN_H, inout PAD_A_NOESD_H, inout PAD_A_ESD_0_H, inout PAD_A_ESD_1_H,
    inout PAD, input [2:0] DM, input HLD_H_N, input INP_DIS, input IB_MODE_SEL,
    input ENABLE_H, input ENABLE_VDDA_H, input ENABLE_INP_H, input OE_N,
    output TIE_HI_ESD, output TIE_LO_ESD, input SLOW, input VTRIP_SEL, input HLD_OVR,
    input ANALOG_EN, input ANALOG_SEL, input ENABLE_VDDIO, input ENABLE_VSWITCH_H,
    input ANALOG_POL, input OUT, inout AMUXBUS_A, inout AMUXBUS_B,
    inout VSSA, inout VDDA, inout VSWITCH, inout VDDIO_Q, inout VCCHIB, inout VDDIO,
    inout VCCD, inout VSSIO, inout VSSD, inout VSSIO_Q
);
    assign TIE_HI_ESD = 1'b1;
    assign TIE_LO_ESD = 1'b0;
    wire inp_ok = (INP_DIS === 1'b0) && ((ENABLE_H === 1'b1) || (ENABLE_INP_H === 1'b1));
    assign IN   = inp_ok ? PAD : 1'b0;
    assign IN_H = inp_ok ? PAD : 1'b0;
    assign PAD  = (OE_N === 1'b0 && ENABLE_H === 1'b1 && DM === 3'b110) ? OUT : 1'bz;
endmodule

module sky130_fd_sc_hd__conb_1 (output HI, output LO, inout VPWR, inout VGND, inout VPB, inout VNB);
    assign HI = 1'b1;
    assign LO = 1'b0;
endmodule

`define SUPPLY_PAD(NAME, P) \
module NAME (inout AMUXBUS_A, inout AMUXBUS_B, inout VSSA, inout VDDA, inout VSWITCH, \
             inout VDDIO_Q, inout VCCHIB, inout VDDIO, inout VCCD, inout VSSIO, inout VSSD, \
             inout VSSIO_Q, inout P); \
endmodule

`SUPPLY_PAD(sky130_ef_io__vccd_lvc_clamped_pad,  VCCD_PAD)
`SUPPLY_PAD(sky130_ef_io__vssd_lvc_clamped_pad,  VSSD_PAD)
`SUPPLY_PAD(sky130_ef_io__vddio_hvc_clamped_pad, VDDIO_PAD)
`SUPPLY_PAD(sky130_ef_io__vssio_hvc_clamped_pad, VSSIO_PAD)
`SUPPLY_PAD(sky130_ef_io__vdda_hvc_clamped_pad,  VDDA_PAD)
`SUPPLY_PAD(sky130_ef_io__vssa_hvc_clamped_pad,  VSSA_PAD)
