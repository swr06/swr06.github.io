`timescale 1ns / 1ps

// =============================================================
// Self-checking testbench for gpu_core
//   [1] reset + power-up clear   [5] malformed SPI frames
//   [2] lines                    [6] command while busy
//   [3] rectangles               [7] SWAP + full frame from the pins
//   [4] circles                  [8] reset in the middle of a command
//
//   default        : FPGA parameters (320x240, RGB332, double buffer)
//   -DASIC_CFG     : ASIC parameters (40x30,  RGB111, single buffer)
//
//   +vcd                     dump waveforms to build/gpu.vcd
//   +demo=<file.hex>         run a command stream from gen_demo.py
//   +frames=<prefix>         where captured VGA frames are written
//
// A software model of the framebuffer is kept next to the DUT.
// After every command the DUT memory is compared with the model,
// and captured VGA frames are compared pixel-by-pixel too.
// =============================================================

module tb_gpu;

`ifdef ASIC_CFG
    localparam FB_W = 40,  FB_H = 30,  SHIFT = 4, PIX_BITS = 3, DOUBLE_BUF = 0;
`elsif SRAM_CFG
    localparam FB_W = 80,  FB_H = 60,  SHIFT = 3, PIX_BITS = 8, DOUBLE_BUF = 0;
`else
    localparam FB_W = 320, FB_H = 240, SHIFT = 1, PIX_BITS = 8, DOUBLE_BUF = 1;
`endif
    localparam FB_PIXELS = FB_W * FB_H;
    localparam DEPTH     = FB_PIXELS * (DOUBLE_BUF ? 2 : 1);
    localparam SPI_HALF  = 250;               // 2 MHz SCK

    // ---------------- clock / DUT ----------------
    reg clk = 1'b0;
    always #20 clk = ~clk;                    // 25 MHz

    reg rst_n = 1'b0;
    reg cs_n  = 1'b1, sck = 1'b0, mosi = 1'b0;
    wire ready, hs, vs, dbg;
    wire [PIX_BITS-1:0] pix;

    gpu_core #(
        .FB_W(FB_W), .FB_H(FB_H), .SCALE_SHIFT(SHIFT),
        .PIX_BITS(PIX_BITS), .DOUBLE_BUF(DOUBLE_BUF)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .spi_cs_n(cs_n), .spi_sck(sck), .spi_mosi(mosi),
        .gpu_ready(ready),
        .vga_hs(hs), .vga_vs(vs), .vga_pix(pix),
        .dbg_cmd_toggle(dbg)
    );

    // ---------------- write monitor ----------------
    integer writes = 0;
    always @(posedge clk) begin
        if (dut.fb_we === 1'b1) begin
            if (dut.fb_waddr >= DEPTH)
                $fatal(1, "FB write out of range: %0d", dut.fb_waddr);
            if (dut.line_plot + dut.rect_plot + dut.circ_plot > 1)
                $fatal(1, "two engines plotting at once");
            writes = writes + 1;
        end
    end

    // READY watchdog
    integer stall = 0;
    always @(posedge clk) begin
        if (ready === 1'b1) stall = 0;
        else begin
            stall = stall + 1;
            if (stall > 3000000) $fatal(1, "READY stuck low (line %b rect %b circle %b swap %b)", dut.line_busy, dut.rect_busy, dut.circ_busy, dut.swap_pending);
        end
    end

    // swaps must happen exactly at the start of vertical blanking
    reg prev_front = 1'b0;
    integer swaps_seen = 0;
    always @(negedge clk) begin
        if (dut.front_buf !== prev_front && dut.reset !== 1'b1) begin
            if (dut.u_vga.v_count != 480 || dut.u_vga.h_count != 1)
                $fatal(1, "buffer swap outside vblank (v=%0d h=%0d)",
                       dut.u_vga.v_count, dut.u_vga.h_count);
            swaps_seen = swaps_seen + 1;
        end
        prev_front = dut.front_buf;
    end

    // ---------------- software model ----------------
    reg [PIX_BITS-1:0] model [0 : 2*FB_PIXELS-1];
    integer front = 0;           // which model buffer is on screen
    integer model_count;         // pixels the last command should write

    function [PIX_BITS-1:0] conv(input [7:0] c);
        conv = (PIX_BITS == 3) ? {c[7], c[4], c[1]} : c[PIX_BITS-1:0];
    endfunction

    function integer back;
        input dummy;
        back = DOUBLE_BUF ? 1 - front : 0;
    endfunction

    function integer sx12(input [15:0] v);    // 12-bit signed, like the RTL
        sx12 = v[11] ? ($signed({1'b0, v[11:0]}) - 4096) : v[11:0];
    endfunction

    task model_plot(input integer x, input integer y, input [PIX_BITS-1:0] c);
        begin
            if (x >= 0 && x < FB_W && y >= 0 && y < FB_H) begin
                model[back(0) * FB_PIXELS + y * FB_W + x] = c;
                model_count = model_count + 1;
            end
        end
    endtask

    task model_line(input integer x0, y0, x1, y1, input [PIX_BITS-1:0] c);
        integer x, y, dx, dy, sx, sy, err, e2, done;
        begin
            dx = (x1 > x0) ? x1 - x0 : x0 - x1;
            dy = (y1 > y0) ? y0 - y1 : y1 - y0;
            sx = (x0 < x1) ? 1 : -1;
            sy = (y0 < y1) ? 1 : -1;
            err = dx + dy; x = x0; y = y0; done = 0;
            while (!done) begin
                model_plot(x, y, c);
                if (x == x1 && y == y1) done = 1;
                else begin
                    e2 = 2 * err;
                    if (e2 >= dy) begin err = err + dy; x = x + sx; end
                    if (e2 <= dx) begin err = err + dx; y = y + sy; end
                end
            end
        end
    endtask

    task model_rect(input integer x, y, w, h, input [PIX_BITS-1:0] c);
        integer i, j, x0, y0, x1, y1;
        begin
            x0 = (x < 0) ? 0 : x;            y0 = (y < 0) ? 0 : y;
            x1 = (x + w > FB_W) ? FB_W : x + w;
            y1 = (y + h > FB_H) ? FB_H : y + h;
            for (j = y0; j < y1; j = j + 1)
                for (i = x0; i < x1; i = i + 1)
                    model_plot(i, j, c);
        end
    endtask

    // midpoint circle, same step order and span rules as circle_renderer.v
    task model_span(input integer row, xa, xb, input [PIX_BITS-1:0] c);
        integer i;
        begin
            if (xa < 0) xa = 0;
            if (xb > FB_W - 1) xb = FB_W - 1;
            if (row >= 0 && row < FB_H)
                for (i = xa; i <= xb; i = i + 1)
                    model_plot(i, row, c);
        end
    endtask

    task model_circle(input integer cx, cy, r, fill, input [PIX_BITS-1:0] c);
        integer x, y, dd, xn, yn, dn, last;
        begin
            x = r; y = 0; dd = 1 - r; last = 0;
            while (!last) begin
                yn = y + 1;
                xn = (dd < 0) ? x : x - 1;
                dn = (dd < 0) ? dd + 2 * yn + 1 : dd + 2 * (yn - xn) + 1;
                last = (xn < yn);
                if (!fill) begin
                    model_plot(cx + x, cy + y, c);  model_plot(cx + y, cy + x, c);
                    model_plot(cx - y, cy + x, c);  model_plot(cx - x, cy + y, c);
                    model_plot(cx - x, cy - y, c);  model_plot(cx - y, cy - x, c);
                    model_plot(cx + y, cy - x, c);  model_plot(cx + x, cy - y, c);
                end
                else begin
                    model_span(cy + y, cx - x, cx + x, c);
                    if (y != 0)
                        model_span(cy - y, cx - x, cx + x, c);
                    if ((dd >= 0 || last) && x != y) begin
                        model_span(cy + x, cx - y, cx + y, c);
                        model_span(cy - x, cx - y, cx + y, c);
                    end
                end
                x = xn; y = yn; dd = dn;
            end
        end
    endtask

    task model_apply(input [79:0] w);
        reg [7:0] op;
        integer a, b, c, d;
        begin
            op = w[79:72];
            a = sx12(w[71:56]); b = sx12(w[55:40]);
            c = sx12(w[39:24]); d = sx12(w[23:8]);
            model_count = 0;
            case (op)
                8'h01: model_rect(0, 0, FB_W, FB_H, conv(w[7:0]));
                8'h02: model_line(a, b, c, d, conv(w[7:0]));
                8'h03: model_rect(a, b, w[39:24] & 12'hFFF, w[23:8] & 12'hFFF, conv(w[7:0]));
                8'h04: if (DOUBLE_BUF) front = 1 - front;
                8'h05: model_circle(a, b, w[34:24], w[8], conv(w[7:0]));
                default: ;
            endcase
        end
    endtask

    // read one pixel out of the DUT memory (flip-flop array or SRAM macros)
    function [PIX_BITS-1:0] peek(input integer a);
`ifdef SRAM_CFG
        reg [31:0] wd;
        begin
            case (a / 1024)
                0: wd = dut.u_fb.g_bank[0].u_sram.mem[(a % 1024) / 4];
                1: wd = dut.u_fb.g_bank[1].u_sram.mem[(a % 1024) / 4];
                2: wd = dut.u_fb.g_bank[2].u_sram.mem[(a % 1024) / 4];
                3: wd = dut.u_fb.g_bank[3].u_sram.mem[(a % 1024) / 4];
                default: wd = dut.u_fb.g_bank[4].u_sram.mem[(a % 1024) / 4];
            endcase
            peek = wd >> (8 * (a % 4));
        end
`else
        peek = dut.u_fb.mem[a];
`endif
    endfunction

    task compare_back;
        integer i, base;
        begin
            base = DOUBLE_BUF ? (dut.front_buf ? 0 : FB_PIXELS) : 0;
            if (DOUBLE_BUF && dut.front_buf !== front[0])
                $fatal(1, "front buffer mismatch");
            for (i = 0; i < FB_PIXELS; i = i + 1)
                if (peek(base + i) !== model[back(0) * FB_PIXELS + i])
                    $fatal(1, "FB mismatch at pixel %0d (x=%0d y=%0d): dut=%h model=%h",
                           i, i % FB_W, i / FB_W, peek(base + i),
                           model[back(0) * FB_PIXELS + i]);
        end
    endtask

    // ---------------- SPI host ----------------
    task wait_ready;
        begin
            wait (ready === 1'b1);
            @(negedge clk);
            @(negedge clk);     // SRAM macros commit writes half a clock later
        end
    endtask

    task spi_frame(input [79:0] w, input integer nbits);
        integer i;
        begin
            cs_n = 1'b0;
            #(SPI_HALF);
            for (i = 0; i < nbits; i = i + 1) begin
                mosi = (i < 80) ? w[79 - i] : 1'b0;
                #(SPI_HALF) sck = 1'b1;
                #(SPI_HALF) sck = 1'b0;
            end
            #(SPI_HALF) cs_n = 1'b1;
            #(SPI_HALF);
        end
    endtask

    integer n_cmds = 0;

    // send one command, then check write count + whole back buffer
    task exec(input [79:0] w);
        integer wr0;
        begin
            wait_ready;
            model_apply(w);
            wr0 = writes;
            spi_frame(w, 80);
            repeat (8) @(negedge clk);
            wait_ready;
            if (writes - wr0 != model_count)
                $fatal(1, "cmd %h wrote %0d pixels, model says %0d", w, writes - wr0, model_count);
            if (w[79:72] != 8'h04)
                compare_back;
            n_cmds = n_cmds + 1;
        end
    endtask

    function [79:0] mk(input [7:0] op, input integer a, b, c, d, input [7:0] col);
        mk = {op, a[15:0], b[15:0], c[15:0], d[15:0], col};
    endfunction

    // ---------------- VGA frame capture from the pins ----------------
    integer hd1 = 0, vd1 = 0, hd2 = 0, vd2 = 0;
    integer cap_state = 0, cap_fd = 0, cap_errors = 0;
    reg [PIX_BITS-1:0] expect_pix;
    reg expect_hs, expect_vs;

    always @(negedge clk) begin
        // pins at this negedge belong to the counter value seen 2 negedges ago
        if (cap_state == 1 && hd2 == 0 && vd2 == 0)
            cap_state = 2;

        if (cap_state == 2) begin
            expect_hs = !(hd2 >= 656 && hd2 < 752);
            expect_vs = !(vd2 >= 490 && vd2 < 492);
            if (hd2 < 640 && vd2 < 480)
                expect_pix = model[front * FB_PIXELS + (vd2 >> SHIFT) * FB_W + (hd2 >> SHIFT)];
            else
                expect_pix = 0;

            if (pix !== expect_pix || hs !== expect_hs || vs !== expect_vs) begin
                cap_errors = cap_errors + 1;
                if (cap_errors < 5)
                    $display("VGA mismatch at (%0d,%0d): pix=%h exp=%h hs=%b vs=%b",
                             hd2, vd2, pix, expect_pix, hs, vs);
            end
            if (hd2 < 640 && vd2 < 480)
                $fwrite(cap_fd, "%h\n", pix);
            if (hd2 == 799 && vd2 == 524)
                cap_state = 3;
        end

        hd2 = hd1; vd2 = vd1;
        hd1 = dut.u_vga.h_count; vd1 = dut.u_vga.v_count;
    end

    task capture_frame(input [8*128-1:0] fname);
        begin
            cap_fd = $fopen(fname, "w");
            cap_errors = 0;
            cap_state = 1;
            wait (cap_state == 3);
            cap_state = 0;
            $fclose(cap_fd);
            if (cap_errors != 0)
                $fatal(1, "captured frame %0s has %0d mismatches", fname, cap_errors);
            $display("  captured + verified frame -> %0s", fname);
        end
    endtask

    // ---------------- test sequence ----------------
    reg [8*128-1:0] demo_file, frame_prefix, fname;
    reg [79:0] w;
    integer fd, i, r, wr0, frame_no, swaps_in_stream;

    initial begin
        if ($test$plusargs("vcd")) begin
            $dumpfile("build/gpu.vcd");
            $dumpvars(0, tb_gpu);
        end
        if (!$value$plusargs("frames=%s", frame_prefix))
            frame_prefix = "build/frame";

        for (i = 0; i < 2 * FB_PIXELS; i = i + 1) model[i] = 0;

        // ---- 1. reset + power-up clear ----
        #1000;
        if (ready !== 1'b0 || pix !== 0) $fatal(1, "reset: READY/RGB not low");
        rst_n = 1'b1;
        wait_ready;
        if (writes != DEPTH) $fatal(1, "power-up clear wrote %0d, expected %0d", writes, DEPTH);
        compare_back;
        $display("[1] reset + power-up clear of %0d words OK", DEPTH);

        if ($value$plusargs("demo=%s", demo_file)) begin
            // ---------------- demo mode ----------------
            fd = $fopen(demo_file, "r");
            if (fd == 0) $fatal(1, "cannot open %0s", demo_file);
            frame_no = 0; swaps_in_stream = 0;
            while (!$feof(fd)) begin
                r = $fscanf(fd, "%h\n", w);
                if (r == 1) begin
                    exec(w);
                    if (w[79:72] == 8'h04) begin
                        swaps_in_stream = swaps_in_stream + 1;
                        if (DOUBLE_BUF || swaps_in_stream > 1) begin
                            $sformat(fname, "%0s_%03d.hex", frame_prefix, frame_no);
                            capture_frame(fname);
                            frame_no = frame_no + 1;
                        end
                    end
                end
            end
            $fclose(fd);
            $display("PASS: demo %0s, %0d commands, %0d frames", demo_file, n_cmds, frame_no);
            $finish;
        end

        // ---- 2. lines: all 8 octants, axis, point, clipped ----
        exec(mk(8'h01, 0, 0, 0, 0, 8'h00));
        exec(mk(8'h02, FB_W/2, FB_H/2, FB_W-3, FB_H/2+3,  8'hE0));
        exec(mk(8'h02, FB_W/2, FB_H/2, FB_W/2+4, FB_H-2,  8'h1C));
        exec(mk(8'h02, FB_W/2, FB_H/2, FB_W/2-4, FB_H-2,  8'h03));
        exec(mk(8'h02, FB_W/2, FB_H/2, 2, FB_H/2+3,       8'hFC));
        exec(mk(8'h02, FB_W/2, FB_H/2, 2, FB_H/2-3,       8'h1F));
        exec(mk(8'h02, FB_W/2, FB_H/2, FB_W/2-4, 1,       8'hE3));
        exec(mk(8'h02, FB_W/2, FB_H/2, FB_W/2+4, 1,       8'hFF));
        exec(mk(8'h02, FB_W/2, FB_H/2, FB_W-3, FB_H/2-3,  8'hF0));
        exec(mk(8'h02, 0, 0, FB_W-1, 0,                   8'hFF));   // horizontal
        exec(mk(8'h02, FB_W-1, FB_H-1, FB_W-1, 0,         8'hE0));   // vertical
        exec(mk(8'h02, 5, 5, 5, 5,                        8'h1C));   // single point
        exec(mk(8'h02, -20, -10, FB_W+15, FB_H+7,         8'h03));   // clipped both ends
        exec(mk(8'h02, -100, 3, -5, 9,                    8'hFF));   // fully off screen
        $display("[2] line renderer: octants, axis, point, clipping OK");

        // ---- 3. rectangles + clipping ----
        exec(mk(8'h03, 3, 2, 7, 5,                        8'hE0));
        exec(mk(8'h03, -4, -3, 9, 8,                      8'h1C));   // clipped top/left
        exec(mk(8'h03, FB_W-4, FB_H-3, 50, 50,            8'h03));   // clipped bottom/right
        exec(mk(8'h03, 10, 10, 0, 5,                      8'hFF));   // zero width -> nothing
        exec(mk(8'h03, FB_W+5, 2, 4, 4,                   8'hFF));   // off screen -> nothing
        $display("[3] rectangle filler + clipping OK");

        // ---- 4. circles: outline + filled, tiny, clipped, huge, off screen ----
        exec(mk(8'h01, 0, 0, 0, 0, 8'h00));
        exec(mk(8'h05, FB_W/2, FB_H/2, FB_H/3, 0,         8'hFF));   // outline
        exec(mk(8'h05, FB_W/2, FB_H/2, FB_H/5, 1,         8'hE0));   // filled
        exec(mk(8'h05, 4, 4, 0, 0,                        8'h1C));   // r = 0
        exec(mk(8'h05, 8, 4, 0, 1,                        8'h1C));
        exec(mk(8'h05, 4, 9, 1, 0,                        8'h03));   // r = 1
        exec(mk(8'h05, 9, 9, 1, 1,                        8'h03));
        exec(mk(8'h05, -3, 2, 8, 0,                       8'hFC));   // clipped left/top
        exec(mk(8'h05, -3, FB_H/2, 8, 1,                  8'hFC));
        exec(mk(8'h05, FB_W-2, FB_H-1, 10, 1,             8'h1F));   // clipped right/bottom
        exec(mk(8'h05, FB_W-2, 1, 9, 0,                   8'hE3));
        exec(mk(8'h05, -100, -100, 5, 1,                  8'hFF));   // off screen
        exec(mk(8'h05, 2047, -2048, 2047, 0,              8'hFF));   // extreme values
        exec(mk(8'h05, 2047, -2048, 2047, 1,              8'hFF));
        exec(mk(8'h05, FB_W/2, FB_H/2, FB_W, 1,           8'h92));   // covers the screen
        exec(mk(8'h05, FB_W/2, FB_H/2, FB_W, 0,           8'hF0));   // all off screen
        $display("[4] circle renderer: outline, filled, r=0/1, clipping, extremes OK");

        // ---- 5. malformed frames must not write anything ----
        wr0 = writes;
        wait_ready; spi_frame(mk(8'h03, 0, 0, 5, 5, 8'hFF), 79);
        wait_ready; spi_frame(mk(8'h03, 0, 0, 5, 5, 8'hFF), 81);
        wait_ready; spi_frame(mk(8'h7F, 0, 0, 5, 5, 8'hFF), 80);
        repeat (50) @(negedge clk);
        wait_ready;
        if (writes != wr0) $fatal(1, "malformed frame wrote pixels");
        compare_back;
        $display("[5] short / long / unknown frames ignored OK");

        // ---- 6. a frame sent while busy is dropped ----
        model_apply(mk(8'h01, 0, 0, 0, 0, 8'h92));
        wr0 = writes;
        wait_ready;
        spi_frame(mk(8'h01, 0, 0, 0, 0, 8'h92), 80);       // CLEAR (busy for FB_PIXELS clocks)
        spi_frame(mk(8'h03, 0, 0, 4, 4, 8'hE0), 80);       // immediately, no READY check
        repeat (8) @(negedge clk);
        wait_ready;
        if (writes - wr0 != FB_PIXELS) $fatal(1, "busy-drop test wrote %0d", writes - wr0);
        compare_back;
        $display("[6] command during busy dropped OK");

        // ---- 7. build a scene, SWAP, capture a full frame from the pins ----
        exec(mk(8'h01, 0, 0, 0, 0, 8'h00));
        exec(mk(8'h03, 2, 2, FB_W/3, FB_H/3,              8'hE0));
        exec(mk(8'h03, FB_W/2, FB_H/2, FB_W/3, FB_H/3,    8'h1C));
        exec(mk(8'h02, 0, FB_H-1, FB_W-1, 0,              8'hFF));
        exec(mk(8'h02, 0, 0, FB_W-1, FB_H-1,              8'h03));
        exec(mk(8'h05, FB_W*3/4, FB_H/4, FB_H/6, 1,      8'hFC));
        exec(mk(8'h05, FB_W/4, FB_H*3/4, FB_H/6, 0,      8'h1F));
        exec(mk(8'h04, 0, 0, 0, 0, 8'h00));                // SWAP
        if (DOUBLE_BUF && swaps_seen != 1) $fatal(1, "swap did not happen");
        $sformat(fname, "%0s_test.hex", frame_prefix);
        capture_frame(fname);
        $display("[7] SWAP at vblank + full 800x525 frame (pixels, HSYNC, VSYNC) OK");

        // ---- 8. reset again in the middle of things ----
        wait_ready;
        spi_frame(mk(8'h01, 0, 0, 0, 0, 8'hFF), 80);
        #2000;
        rst_n = 1'b0; #500;
        if (ready !== 1'b0) $fatal(1, "READY high in reset");
        wr0 = writes;
        rst_n = 1'b1;
        for (i = 0; i < 2 * FB_PIXELS; i = i + 1) model[i] = 0;
        front = 0;
        wait_ready;
        if (writes - wr0 != DEPTH) $fatal(1, "second power-up clear wrote %0d", writes - wr0);
        compare_back;
        $display("[8] reset during a command + second clear OK");

        $display("PASS: all gpu_core tests (%0dx%0d, %0d-bit, %s buffer), %0d commands",
                 FB_W, FB_H, PIX_BITS, DOUBLE_BUF ? "double" : "single", n_cmds);
        $finish;
    end

endmodule
