`timescale 1ns / 1ps
// =============================================================
// tb_selftest : the PYNQ-Z2 top level with its on-board SPI test host
//
// Runs fpga_top (real file, Clocking Wizard replaced by sim/clk_wiz_sim.v)
// as it is built in bring-up step 2, 3 or 4 (iverilog -DSTEP=n, compiled
// with that step's gpu_core.v and engine files, -DROM="<its selftest.mem>"):
//   the power-up test (test 1 runs by itself with SW0 = 1),
//   tests 1..6 by "pressing" BTN1..BTN3 with SW1 down and up
//   (step 2: tests 4..6 are empty - checked that they send nothing),
//   then test 2 again with SW0 = 0 and the SPI header wired back into the
//   Arduino header pins (the loopback test).
// After each test one VGA frame is captured to build/selftest/board_<n>.hex.
// run_sims.sh compares them with frames that tb_gpu.v verified against its
// golden model for the same commands.
// =============================================================
`ifndef STEP
`define STEP 4
`endif
`ifndef ROM
`define ROM "fpga/selftest.mem"
`endif
module tb_selftest;
    reg        sysclk = 1'b0;
    reg        btn0   = 1'b1;          // reset held
    reg  [2:0] btn    = 3'b000;
    reg  [1:0] sw     = 2'b01;         // SW0 = 1: internal test host
    reg        loopback = 1'b0;        // jumper wires SPI header -> AR10/11/13

    wire t_cs, t_sck, t_mosi, ready, hs, vs;
    wire [3:0] r, g, b, led;

    // what the Arduino header sees: the loopback wires, or nothing (pulls)
    wire ar10 = loopback ? t_cs   : 1'b1;
    wire ar13 = loopback ? t_sck  : 1'b0;
    wire ar11 = loopback ? t_mosi : 1'b0;

    fpga_top #(.DEBOUNCE_BITS(4), .ROM_FILE(`ROM)) dut (
        .sysclk(sysclk), .reset(btn0), .btn(btn), .sw(sw),
        .spi_cs_n(ar10), .spi_sck(ar13), .spi_mosi(ar11), .gpu_ready(ready),
        .test_cs_n(t_cs), .test_sck(t_sck), .test_mosi(t_mosi),
        .vga_hs(hs), .vga_vs(vs), .vga_r(r), .vga_g(g), .vga_b(b), .led(led)
    );

    always #20 sysclk = !sysclk;       // 25 MHz (the stand-in passes it through)

    // ---------------- frame capture (same alignment as tb_gpu.v) ----------------
    integer hd1 = 0, vd1 = 0, hd2 = 0, vd2 = 0, cap_state = 0, cap_fd = 0;
    always @(negedge sysclk) begin
        if (cap_state == 1 && hd2 == 0 && vd2 == 0) cap_state = 2;
        if (cap_state == 2) begin
            if (hd2 < 640 && vd2 < 480) $fwrite(cap_fd, "%h\n", dut.pix);
            if (hd2 == 799 && vd2 == 524) cap_state = 3;
        end
        hd2 = hd1; vd2 = vd1;
        hd1 = dut.u_gpu.u_vga.h_count; vd1 = dut.u_gpu.u_vga.v_count;
    end

    task capture(input [8*64-1:0] fname);
        begin
            cap_fd = $fopen(fname, "w");
            cap_state = 1;
            wait (cap_state == 3);
            cap_state = 0;
            $fclose(cap_fd);
        end
    endtask

    // press a button long enough for the debouncer, then wait for the test
    task run_test(input integer n);
        integer k;
        begin
            k = (n - 1) % 3;
            sw[1] = (n > 3);
            @(negedge sysclk) btn[k] = 1'b1;
            wait (dut.test_busy === 1'b1);
            repeat (100) @(negedge sysclk);
            btn[k] = 1'b0;
            wait (dut.test_busy === 1'b0);
            wait (ready === 1'b1);              // last command (the SWAP) done
        end
    endtask

    reg [8*64-1:0] fname;
    integer n, cmds0;
    initial begin
        repeat (50) @(negedge sysclk);
        btn0 = 1'b0;                            // release BTN0
        wait (ready === 1'b1);
        $display("[1] step %0d: reset released, power-up clear done, READY = 1", `STEP);

        // power-up picture: test 1 starts by itself because SW0 = 1
        wait (dut.test_busy === 1'b1);
        wait (dut.test_busy === 1'b0);
        wait (ready === 1'b1);
        capture("build/selftest/auto.hex");
        $display("[2] power-up: test 1 ran by itself, %0d commands", n_cmds);

        for (n = 1; n <= 6; n = n + 1) begin
            cmds0 = n_cmds;
            if (`STEP == 2 && n > 3) begin
                // step 2 has no earlier step: tests 4..6 are empty
                run_test(n);
                repeat (2000) @(negedge sysclk);
                if (n_cmds != cmds0) $fatal(1, "empty test %0d sent %0d commands", n, n_cmds - cmds0);
                $display("[3] test %0d: empty, sends nothing (as it should in step 2)", n);
            end
            else begin
                run_test(n);
                $sformat(fname, "build/selftest/board_%0d.hex", n);
                capture(fname);
                $display("[3] test %0d: %0d commands over SPI, frame -> %0s", n, n_cmds - cmds0, fname);
            end
        end

        // loopback: GPU listens to the Arduino header, test host drives the SPI header
        sw[0] = 1'b0; loopback = 1'b1;
        cmds0 = n_cmds;
        run_test(2);
        capture("build/selftest/board_2_loop.hex");
        $display("[4] loopback (SPI header -> AR10/AR11/AR13, SW0 = 0): test 2, %0d commands", n_cmds - cmds0);
        $display("PASS: bring-up step %0d: power-up test + 6 tests + loopback", `STEP);
        $finish;
    end

    // count completed SPI frames seen by the GPU
    integer n_cmds = 0;
    always @(posedge sysclk) if (dut.u_gpu.cmd_valid) n_cmds = n_cmds + 1;

    initial begin
        #2_000_000_000;                         // 2 s simulated: something is stuck
        $fatal(1, "timeout (test_busy %b, ready %b)", dut.test_busy, ready);
    end
endmodule
