`timescale 1ns / 1ps
// SIMULATION-ONLY behavioural stand-in for the OpenRAM macro, written to
// match the PDK model's timing: inputs captured on posedge, data out on the
// following negedge (so it is valid at the next posedge = 1 clk latency).
// For real work use $SKY130_PDK/libs.ref/sky130_sram_macros/verilog/*.v
module sky130_sram_1kbyte_1rw1r_32x256_8 (
    input clk0, input csb0, input web0, input [3:0] wmask0, input [7:0] addr0,
    input [31:0] din0, output reg [31:0] dout0,
    input clk1, input csb1, input [7:0] addr1, output reg [31:0] dout1
);
    reg [31:0] mem [0:255];
    reg csb0_r, web0_r, csb1_r; reg [3:0] wm_r; reg [7:0] a0_r, a1_r; reg [31:0] d0_r;
    always @(posedge clk0) begin csb0_r <= csb0; web0_r <= web0; wm_r <= wmask0; a0_r <= addr0; d0_r <= din0; end
    always @(posedge clk1) begin csb1_r <= csb1; a1_r <= addr1; end
    always @(negedge clk0) if (!csb0_r && !web0_r) begin
        if (wm_r[0]) mem[a0_r][ 7: 0] <= d0_r[ 7: 0];
        if (wm_r[1]) mem[a0_r][15: 8] <= d0_r[15: 8];
        if (wm_r[2]) mem[a0_r][23:16] <= d0_r[23:16];
        if (wm_r[3]) mem[a0_r][31:24] <= d0_r[31:24];
    end
    always @(negedge clk1) if (!csb1_r) dout1 <= mem[a1_r];
endmodule
