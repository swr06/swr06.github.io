`timescale 1ns / 1ps
// Simulation stand-in for the Vivado Clocking Wizard (clk_wiz_0).
// The testbench already drives 25 MHz, so the clock is passed through;
// 'locked' rises after 20 clocks like the real MMCM after its lock time.
module clk_wiz_0 (
    input  wire clk_in1,
    input  wire reset,
    output wire clk_out1,
    output reg  locked
);
    assign clk_out1 = clk_in1;
    integer n = 0;
    initial locked = 1'b0;
    always @(posedge clk_in1)
        if (reset) begin n = 0; locked <= 1'b0; end
        else if (n < 20) n = n + 1;
        else locked <= 1'b1;
endmodule
