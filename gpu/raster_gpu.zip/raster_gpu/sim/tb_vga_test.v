`timescale 1ns / 1ps
// =============================================================
// tb_vga_test : bring-up step 1 bitstream (vga_test_top) in simulation
//
// Captures one full 640x480 frame from the VGA pins for every
// picture: checkerboard (after reset), colour bars (BTN2),
// DAC ramps (BTN3), grid (SW1), inverted checkerboard (BTN1 + SW0).
// Each pixel is written as 3 hex digits RGB444 to
// build/vga_test/pattern_<n>.hex; scripts/check_vga_test.py compares
// every pixel with an independent model and makes the PNGs.
// =============================================================
module tb_vga_test;
    reg sysclk = 1'b0, btn0 = 1'b1;
    reg [2:0] btn = 3'b000;
    reg [1:0] sw  = 2'b00;
    wire hs, vs; wire [3:0] r, g, b, led;

    vga_test_top dut (.sysclk(sysclk), .reset(btn0), .btn(btn), .sw(sw),
                      .vga_hs(hs), .vga_vs(vs), .vga_r(r), .vga_g(g), .vga_b(b), .led(led));

    always #20 sysclk = !sysclk;                   // 25 MHz through the clk_wiz stand-in

    // capture: pins carry the pixel of the counters seen 2 clocks earlier
    integer hd1 = 0, vd1 = 0, hd2 = 0, vd2 = 0, st = 0, fd = 0, hs_low = 0, n_hs = 0;
    always @(negedge sysclk) begin
        if (st == 1 && hd2 == 0 && vd2 == 0) st = 2;
        if (st == 2) begin
            if (hd2 < 640 && vd2 < 480) $fwrite(fd, "%h%h%h\n", r, g, b);
            if (vd2 == 100 && hd2 >= 640 && hs === 1'b0) hs_low = hs_low + 1;  // HSYNC width
            if (hd2 == 799 && vd2 == 524) st = 3;
        end
        hd2 = hd1; vd2 = vd1;
        hd1 = dut.u_vga.h_count; vd1 = dut.u_vga.v_count;
    end

    task capture(input [8*48-1:0] fname);
        begin
            fd = $fopen(fname, "w"); st = 1;
            wait (st == 3); st = 0; $fclose(fd);
        end
    endtask

    task press(input integer k);
        begin
            @(negedge sysclk) btn[k] = 1'b1;
            repeat (10) @(negedge sysclk);
            btn[k] = 1'b0;
        end
    endtask

    initial begin
        repeat (50) @(negedge sysclk);
        btn0 = 1'b0;
        wait (dut.top_reset === 1'b0);                 // clock locked, reset released
        repeat (5) @(negedge sysclk);
        capture("build/vga_test/pattern_0.hex");      // checkerboard right after reset
        if (hs_low != 96) $fatal(1, "HSYNC low for %0d clocks, expected 96", hs_low);
        $display("[1] checkerboard after reset, HSYNC pulse = %0d clocks", hs_low);
        press(1); capture("build/vga_test/pattern_1.hex");
        $display("[2] BTN2: colour bars + grey ramp");
        press(2); capture("build/vga_test/pattern_2.hex");
        $display("[3] BTN3: DAC ramps");
        sw[1] = 1'b1; repeat (10) @(negedge sysclk);
        capture("build/vga_test/pattern_3.hex");
        $display("[4] SW1: 1-pixel grid");
        sw[1] = 1'b0; sw[0] = 1'b1; press(0);
        capture("build/vga_test/pattern_4.hex");
        $display("[5] BTN1 + SW0: inverted checkerboard");
        $display("PASS: step 1 (VGA controller + adapter) frames captured");
        $finish;
    end
endmodule
