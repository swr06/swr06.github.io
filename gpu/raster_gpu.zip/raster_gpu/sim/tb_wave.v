`timescale 1ns / 1ps

// =============================================================
// Short waveform testbench (ASIC parameters, small VCD)
// Open build/wave.vcd in GTKWave (or load sim/wave.gtkw).
//   1) reset + power-up clear
//   2) LINE    (2,1) -> (9,4)        red
//   3) RECT    x=3 y=6 w=4 h=2       green
//   4) CIRCLE  outline (20,15) r=3   white
//   5) CIRCLE  filled  (31,6)  r=3   blue
//   6) jumps to screen line 100 (FB row 6) and records two video lines
// =============================================================

module tb_wave;
    reg clk = 1'b0;
    always #20 clk = ~clk;                    // 25 MHz

    reg rst_n = 1'b0;
    reg cs_n = 1'b1, sck = 1'b0, mosi = 1'b0;
    wire ready, hs, vs;
    wire [2:0] rgb;

    gpu_asic dut (
        .clk(clk), .rst_n(rst_n),
        .spi_cs_n(cs_n), .spi_sck(sck), .spi_mosi(mosi),
        .gpu_ready(ready), .vga_hs(hs), .vga_vs(vs), .vga_rgb(rgb)
    );

    task spi_send(input [79:0] w);
        integer i;
        begin
            wait (ready === 1'b1);
            #300 cs_n = 1'b0;
            #250;
            for (i = 79; i >= 0; i = i - 1) begin
                mosi = w[i];
                #250 sck = 1'b1;
                #250 sck = 1'b0;
            end
            #250 cs_n = 1'b1;
            #500;
        end
    endtask

    initial begin
        $dumpfile("build/wave.vcd");
        $dumpvars(0, tb_wave);

        #400 rst_n = 1'b1;
        //            op    x0/x    y0/y     x1/w     y1/h    colour
        spi_send({8'h02, 16'd2, 16'd1, 16'd9, 16'd4, 8'hE0});   // LINE red
        #10000;
        spi_send({8'h03, 16'd3, 16'd6, 16'd4, 16'd2, 8'h1C});   // RECT green
        #10000;
        spi_send({8'h05, 16'd20, 16'd15, 16'd3, 16'd0, 8'hFF}); // CIRCLE outline white
        #10000;
        spi_send({8'h05, 16'd31, 16'd6, 16'd3, 16'd1, 8'h03});  // CIRCLE filled blue
        wait (ready === 1'b1);
        #2000;

        // skip ahead to screen line 100 (FB row 6: rectangle + filled circle)
        $dumpoff;
        wait (dut.u_gpu.u_vga.v_count == 10'd99);
        $dumpon;
        #80000;                                                // > two 32 us video lines
        $finish;
    end
endmodule
