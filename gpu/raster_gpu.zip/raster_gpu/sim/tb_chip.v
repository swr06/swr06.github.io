`timescale 1ns / 1ps

// =============================================================
// Chip-level connectivity test: chip_top.v + pad stand-ins + GPU RTL
//   - outputs must stay Z while power_good is low
//   - SPI in through the pads, VGA out through the pads
// Run with -DUSE_POWER_PINS so gpu_asic has VPWR/VGND ports.
// =============================================================

module tb_chip;
    reg clk = 1'b0;
    always #19.861 clk = ~clk;                 // 25.175 MHz oscillator

    reg power_good = 1'b0, rst_n = 1'b0;
    reg cs_n = 1'b1, sck = 1'b0, mosi = 1'b0;
    wire ready, hs, vs;
    wire [2:0] rgb;
    wire vccd, vssd, vddio, vssio, vdda, vssa;

    // inout pads need nets: drive them from the regs
    wire w_clk = clk, w_rst_n = rst_n, w_pg = power_good;
    wire w_cs_n = cs_n, w_sck = sck, w_mosi = mosi;

    chip_top dut (
        .pad_clk(w_clk), .pad_rst_n(w_rst_n), .pad_power_good(w_pg),
        .pad_cs_n(w_cs_n), .pad_sck(w_sck), .pad_mosi(w_mosi), .pad_ready(ready),
        .pad_hs(hs), .pad_vs(vs), .pad_rgb(rgb),
        .pad_vccd(vccd), .pad_vssd(vssd), .pad_vddio(vddio),
        .pad_vssio(vssio), .pad_vdda(vdda), .pad_vssa(vssa)
    );

    task send(input [79:0] w);
        integer i;
        begin
            wait (ready === 1'b1);
            cs_n = 0; #250;
            for (i = 79; i >= 0; i = i - 1) begin
                mosi = w[i]; #250 sck = 1; #250 sck = 0;
            end
            #250 cs_n = 1; #500;
        end
    endtask

    integer x, y, errors = 0;
    reg [2:0] expect_pix;
    initial begin
        #2000;
        if (ready !== 1'bz || hs !== 1'bz) $fatal(1, "outputs driven while power_good is low");
        $display("[1] pads tri-stated while power_good = 0");
        power_good = 1'b1;
        #1000 rst_n = 1'b1;
        send({8'h01, 64'd0, 8'h1C});                                  // CLEAR green
        send({8'h03, 16'd4, 16'd3, 16'd10, 16'd6, 8'hE0});            // RECT red
        send({8'h02, 16'd0, 16'd29, 16'd39, 16'd0, 8'hFF});           // LINE white
        wait (ready === 1'b1);
        $display("[2] three commands accepted through the SPI pads");

        // compare one whole frame on the RGB pads against the core memory
        wait (dut.u_core.u_gpu.u_vga.h_count == 0 && dut.u_core.u_gpu.u_vga.v_count == 0);
        @(posedge clk); @(posedge clk); #1;          // 2-clock video pipeline
        for (y = 0; y < 480; y = y + 1)
            for (x = 0; x < 800; x = x + 1) begin
                expect_pix = (x < 640) ? dut.u_core.u_gpu.u_fb.mem[(y >> 4) * 40 + (x >> 4)] : 3'b000;
                if (rgb !== expect_pix) errors = errors + 1;
                @(posedge clk); #1;
            end
        if (errors) $fatal(1, "%0d pixel errors on the RGB pads", errors);
        $display("[3] full frame on pad_rgb matches the framebuffer");
        $display("PASS: chip_top wiring (11 GPIO + power-good + supplies + macro)");
        $finish;
    end
    initial begin #40_000_000; $fatal(1, "timeout"); end
endmodule
