`timescale 1ns / 1ps

// =============================================================
// Pins-only testbench for gpu_asic (works on RTL AND on the
// gate-level netlist from LibreLane: no internal signals used).
//
//   +demo=<file.cmd>   commands to send (from gen_demo.py)
//   +out=<file.hex>    captured 640x480 frame (one pixel per line)
//
// The frame is located like a monitor does it: from the sync pulses.
//   VSYNC rises at the end of line 491, HSYNC falls at x = 656.
//   -> 33rd HSYNC fall after VSYNC rises = line 524
//   -> 144 clocks later x = 0 of line 0 comes out.
// =============================================================

module tb_pins;
    reg clk = 1'b0;
    always #19.861 clk = ~clk;                 // 25.175 MHz

    reg rst_n = 1'b0;
    reg cs_n = 1'b1, sck = 1'b0, mosi = 1'b0;
    wire ready, hs, vs;
    wire [2:0] rgb;

    gpu_asic dut (
        .clk(clk), .rst_n(rst_n),
        .spi_cs_n(cs_n), .spi_sck(sck), .spi_mosi(mosi),
        .gpu_ready(ready), .vga_hs(hs), .vga_vs(vs), .vga_rgb(rgb)
    );

    task send(input [79:0] w);
        integer i;
        begin
            wait (ready === 1'b1);
            #100 cs_n = 1'b0;
            #250;
            for (i = 79; i >= 0; i = i - 1) begin
                mosi = w[i];
                #250 sck = 1'b1;
                #250 sck = 1'b0;
            end
            #250 cs_n = 1'b1;
            #500;
        end
    endtask

    reg [8*128-1:0] demo_file, out_file;
    reg [79:0] w;
    integer fd, r, x, y, n;

    initial begin
        if (!$value$plusargs("demo=%s", demo_file)) $fatal(1, "need +demo=");
        if (!$value$plusargs("out=%s", out_file))   out_file = "build/pins_frame.hex";

        #1000 rst_n = 1'b1;

        fd = $fopen(demo_file, "r");
        n = 0;
        while (!$feof(fd)) begin
            r = $fscanf(fd, "%h\n", w);
            if (r == 1) begin send(w); n = n + 1; end
        end
        $fclose(fd);
        wait (ready === 1'b1);
        $display("sent %0d commands", n);

        // ---- find the start of the next frame from the sync pins ----
        @(posedge vs);
        repeat (33) @(negedge hs);
        repeat (144) @(posedge clk);
        #1;
        fd = $fopen(out_file, "w");
        for (y = 0; y < 480; y = y + 1)
            for (x = 0; x < 800; x = x + 1) begin
                if (x < 640) $fwrite(fd, "%h\n", rgb);
                else if (rgb !== 3'b000) $fatal(1, "RGB not black in blanking (x=%0d y=%0d)", x, y);
                if (x == 700 && hs !== 1'b0) $fatal(1, "HSYNC not low at x=700 (y=%0d)", y);
                if (x == 100 && hs !== 1'b1) $fatal(1, "HSYNC low at x=100 (y=%0d)", y);
                @(posedge clk); #1;
            end
        $fclose(fd);
        $display("PASS: frame captured from the pins -> %0s", out_file);
        $finish;
    end

    initial begin #100_000_000; $fatal(1, "timeout"); end
endmodule
