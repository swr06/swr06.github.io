`timescale 1ns / 1ps

// =============================================================
// frame_buffer (SRAM version) - drop-in replacement for rtl/frame_buffer.v
//
// Same ports and same 1-clock read latency, but the storage is a row of
// OpenRAM macros   sky130_sram_1kbyte_1rw1r_32x256_8
//   port 0 (RW) : draw engines write here      (byte write mask)
//   port 1 (R)  : VGA scan-out reads here      (every clock)
//
// One macro = 256 words x 32 bit = 1024 pixels of 8 bit.
//   pixel address a :  bank = a / 1024, word = a[9:2], byte lane = a[1:0]
//
// 80 x 60 x 8 bit = 4800 pixels -> 5 macros
// =============================================================

module frame_buffer #(
    parameter PIX_BITS  = 8,
    parameter DEPTH     = 4800,
    parameter ADDR_BITS = 13
)(
    input wire clk,

    // Write port
    input wire                 write_en,
    input wire [ADDR_BITS-1:0] addr_write,
    input wire [PIX_BITS-1:0]  write_data,

    // Read port
    input  wire [ADDR_BITS-1:0] addr_read,
    output reg  [PIX_BITS-1:0]  read_data
);

    localparam BANKS     = (DEPTH + 1023) / 1024;
    localparam BANK_BITS = (ADDR_BITS > 10) ? ADDR_BITS - 10 : 1;

    // which bank / byte the VGA asked for one clock ago
    reg [BANK_BITS-1:0] rd_bank_d;
    reg [1:0]           rd_lane_d;

    always @(posedge clk) begin
        rd_bank_d <= addr_read[ADDR_BITS-1:10];
        rd_lane_d <= addr_read[1:0];
    end

    wire [7:0]  wr_byte = write_data;          // PIX_BITS = 8 in this build
    wire [3:0]  wr_mask = 4'b0001 << addr_write[1:0];
    wire [31:0] rd_word [0:BANKS-1];

    genvar i;
    generate
        for (i = 0; i < BANKS; i = i + 1) begin : g_bank

            wire sel_w = write_en && (addr_write[ADDR_BITS-1:10] == i);

            // vccd1 / vssd1 are hooked up by LibreLane (PDN_MACRO_CONNECTIONS),
            // dout0 (read data of the write port) is not needed.
            /* verilator lint_off PINMISSING */
            /* verilator lint_off PINCONNECTEMPTY */
            sky130_sram_1kbyte_1rw1r_32x256_8 u_sram (
                // port 0 : write
                .clk0  (clk),
                .csb0  (~sel_w),                 // active low chip select
                .web0  (1'b0),                   // 0 = write
                .wmask0(wr_mask),
                .addr0 (addr_write[9:2]),
                .din0  ({4{wr_byte}}),
                .dout0 (),

                // port 1 : read (always enabled)
                .clk1  (clk),
                .csb1  (1'b0),
                .addr1 (addr_read[9:2]),
                .dout1 (rd_word[i])
            );
            /* verilator lint_on PINCONNECTEMPTY */
            /* verilator lint_on PINMISSING */
        end
    endgenerate

    // pick the byte (combinational after the macro's own output register)
    wire [31:0] sel_word = rd_word[rd_bank_d];

    always @(*) begin
        case (rd_lane_d)
            2'd0: read_data = sel_word[ 7: 0];
            2'd1: read_data = sel_word[15: 8];
            2'd2: read_data = sel_word[23:16];
            default: read_data = sel_word[31:24];
        endcase
    end

endmodule
