`timescale 1ns / 1ps

// =============================================================
// gpu_asic (SRAM version) : 80 x 60, 8-bit RGB332, 5 OpenRAM macros
// 5 inputs + 11 outputs = 16 signal GPIOs
// =============================================================

module gpu_asic (
`ifdef USE_POWER_PINS
    inout  wire VPWR,
    inout  wire VGND,
`endif
    input  wire clk,
    input  wire rst_n,

    input  wire spi_cs_n,
    input  wire spi_sck,
    input  wire spi_mosi,
    output wire gpu_ready,

    output wire vga_hs,
    output wire vga_vs,
    output wire [7:0] vga_rgb    // RRRGGGBB
);

    gpu_core #(
        .FB_W(80),
        .FB_H(60),
        .SCALE_SHIFT(3),         // 8 x 8 screen pixels per FB pixel
        .PIX_BITS(8),
        .DOUBLE_BUF(0)
    ) u_gpu (
        .clk(clk),
        .rst_n(rst_n),
        .spi_cs_n(spi_cs_n),
        .spi_sck(spi_sck),
        .spi_mosi(spi_mosi),
        .gpu_ready(gpu_ready),
        .vga_hs(vga_hs),
        .vga_vs(vga_vs),
        .vga_pix(vga_rgb),
        /* verilator lint_off PINCONNECTEMPTY */
        .dbg_cmd_toggle()                  // debug LED output, not needed on the chip
        /* verilator lint_on PINCONNECTEMPTY */
    );

endmodule
